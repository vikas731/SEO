-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 28, 2019 at 03:06 AM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `seo_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `password` varchar(50) NOT NULL,
  `username` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`password`, `username`) VALUES
('0192023a7bbd73250516f069df18b500', 'vikas'),
('0192023a7bbd73250516f069df18b500', 'karan');

-- --------------------------------------------------------

--
-- Table structure for table `blogpost`
--

DROP TABLE IF EXISTS `blogpost`;
CREATE TABLE IF NOT EXISTS `blogpost` (
  `postid` int(60) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `content` varchar(15000) NOT NULL,
  `image` varchar(100) NOT NULL,
  `category` varchar(50) NOT NULL,
  `addedon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`postid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blogpost`
--

INSERT INTO `blogpost` (`postid`, `title`, `content`, `image`, `category`, `addedon`) VALUES
(1, 'How Can Blogging Help With SEO', '<p style=\"text-align:justify\"><span style=\"background-color:#ffffff; color:rgba(0, 0, 0, 0.8); font-family:calibri; font-size:16px\">Blogs have all kinds of benefits for your veterinary practice website; they can increase awareness of your practice, give you a platform to share your knowledge. This alone makes a blog a great strategy for your website; but did you know that it can also help with your website&rsquo;s ranking on search engines?</span></p>\r\n\r\n<h2 style=\"font-style:normal; margin-left:0px; margin-right:0px\"><strong>How Can A Blog Help?</strong></h2>\r\n\r\n<p style=\"text-align:justify\"><span style=\"background-color:#ffffff; color:rgba(0, 0, 0, 0.8); font-family:calibri; font-size:16px\">Let&rsquo;s face it: there are more neglected and abandoned websites out there than even Google can shake a stick at. That&rsquo;s why search engines are constantly checking the time stamps on when websites are updated.</span></p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">Publishing blog posts is a very logical and natural way to update your website frequently; which is a signal to search engines that it is a good place to send web users. A new blog post even every couple of weeks will show those bots; the updates made on the website.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px\">This doesn&rsquo;t have to turn into a huge time-sink for you, though. We&rsquo;ve got some strategies to help you out!</p>\r\n\r\n<h3 style=\"color:rgba(0, 0, 0, 0.8); font-style:normal; margin-left:0px; margin-right:0px\"><span style=\"font-size:18px\"><strong>It Increases The Number Of Pages On Your Website.</strong></span></h3>\r\n\r\n<p style=\"text-align:justify\"><span style=\"background-color:#ffffff; color:rgba(0, 0, 0, 0.8); font-family:calibri; font-size:16px\">This is the real secret to SEO. The more content you have, more the search engines will have to crawl and index. This helps give the crawlers a better understanding of just what your website is about. And which types of searches it should rank highly for.</span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"background-color:#ffffff; color:rgba(0, 0, 0, 0.8); font-family:calibri; font-size:16px\">It also gives you the opportunity to branch out on your keyword use. There are two main complications with SEO:</span></p>\r\n\r\n<h2 style=\"font-style:normal; margin-left:0px; margin-right:0px; text-align:justify\"><strong>You can only use keywords so many times.</strong></h2>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">Keyword stuffing is when you go a little overboard trying to pack your keywords into one page. It&rsquo;s usually identified by keywords that show up in a list or group; or even seem forced in a selection of copy. Search engines can identify when this is the case. They may also assume that you&rsquo;re trying to trick them into giving your site a higher ranking; which usually just has the opposite effect.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">Because blog posts are generally about a single topic, they&rsquo;re useful for incorporating a range of keywords into your site without running the risk of overdoing it &ndash; and by increasing the number of pages on your website with blog posts, you&rsquo;re giving yourself more room to use your keywords and to include different keywords without affecting your current ones.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">Blogging comes with benefits (for SEO).</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">There are a couple of benefits that your practice can get out of a blog as an SEO strategy:<strong>&nbsp;</strong></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:14px\"><strong>It&rsquo;s great for direct SEO&hellip;</strong></span></p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">which means anything that influences your visitors to behave in ways; that tell search engines that your site is a good resource. This includes:</p>\r\n\r\n<ul style=\"margin-left:24px; margin-right:0px\">\r\n	<li style=\"text-align: justify;\"><span style=\"font-size:14px\"><strong>Inspiring longer visits.</strong></span>&nbsp;If people click on your site from the SERP but go &ldquo;back&rdquo; almost immediately, this tells search engines that the content on your site is either irrelevant or not good. By bringing folks in with quality content that they&rsquo;ll want to read, you can influence them to stay longer than a minute or two &ndash; which tells search engines that your site is a good place to send people looking for that type of information.</li>\r\n	<li style=\"text-align: justify;\"><span style=\"font-size:14px\"><strong>Encouraging inbound links.</strong>&nbsp;</span>When people think that a website has quality content, they&rsquo;re much more likely to include links to that website in their own content as a reference. Search engines see these links that direct users to your site as votes of confidence in your content. You can also put&nbsp;inbound links to your own site&nbsp;in your blog posts, which helps search engines understand what your site is all about.</li>\r\n	<li style=\"text-align: justify;\"><span style=\"font-size:14px\"><strong>Tip:</strong></span>&nbsp;It&rsquo;s important to play by the rules when creating your content.It needs to be unique and original; search engines love content that doesn&rsquo;t exist anywhere else on the web, and penalize duplicate content, so make sure it&rsquo;s your own work.</li>\r\n</ul>\r\n', 'image/SEO-in-Blogging.png', 'Search Engine Optimization', '2019-07-10 06:01:29'),
(2, 'The Future of SEO: How the Voice Search Will Impact SEO', '<h2 style=\"font-style:normal; margin-left:0px; margin-right:0px; text-align:justify\"><span style=\"background-color:#ffffff; color:rgba(0, 0, 0, 0.8); font-family:calibri; font-size:16px\">At Adweb Studio, we love to stay on top of the latest SEO trends, and one we are keeping an eye upon ahead of time is the growing sector of voice search last year. These days, we can see almost three big things happening today with voice search, it is more accurate than ever, many of the household products are equipped with voice search and number of voice search queries is rapidly increasing. In fact, almost 40% of adults are now performing voice search once, per day.</span><br />\r\n<span style=\"background-color:#ffffff; color:rgba(0, 0, 0, 0.8); font-family:calibri; font-size:16px\">However, many of the people type the way they usually speak, which means that websites optimized for the wat people speak might not always match the way people type out. Now as more and more people are using some voice search to find relevant information online, the way that optimizers do the work might shift. As we look on to the SEO trends of 2018,it is time to find out what can you do to prepare for the enhancement of voice search.</span></h2>\r\n\r\n<h2 style=\"font-style:normal; margin-left:0px; margin-right:0px; text-align:justify\"><strong>How does the Voice Search Actually Works?</strong></h2>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\">Speaking through the phone is much more convenient than typing, people nowadays are using more voice searches on their tablets, smartphones and voice assistants to find the information or complete tasks online. Apple uses turns towards Siri, at home people usually ask Google Home, Amazon Alexa as well and Echo devices for some quick answers. If you own a PC or Windows phone, you might be using Microsoft Cortana. No matter, you are on a smartphone, in your living room or using your computer, you must have accessed the voice devices.<br />\r\nWhen the voice search is fairly new, it is a fun function to use, but the research was the most reliable. In 2013, Google&rsquo;s word recognition accuracy was only less than 80%. As with anything else related to research, many things have changed in recent years. Today, voice search is accurate at 92%, while this technique exists to stay. Check out this video from Moz to get more information about this process.</p>\r\n\r\n<h2 style=\"font-style:normal; margin-left:0px; margin-right:0px; text-align:justify\"><strong>Voice Search in Results</strong></h2>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\">In order to optimize your website completely, it is essential to understand how the search engines are determining search results for voice search queries. All the voice controlled devices can primarily prove answers to search queries in any two ways; they will always state the answer to a question, or provide with some website where it is likely that you will find answers to some questions. Moz recently conducted a study that analyzed the search results of 1000 voice searches and found that voice responses were obtained 87% of the time. Featured pieces of Google search results are displayed in a block at the top of the search results page. They provide a summary of the response that you extract from a web page. One of the ways to increase the traffic of audio searches is to focus on appearing as the top priority for valuable searches.</p>\r\n\r\n<h2 style=\"font-style:normal; margin-left:0px; margin-right:0px; text-align:justify\"><strong>How do people use the voice search?</strong></h2>\r\n\r\n<h3 style=\"color:rgba(0, 0, 0, 0.8); font-style:normal; margin-left:0px; margin-right:0px; text-align:start\"><strong>Voice Search is quite Conversational</strong></h3>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\">Google studies recently found that 70% of searches via the Google assistant are often conversational queries that resembles closely to one person would casually address some other person. Now, as the searches have become more of a conversational search, voice searches are still quite different from the way users now interact with a text search box. To compete for the voice search results, websites will always need to focus on writing content in some conversational tone.</p>\r\n\r\n<h3 style=\"color:rgba(0, 0, 0, 0.8); font-style:normal; margin-left:0px; margin-right:0px; text-align:start\"><strong>On Mobile Phone Devices</strong></h3>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\">Google has also found that almost 20% of mobile queries are now voice searches, and that number will still continue to rise. Having some mobile-friendly website will be quite critical to appear at the start of the voice search results. If you are not optimizing something for the mobile, not only it will be more difficult to rank at some top spot, but all the traffic you have worked hard to achieve from voice searches may end up going away without providing conversion rates.</p>\r\n\r\n<h2 style=\"font-style:normal; margin-left:0px; margin-right:0px; text-align:justify\"><strong>How to Optimize for the Voice Search in 2018</strong></h2>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\">People who use voice search often search the store, product or service near them. From a local search perspective, it is important to use phrases on your site that identify your city and your neighbors.</p>\r\n\r\n<h2 style=\"font-style:normal; margin-left:0px; margin-right:0px; text-align:start\"><strong>Optimize for Long Keywords and Be Conversational at Articles</strong></h2>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\">Sometimes you are looking for conversation questions about your products, services and industry. You can use tools like &ldquo;contact&rdquo; to find the questions that users are following for your topic. Discover the industry and its keywords on your audio device. What types of responses are presented? Does the device respond or offer search results? You may find that you have a lot of competition or you may find that your competitors do not enjoy the opportunity to search for audio.<br />\r\nVoice search uses the natural language of conversation, which means that long-term key phrases are more important than ever. Ask questions about questions that are naturally asked about your business, product or service, ask them and look for ways to combine them in the version of your website.</p>\r\n\r\n<h2 style=\"font-style:normal; margin-left:0px; margin-right:0px; text-align:justify\"><strong>Add an FAQ page on it</strong></h2>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\">An efficient way to use those questions users are commonly searching for is to develop a thorough Frequently Asked Questions Page. You will definitely be able to incorporate all those actual questions users ask their devices with headings, increasing your chances of ranking on top of the queries.</p>\r\n\r\n<h2 style=\"font-style:normal; margin-left:0px; margin-right:0px; text-align:justify\"><strong>Time to Optimize your Google my Business Profile</strong></h2>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\">If users search for popular &ldquo;popularly searched&rdquo; local search words, the optimization of your site will not be excellent. Instead, the device finds the user&rsquo;s location and creates lists of online directories such as Google My Business and Bing Places for Business.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\">Websites want to make sure that their businesses demand and improve these sites from local lists. When setting up or improving Google My Business or Bing Places for business profiles, the first step is to verify your name, address and phone number in the lists. Do not forget to take a look at other online directories. If there are different addresses on different sites, search engines do not know which URLs are correct and will create an opportunity for your voice search results.</p>\r\n', 'image/voice_search.jpg', 'Search Engine Optimization', '2019-07-10 06:19:53'),
(3, 'How Search Engines Work: Everything You Need to Know to Understand Crawlers', '<p style=\"margin-left:0px; margin-right:0px; text-align:justify\"><span style=\"font-family:roboto,Arial,Helvetica,sans-serif !important\">Back in 1996, two Stanford PhDs theorized a new kind of search engine. Instead of ranking results based on how many times a keyword appeared on a webpage, Larry Page and Sergey Brin figured it would be better to rank results based on the relationships between pages. They called their idea &ldquo;BackRub&rdquo; because it ranked search results&nbsp;based on backlinks.</span></p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\"><span style=\"font-family:roboto,Arial,Helvetica,sans-serif !important\">That&rsquo;s pretty different compared to how search engines work today. Page and Brin&rsquo;s search engine, Google, receives&nbsp;5.5 billion searches a day. Or 63,000 searches per second. For every one of those queries, the search engine trawls through more than&nbsp;130 trillion individual pagesinternet-wide and selects results in less than a second.</span></p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\"><span style=\"font-family:roboto,Arial,Helvetica,sans-serif !important\">Behind those results lies a lot of groundwork. While Google &mdash; and other search engines &mdash; is notoriously secretive about the mechanisms behind search results, marketers benefit from knowing how search engines work. Understanding how search engines find, organize, and select results means you can better optimize your web pages to rank.</span></p>\r\n\r\n<h2 style=\"font-style:normal; margin-left:0px; margin-right:0px; text-align:start\"><span style=\"font-family:roboto,Arial,Helvetica,sans-serif !important\"><strong>How Search Engines Work: The Basics</strong></span></h2>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\"><span style=\"font-family:roboto,Arial,Helvetica,sans-serif !important\">A &ldquo;search engine&rdquo; is several interlinked mechanisms that work together to identify pieces of web content &mdash; images, videos, website pages, etc. &mdash; based on the words you type into a search bar. Site owners use&nbsp;<span style=\"font-family:roboto,Arial,Helvetica,sans-serif !important\">Search Engine Optimization</span>&nbsp;to improve the chances that content on their site will show up in search results.</span></p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:start\"><span style=\"font-family:roboto,Arial,Helvetica,sans-serif !important\">Search engines use three basic mechanisms:</span></p>\r\n\r\n<ul>\r\n	<li><span style=\"font-family:roboto,Arial,Helvetica,sans-serif !important\"><strong>Web crawlers</strong>: Bots that continually browse the web for new pages. Crawlers collect the information needed to index a page correctly and use hyperlinks to hop to other pages and index them too.</span></li>\r\n	<li style=\"text-align: justify;\"><span style=\"font-family:roboto,Arial,Helvetica,sans-serif !important\"><strong>Search index</strong>: A record of all web pages online, organized in a way that allows association between keyword terms and page content. Search engines also have ways of grading the quality of content in their indexes.</span></li>\r\n	<li style=\"text-align: justify;\"><span style=\"font-family:roboto,Arial,Helvetica,sans-serif !important\"><strong>Search algorithms</strong>: Calculations that grade the quality of web pages, figure out how relevant that page is to a search term, and determine how the results are ranked based on quality and popularity.</span></li>\r\n</ul>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\"><span style=\"font-family:roboto,Arial,Helvetica,sans-serif !important\">Search engines try to deliver the most useful results for each user to keep large numbers of users coming back time and again. This makes business sense, as most search engines make money through advertising. Google made an impressive&nbsp;$116B in 2018, for example.</span></p>\r\n\r\n<h2 style=\"font-style:normal; margin-left:0px; margin-right:0px; text-align:start\"><span style=\"font-family:roboto,Arial,Helvetica,sans-serif !important\"><strong>How Search Engines Crawl, Index, and Rank Content</strong></span></h2>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\"><span style=\"font-family:roboto,Arial,Helvetica,sans-serif !important\">Search engines look simple from the outside. You type in a keyword, and you get a list of relevant pages. But that deceptively easy interchange requires a lot of computational heavy lifting backstage.</span></p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\"><span style=\"font-family:roboto,Arial,Helvetica,sans-serif !important\">The hard work starts way before you make a search. Search engines work round-the-clock, gathering information from the world&rsquo;s websites and organizing that information, so it&rsquo;s easy to find. This is a three-step process of first&nbsp;<strong>crawling&nbsp;</strong>web pages<strong>, indexing&nbsp;</strong>them, then&nbsp;<strong>ranking</strong>them with search algorithms.</span></p>\r\n\r\n<h3 style=\"color:#1b334b; font-style:normal; text-align:start\"><span style=\"font-family:roboto,Arial,Helvetica,sans-serif !important\"><strong>Crawling</strong></span></h3>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\"><span style=\"font-family:roboto,Arial,Helvetica,sans-serif !important\">Search engines rely on crawlers &mdash; automated scripts &mdash; to scour the web for information. Crawlers start out with a list of websites. Algorithms &mdash; sets of computational rules &mdash; automatically decide which of these sites to crawl. The algorithms also dictate how many pages to crawl and how frequently.</span></p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\"><span style=\"font-family:roboto,Arial,Helvetica,sans-serif !important\">Crawlers visit each site on the list systematically, following links through tags like HREF and SRC to jump to internal or external pages. Over time, the crawlers build an ever-expanding map of interlinked pages.</span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-family:roboto,Arial,Helvetica,sans-serif !important\"><strong>Takeaway for Marketers</strong></span></p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\"><span style=\"font-family:roboto,Arial,Helvetica,sans-serif !important\">Make sure your site is easily accessible to crawlers. If bots can&rsquo;t crawl it, they can&rsquo;t index it, and that means your site won&rsquo;t appear in search results. You can help guarantee crawler accessibility by implementing the following:</span></p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<ul>\r\n	<li style=\"text-align: justify;\"><span style=\"font-family:roboto,Arial,Helvetica,sans-serif !important\"><strong>Logical site hierarchy</strong>: Define a logical site architecture that flows from domain to category to subcategory. This lets crawlers move through your site more quickly, allowing the site to stay within its&nbsp;crawl budget.</span></li>\r\n	<li style=\"text-align: justify;\"><span style=\"font-family:roboto,Arial,Helvetica,sans-serif !important\"><strong>Links</strong>: Use internal on every page. Crawlers need links to move between pages. Pages without any links are un-crawlable and therefore un-indexable.</span></li>\r\n	<li style=\"text-align: justify;\"><span style=\"font-family:roboto,Arial,Helvetica,sans-serif !important\"><strong>XML sitemap</strong>: Make a list of all your website&rsquo;s pages, including blog posts. This list acts as an instruction manual for crawlers, telling them which pages to crawl. There are plugins and tools&mdash;like Yoast and Google XML Sitemaps&mdash;that will generate and update your sitemap when you publish new content.</span></li>\r\n</ul>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n', 'image/how-search-engines-work.png', 'Search Engine Optimization', '2019-07-18 05:56:55'),
(4, 'What are the SEO benefits of social media?', '<p style=\"margin-left:0px; margin-right:0px; text-align:justify\"><strong>How does using&nbsp;social media&nbsp;benefit your efforts with&nbsp;SEO?</strong></p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">Back in 2008,&nbsp;Search Engine&nbsp;Watch published the article &lsquo;Social Media and SEO &ndash; Friends with Benefits&lsquo;, and I&rsquo;d highly recommend reading it back now for a stark reminder of how far the digital world has progressed in the last nine years.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">Some of the key statistics and points featured in the article (although contemporary at the time) may seem somewhat archaic in 2017:</p>\r\n\r\n<ul style=\"list-style-type:square; margin-left:45px; margin-right:5px\">\r\n	<li style=\"text-align: justify;\">Facebook having 140 million active&nbsp;users&nbsp;(when they are now&nbsp;over 2 billion)</li>\r\n	<li style=\"text-align: justify;\">LinkedIn having 30 million users (less than 10% of their&nbsp;current user base)</li>\r\n	<li style=\"text-align: justify;\">Popularity of now defunct social platforms like Digg (which sold for&nbsp;just $500,000&nbsp;back in 2012)</li>\r\n	<li style=\"text-align: justify;\">MySpace being mentioned in the same breath as Facebook, LinkedIn, Reddit and Twitter (ha!)</li>\r\n	<li style=\"text-align: justify;\">Use of &lsquo;SEO&nbsp;friendly&rsquo; anchor text when linking from social profiles (<em>ahem</em>&hellip; &lsquo;money keywords&rsquo;)</li>\r\n</ul>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">Nobody could have guessed what&nbsp;social media&nbsp;would become in such a short amount of time. Nearly a decade later and Facebook is nothing short of a social media superpower, Instagram has grown from&nbsp; <span style=\"background-color:#ffffff; color:#404040; font-family:arial,sans-serif; font-size:14px\">zero to over 700 million users in the space of just seven years, MySpace has fallen out of popularity into the depths of dated pop-culture references, and using &lsquo;SEO friendly&rsquo; anchor text is a very dangerous game to play in light of Google&rsquo;s almighty Penguin updates.</span> It&rsquo;s safe to say that everything is very different now, and as the social media landscape changes so too does its relationship with&nbsp;search engines&nbsp;and&nbsp;SEO&nbsp;practices. But what exactly is this relationship in 2017?</p>\r\n', 'image/social-media-SEO-300x228.jpg', 'Social Media Marketing', '2019-07-18 16:35:59'),
(5, 'm', '', 'image/Microsoft Edge 6_2_2019 12_01_59 PM.png', 'Search Engine Marketing', '2019-07-27 08:15:57');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `category` varchar(60) NOT NULL,
  PRIMARY KEY (`category`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category`) VALUES
('Latest Seo Trend '),
('Search Engine Marketing'),
('Search Engine Optimization '),
('Social Media Marketing');

-- --------------------------------------------------------

--
-- Table structure for table `contact_msg`
--

DROP TABLE IF EXISTS `contact_msg`;
CREATE TABLE IF NOT EXISTS `contact_msg` (
  `enquiry` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phoneno` varchar(15) NOT NULL,
  `url` varchar(100) NOT NULL,
  `message` varchar(2000) NOT NULL,
  `msgdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`enquiry`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `factor`
--

DROP TABLE IF EXISTS `factor`;
CREATE TABLE IF NOT EXISTS `factor` (
  `factorid` int(50) NOT NULL AUTO_INCREMENT,
  `type` varchar(30) NOT NULL,
  `title` varchar(100) NOT NULL,
  `point` varchar(3) NOT NULL,
  `description` varchar(2000) NOT NULL,
  PRIMARY KEY (`factorid`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `factor`
--

INSERT INTO `factor` (`factorid`, `type`, `title`, `point`, `description`) VALUES
(1, 'Keywords', 'Keywords in &lt;title&gt; tag', '+3', '<p style=\"text-align:justify\"><span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">This is one of the most important places to have a keyword because what is written inside the </span>tag shows in search results as your page title. The title tag must be short (6 or 7 words at most) and the the keyword must be near the beginning.</p>\r\n'),
(11, 'Links', 'Anchor text of inbound links', '+3', '<p style=\"text-align:justify\"><span style=\"font-family:arial,sans-serif; font-size:13px\">As discussed in the Keywords section, this is one of the most important factors for good rankings. It is best if you have a keyword in the anchor text but even if you don&#39;t, it is still OK. However, don&#39;t use the same anchor text all the time because this is also penalized by Google. Try to use synonyms, keyword stemming, or simply the name of your site instead</span></p>\r\n'),
(2, 'Keywords', 'Keywords in URL', '+3', '<p style=\"text-align:justify\">Keywords in URLs help a lot - e.g. - http://domainname.com/seo-services.html, where &ldquo;SEO services&rdquo; is the keyword phrase you attempt to rank well for. But if you don&#39;t have the keywords in other parts of the document, don&#39;t rely on having them in the URL</p>\r\n'),
(3, 'Keywords', 'Keyword density in document text', '+3', '<p style=\"text-align:justify\"><span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">Another very important factor you need to&nbsp;</span>check<span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">. 3-7 % for major keywords is best, 1-2 for minor. Keyword density of over 10% is suspicious and looks more like keyword stuffing, than a naturally written text.</span></p>\r\n'),
(4, 'Keywords', ' Keywords in anchor text', '+3', '<p style=\"text-align:justify\">Also very important, especially for&nbsp;the anchor text of inbound links, because if you have the keyword in the anchor text in a link from another site, this is regarded as getting a vote from this site not only about your site in general, but about the keyword in particular</p>\r\n'),
(5, 'Keywords', ' Keywords in headings (&lt;H1&gt;, &lt;H2&gt;, etc. tags)', '+3', '<p style=\"text-align:justify\"><span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">One more place where keywords count a lot. But beware that your page has actual text about the particular keyword.</span></p>\r\n'),
(6, 'Keywords', ' Keywords in the beginning of a document', '+2', '<p style=\"text-align:justify\"><span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">Also counts, though not as much as anchor text, title tag or headings. However, have in mind that the beginning of a document does not necessarily mean the first paragraph &ndash; for instance if you use tables, the first paragraph of text might be in the second half of the table</span></p>\r\n'),
(7, 'Keywords', 'Keywords in &lt;alt&gt; tags', '+2', '<p style=\"text-align:justify\"><span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">Spiders don&#39;t read images but they do read their textual descriptions in the tag, so if you have images on your page, fill in the tag with some keywords about them</span></p>\r\n'),
(8, 'Keywords', 'Keywords in metatags', '+1', '<p style=\"text-align:justify\"><span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">Less and less important, especially for Google. Yahoo! and Bing still rely on them, so if you are optimizing for Yahoo! or Bing, fill these tags properly. In any case, filling these tags properly will not hurt, so do it</span></p>\r\n'),
(9, 'Keywords', 'Keyword proximity', '+1', '<p style=\"text-align:justify\"><span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">Keyword proximity measures how close in the text the keywords are. It is best if they are immediately one after the other (e.g. &ldquo;dog food&rdquo;), with no other words between them. For instance, if you have &ldquo;dog&rdquo; in the first paragraph and &ldquo;food&rdquo; in the third paragraph, this also counts but not as much as having the phrase &ldquo;dog food&rdquo; without any other words in between. Keyword proximity is applicable for keyword phrases that consist of 2 or more words.</span></p>\r\n'),
(10, 'Keywords', ' Keyword phrases', '+1', '<p style=\"text-align:justify\">In addition to keywords, you can optimize for keyword phrases that consist of several words &ndash; e.g. &ldquo;SEO services&rdquo;. It is best when the keyword phrases you optimize for are popular ones, so you can get a lot of exact matches of the search string but sometimes it makes sense to optimize for 2 or 3 separate keywords (&ldquo;SEO&rdquo; and &ldquo;services&rdquo;) than for one phrase that might occasionally get an exact match</p>\r\n'),
(12, 'Links', 'Origin of inbound links', '+3', '<p style=\"text-align:justify\"><span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">Besides the anchor text, it is important if the site that links to you is a reputable one or not. Generally sites with greater Google PR are considered reputable. Links from poor sites and link farms can do real harm to you, so avoid them at all costs.</span></p>\r\n'),
(13, 'Links', 'Links from similar sites', '+3', '<p style=\"text-align:justify\"><span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">Generally the more, the better. But the reputation of the sites that link to you is more important than their number. Also important is their anchor text (and its diversity), the lack/presence of keyword(s) in it, the link age, etc.</span></p>\r\n'),
(14, 'Links', 'Links from .edu and .gov sites', '+3', '<p style=\"text-align:justify\"><span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">These links are precious because .edu and .gov sites are more reputable than .com. .biz, .info, etc. domains. Additionally, such links are hard to obtain.</span></p>\r\n'),
(15, 'Links', 'Number of backlinks', '+3', '<p style=\"text-align:justify\"><span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">Generally the more, the better. But the reputation of the sites that link to you is more important than their number. Also important is their anchor text, is there a keyword in it, how old are they, etc.</span></p>\r\n'),
(16, 'Links', 'Anchor text of internal links', '+3', '<p style=\"text-align:justify\"><span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">This also matters, though not as much as the anchor text of inbound links.</span></p>\r\n'),
(17, 'Select type', 'Around-the-anchor text', '+2', '<p style=\"text-align:justify\"><span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">The text that is immediately before and after the anchor text also matters because it further indicates the relevance of the link &ndash; i.e. if the link is artificial or it naturally flows in the text.</span></p>\r\n'),
(18, 'Links', 'Age of inbound links', '+2', '<p style=\"text-align:justify\"><span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">The older, the better. Getting many new links in a short time suggests buying them.</span></p>\r\n'),
(21, 'Metatags', '&lt;Description&gt;metatag', '+1', '<p style=\"text-align:justify\"><span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">Metatags are becoming less and less important but if there are metatags that still matter, these are the and ones. Use the metatag to write the description of your site. Besides the fact that metatags still rock on Bing and Yahoo!, the metatag has one more advantage &ndash; it sometimes pops in the description of your site in search results.</span></p>\r\n'),
(23, 'Content', 'Unique content', '+3', '<p style=\"text-align:justify\"><span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">Having more content (relevant content, which is different from the content on other sites both in wording and topics) is a real boost for your site&#39;s rankings.</span></p>\r\n'),
(22, 'Keywords', '<Keywords>metatag', '+1', '<p style=\"text-align:justify\"><span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">The metatag also matters, though as all metatags it gets almost no attention from Google and some attention from Bing and Yahoo! Keep the metatag reasonably long &ndash; 10 to 20 keywords at most. Don&#39;t stuff the tag with keywords that you don&#39;t have on the page, this is bad for your rankings.</span></p>\r\n'),
(24, 'Content', 'Frequency of content change', '+3', '<p style=\"text-align:justify\"><span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">Frequent changes are favored. It is great when you constantly add new content but it is not so great when you only make small updates to existing content.</span></p>\r\n'),
(25, 'Visual Extras and SEO', 'JavaScript', '0', '<p style=\"text-align:justify\"><span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">If used wisely, it will not hurt. But if your main content is displayed through JavaScript, this makes it more difficult for spiders to follow and if JavaScript code is a mess and spiders can&#39;t follow it, this will definitely hurt your ratings.</span></p>\r\n'),
(26, 'Visual Extras and SEO', 'Images in text', '0', '<p style=\"text-align:justify\"><span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">Having a text-only site is so boring but having many images and no text is a SEO sin. Always provide in the &lt;alt&gt; tag a meaningful description of an image but don&#39;t stuff it with keywords or irrelevant information.</span></p>\r\n'),
(27, 'Visual Extras and SEO', 'Podcasts and videos', '0', '<p style=\"text-align:justify\"><span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">Podcasts and videos are becoming more and more popular but as with all non-textual goodies, search engines can&#39;t read them, so if you don&#39;t have the tapescript of the podcast or the video, it is as if the podcast or movie is not there because it will not be indexed by search engines.</span></p>\r\n'),
(28, 'Domains, URLs, Web Mastery', 'Keyword-rich URLs and filenames', '+3', '<p style=\"text-align:justify\"><span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">A very important factor, especially for Yahoo! and Bing.</span></p>\r\n'),
(29, 'Select type', 'Site Accessibility', '+3', '<p style=\"text-align:justify\"><span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">Another fundamental issue, which that is often neglected. If the site (or separate pages) is unaccessible because of broken links, 404 errors, password-protected areas and other similar reasons, then the site simply can&#39;t be indexed.</span></p>\r\n'),
(30, 'Domains, URLs, Web Mastery', '	 Sitemap', '+2', '<p style=\"text-align:justify\"><span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">It is great to have a complete and up-to-date&nbsp;</span>sitemap<span style=\"color:#212121; font-family:arial,sans-serif; font-size:13px\">, spiders love it, no matter if it is a plain old HTML sitemap or the special Google sitemap format.</span></p>\r\n'),
(31, 'Select type', 'lj', '8', ''),
(32, 'Select type', 'kjhb', '0', '<p>lkjh</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

DROP TABLE IF EXISTS `faq`;
CREATE TABLE IF NOT EXISTS `faq` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(1000) NOT NULL,
  `answer` varchar(1000) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`questionid`, `question`, `answer`) VALUES
(1, 'What does SEO stand for?', '<p style=\"text-align:justify\"><br />\r\nSEO stands for Search Engine Optimization. You engage in SEO when you attempt to get a page to rank higher in a search engine&acirc;&euro;&trade;s SERPs (search engine results pages), with the ultimate goal being to increase organic (unpaid) traffic to that page.</p>\r\n'),
(2, 'What is on-page SEO?', '<p style=\"text-align:justify\"><br />\r\nOn-page SEO refers to tactics utilized on or within a page to assist it in ranking higher in the search engine. On-page SEO includes both content and the HTML source code of a page (image optimization, keyword optimization, Schema markup, and more), but not external links and other external signals.</p>\r\n'),
(3, 'What is keyword research?', '<p style=\"text-align:justify\"><br />\r\n<br />\r\nGreat question! Keyword research helps you determine the keywords for which you should optimize the current and future pages of your site. For example: if your new small business sells employee scheduling software, but you discover that &acirc;&euro;&oelig;employee scheduling tool&acirc;&euro;Â has higher search volume and lower competition than &acirc;&euro;&oelig;employee scheduling software,&acirc;&euro;Â you might want to change the copy on your website to reflect that. Keyword research is a way of determining which queries people are entering into search engines so you can publish pages that will show up as results for those queries.</p>\r\n'),
(4, 'Where do I put my SEO keywords?', '<p style=\"text-align:justify\"><br />\r\nYou&acirc;&euro;&trade;ve probably heard keyword stuffing is bad, and yes&acirc;&euro;&rdquo;you don&acirc;&euro;&trade;t want to throw in keywords unnaturally. But in general, the keyword your optimizing a page for should appear in the title, in the first paragraph of your intro, in an H2, if you can manage it (ideally in the form of a question!), and sporadically throughout the rest of your post. For reference, &acirc;&euro;&oelig;SEO Keywords&acirc;&euro;Â is the H2 of this section, while the questions themselves are H3s.</p>\r\n'),
(5, 'Will blogging help SEO?', '<p style=\"text-align:justify\"><br />\r\n<br />\r\nYes! Each piece of new content you create is another opportunity to rank for a target keyword related to your business. The more high-quality blogs you create, the wider the net you cast across your industry&acirc;&euro;&trade;s organic search results.</p>\r\n'),
(6, 'Are SEO meta tags important?', '<p style=\"text-align:justify\"><br />\r\nYes! But not all of them. There are four kinds of meta tags: Meta Keywords Attribute &acirc;&euro;&ldquo; A series of keywords you deem relevant to the page in question. Title Tag &acirc;&euro;&ldquo; The title of your page. Meta Description Attribute - A brief description of the page. Meta Robots Attribute - An indication to search engine crawlers (robots or &quot;bots&quot;) as to what they should do with the pag</p>\r\n'),
(7, 'What is robots.txt?', '<p style=\"text-align:justify\">Robots.txt is a text file within your website&acirc;&euro;&trade;s top-level directory that instructs search engines how to crawl your pages.</p>\r\n'),
(8, 'Do categories help SEO?', '<p style=\"text-align:justify\"><br />\r\nYes! Sorting your pages into categories can help prevent individual pages from competing with one another.</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
  `newsid` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(300) NOT NULL,
  `subtitle` varchar(600) DEFAULT NULL,
  `content` varchar(15000) DEFAULT NULL,
  `image` varchar(100) NOT NULL,
  `addedon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`newsid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`newsid`, `title`, `subtitle`, `content`, `image`, `addedon`) VALUES
(1, 'Pinterest Rolls Out a Suite of New Video Tools', 'Pinterest Rolls Out a Suite', '<p style=\"margin-left:0px; margin-right:0px\">Pinterest is&nbsp;rolling out&nbsp;a new set of tools to help businesses keep up with the rising demand for video content.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px\">According to Pinterest, searches for &ldquo;inspirational videos&rdquo; have increased 31% since last year.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px\">The company notes that users also go to the platform looking for how-to videos, tutorials, and brand stories.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px\">To help businesses satisfy this demand, Pinterest is introducing new video features that include:</p>\r\n\r\n<ul style=\"margin-left:0px; margin-right:0px\">\r\n	<li><strong>An improved uploader</strong>: To seamlessly upload video directly to Pinterest.</li>\r\n	<li><strong>A video tab</strong>: To allow brands to feature all their videos in one place.</li>\r\n	<li><strong>Lifetime analytics</strong>: To get insights into the performance of a video over time.</li>\r\n	<li><strong>Pin scheduling</strong>: Businesses and creators can now also schedule video content in advance.</li>\r\n</ul>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">For businesses and creators looking to capitalize on trending video searches, Pinterest highlighted what is currently rising in popularity.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">Trending video searches on Pinterest currently include:</p>\r\n\r\n<ul style=\"margin-left:0px; margin-right:0px\">\r\n	<li style=\"text-align: justify;\">Overnight oats videos (up 3712%)</li>\r\n	<li style=\"text-align: justify;\">Lasagna recipe videos (up 3462%)</li>\r\n	<li style=\"text-align: justify;\">Makeup tutorial videos (up 2063%)</li>\r\n	<li style=\"text-align: justify;\">Hair dye videos (up 276%)</li>\r\n	<li style=\"text-align: justify;\">Curling hair with flat iron videos (up 129%)</li>\r\n</ul>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">The updates are available for business accounts in all English-speaking countries, and will eventually roll out to creators worldwide.</p>\r\n\r\n<p>&nbsp;</p>\r\n', 'image/pinterest.png', '2019-07-11 05:51:12'),
(2, 'Googleâ€™s John Mueller Explains How Pages Blocked by Robots.txt Are Ranked', 'How Pages Blocked by Robots.txt Are Ranked', '<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">Google&rsquo;s John Mueller recently explained how query relevancy is determined for pages blocked by robots.txt.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">It has&nbsp;been stated&nbsp;that Google will still index pages that are blocked by robots.txt. But how does Google know what types of queries to rank these pages for?</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">That&rsquo;s the question that came up in yesterday&rsquo;s Google Webmaster Central hangout:</p>\r\n\r\n<blockquote>\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">&ldquo;Nowadays everyone talks about user intent. If a page is blocked by robots.txt, and is ranking, how does Google determine the query relevancy with page content as it&rsquo;s blocked?&rdquo;</p>\r\n</blockquote>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px\">In response, Mueller says Google obviously cannot look at the content if it&rsquo;s blocked.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px\">So what Google does is find other ways to compare the URL with other URLs, which is admittedly much harder when blocked by robots.txt.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px\">In most cases, Google will prioritize the indexing of other pages of a site that are more accessible and not blocked from crawling.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px\">Sometimes pages blocked by robots.txt will rank in search results if Google considers them worthwhile. That&rsquo;s determined by the links pointing to the page.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px\">So how does Google figure out how to rank blocked pages? The answer comes down to links.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px\">Ultimately, it wouldn&rsquo;t we wise to block content with robots.txt and hope Google knows what to do with it.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px\">But if you happen to have content that is blocked by robots.txt, Google will do its best to figure out how to rank it.</p>\r\n\r\n<blockquote>\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">&ldquo;If it&rsquo;s blocked by robots.txt, then obviously we can&rsquo;t look at the content. So we do have to kind of improvise and find ways to compare that URL with other URLs that are kind of trying to rank for these queries, and that is a lot harder.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">Because it&rsquo;s a lot harder it&rsquo;s also something where, if you have really good content that is available for crawling and indexing, then usually that&rsquo;s something we would try to kind of use instead of a random robotted page.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">So, from that point of view, it&rsquo;s not that trivial. We do sometimes show robotted pages in the search results just because we&rsquo;ve seen that they work really well. When people link to them, for example, we can estimate that this is probably something worthwhile, all of these things.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">So it&rsquo;s something where, as a site owner, I wouldn&rsquo;t recommend using robots.txt to block your content and hope that it works out well. But if your content does happen to be blocked by robots.txt we will still try to show it somehow in the search results.&rdquo;</p>\r\n</blockquote>\r\n\r\n<p>&nbsp;</p>\r\n', 'image/google_news.png', '2019-07-11 06:00:25'),
(3, 'Microsoft Advertising Rolls Out Tool That Creates Hundreds of Ad Variations', 'Advertisers can set up their ads to change based on a number of targeting options such as location, audience lists, device, search queries, time of day, and others', '<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">Microsoft Advertising is introducing&nbsp;ad customizers&nbsp;which help reduce setup time and are also said to improve ad quality.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">Ad customizers allow advertisers to create hundreds of different variations of a single ad.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">Microsoft explains the technicalities of how ad customizers work:</p>\r\n\r\n<blockquote>\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">&ldquo;Ad customizers are parameters within the ad copy which get replaced by dynamic text when the ad is displayed for the user. The text values are provided in the feed file and they are selected based on the targeting defined in the feed.&rdquo;</p>\r\n</blockquote>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">The parameters in the ad copy follow this format, Microsoft continues to explain:</p>\r\n\r\n<blockquote>\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">&ldquo;{=FeedName.AttributeName: Default}. If your feed name is &ldquo;Deals&rdquo; and you want to reference the custom attribute &ldquo;Product (text)&rdquo;, the parameter would be {=Deals.Product}&rdquo;</p>\r\n</blockquote>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">Advertisers can set up their ads to change based on a number of targeting options such as location, audience lists, device, search queries, time of day, and others.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">As an example, to modify ad text based on user location, you would start by creating a feed with &lsquo;Target Location&rsquo; attribute.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">Different ad copy can be assigned to specific target locations, which will allow variations of ad copy to be served depending on where the searcher is located.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">Advertisers can get started with ad customizers by constructing a customizer feed and uploading it to their account via the Feed Management Tool under Shared Library.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">Then create Expanded Text Ads with the reference to the ad customizer parameters in the ad copy.</p>\r\n\r\n<p style=\"margin-left:0px; margin-right:0px; text-align:justify\">For more information about how to create an ad customizer feed, see Microsoft&rsquo;s&nbsp;help page.</p>\r\n', 'image/shutterstock_1390179350-1-1520x800.png', '2019-07-11 06:05:11');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
CREATE TABLE IF NOT EXISTS `questions` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(300) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`questionid`, `question`, `email`) VALUES
(1, 'how does seo works\r\n', 'vikaskumar7321@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
CREATE TABLE IF NOT EXISTS `review` (
  `reviewid` int(11) NOT NULL AUTO_INCREMENT,
  `reviews` varchar(1000) NOT NULL,
  `reviewby` varchar(100) NOT NULL,
  `reviewdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`reviewid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`reviewid`, `reviews`, `reviewby`, `reviewdate`) VALUES
(1, 'As', '1', '2019-07-25 07:49:49'),
(2, 'jhgvhb', '5', '2019-07-27 08:06:57'),
(3, '', '5', '2019-07-27 08:07:06'),
(4, '', '5', '2019-07-27 08:08:06');

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
CREATE TABLE IF NOT EXISTS `team` (
  `memberid` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `about` varchar(1000) NOT NULL,
  `image` varchar(100) NOT NULL,
  `emailid` varchar(50) NOT NULL,
  `phoneno` varchar(20) NOT NULL,
  `worktype` varchar(100) NOT NULL,
  PRIMARY KEY (`memberid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `term`
--

DROP TABLE IF EXISTS `term`;
CREATE TABLE IF NOT EXISTS `term` (
  `termid` int(11) NOT NULL AUTO_INCREMENT,
  `term` varchar(1000) NOT NULL,
  `description` varchar(2000) NOT NULL,
  PRIMARY KEY (`termid`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `term`
--

INSERT INTO `term` (`termid`, `term`, `description`) VALUES
(1, 'Alt Attribute', '<p style=\"text-align:justify\">The &quot;alt attribute&quot; or &quot;alt text&quot; is used to indicate the alternative textual information which is to be displayed instead of an image in case the subject image cannot be rendered by the browser.<br />\r\nExample: &lt;img src=&quot;https://www.example.com/images/test.gif&quot; alt=&quot;The alt text for the image goes here&quot;&gt;</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n'),
(2, ' Analytics', '<p style=\"text-align:justify\"><br />\r\nAnalytics or website analytics refers to the collection, organization, and presentation of website traffic and user activity data through a script/software. The data gathered is used to track the performance of the site, and also help improve the functionality, and conversion rate of the website.<br />\r\n&nbsp;</p>\r\n'),
(3, 'Anchor Text', '<p><br />\r\nThe visible, clickable text in a hyperlink is called the &quot;anchor text&quot;. The anchor text is generally a descriptive term which tells the user the topic or name of the destination page.<br />\r\nExample: &lt;a href=&quot;http://www.evoba.com&quot;&gt;Search Engine Optimization Company&lt;/a&gt;<br />\r\nIn this example &quot;Search Engine Optimization Company&quot; is the anchor text.</p>\r\n'),
(4, 'Black Hat SEO', '<p style=\"text-align:justify\"><br />\r\nBlack hat SEO is the practice of manipulating search engine rankings by utilizing methods which are against the general guidelines set forth by the major search engines. These practices are designed to circumvent the algorithmic safeguards developed by the search engines, helping websites gain high rankings in search engine result pages without having the intrinsic merits to do so without such tactics.</p>\r\n'),
(5, 'White Hat SEO', '<p style=\"text-align:justify\"><br />\r\n<br />\r\nWhite has SEO is the process by which websites can gain higher organic rankings in search engine result pages. White hat SEO activities fall within the guidelines set forth by the major search engines, and do not utilize questionable methods to trick search engine algorithms to gain an unfair advantage over competing websites.</p>\r\n'),
(6, 'Borken Link', '<p style=\"text-align:justify\"><br />\r\nA broken link is a link which no longer works, due to a variety of causes, often resulting in an error page. A broken is caused by several reasons. The most common result of a dead (broken) link is a 404 error, which indicates that even though the web server where the request was sent to responded, the specific page requested could not be found. A broken link which results in a DNS error is caused when the server which hosts the target page no longer works or has been moved to a different domain name.</p>\r\n'),
(7, 'Cache', '<p style=\"text-align:justify\"><br />\r\nCache or &quot;web cache&quot; is the temporarily stored copy of a web document such as an HTML file, PDF document, image, etc (or a combination thereof). Search engines use such copies of web pages to facilitate their search functionality. The cached files in the search engine indices allow users to search for web pages and documents a copy of which has been cached (saved) by the search engines for this purpose.<br />\r\n&nbsp;</p>\r\n'),
(8, 'Canonical URL', '<p style=\"text-align:justify\"><br />\r\nCanonical URLs or &quot;canonicalization&quot; refers to the elimination of duplicate content through the designation of one version of a particular page of data as the dominant (authoritative) one. For example, in an ecommerce website, a certain set of products can be organized in a variety of ways on a search results page, creating pages which have the same exact content but have different URLs. To fix this, a canonical tag is added to the non-primary pages which tells the search engines where to find the primary page of content.</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n'),
(9, 'Cloaking', '<p style=\"text-align:justify\"><br />\r\nCloaking is the practice of serving (displaying) content to search engines which is different than that served to regular website users. Generally, in the world of Black Hat SEO, cloaking is used to manipulate search engine rankings; however, there are legitimate uses (e.g., location based content variations) of cloaking which are within search engine guidelines.<br />\r\n&nbsp;</p>\r\n'),
(10, 'Content Management System (CMS)', '<p style=\"text-align:justify\">As the name suggests, a CMS or content management system is a set of scripts which work as a unit to enable management and manipulation of web content.<br />\r\nContent management systems come in a variety of flavors and include commercial as well as open-source options. One of the most well-known and widely used open-source content management systems is WordPress. Though it started as a blogging platform, it has grown to be a tremendously powerful content management system.</p>\r\n'),
(11, 'Cookie', '<p style=\"text-align:justify\">A cookie is a small text file which stores data about the user on his local machine. The cookie can be used to store a variety of information including the contents of a user&#39;s shopping cart, the login status, and website preferences.<br />\r\nCookies are often cited as a privacy concern, but are an essential part of utilizing the web and the many services offered by websites.</p>\r\n'),
(12, 'Crawl Depth', '<p style=\"text-align:justify\">Crawl depth is the depth to which a website is crawled by a search engine. Depth is the degrees of separation as measured by the number of clicks (through links) it takes to get to a particular page from the home page of a website. Since search engine spiders follow links to discover pages, the deeper a search engine spider is willing to go into a site the more content it is able to find. Search engines determine the crawl depth of each website based on the authority assigned to it by the search algorithm--higher quality sites are rewarded by a deeper crawl which in turn makes more of their content available to searchers through a search engine&#39;s index.</p>\r\n'),
(13, 'Crawl Frequency', '<p style=\"text-align:justify\">Crawl frequency is the frequency by which a website is crawled. Generally, most sites/pages are on a 30-day crawl cycle, which means that the site will get crawled every thirty days. This does not necessarily mean that the entire site will be crawled in one day, but that each page of the website will get recrawled about thirty days after the last crawl.<br />\r\nLike crawl depth, crawl frequency is determined by the search engine algorithm and the value which it assigns to a particular page or website. For example, if a website is updated often, and is given &#39;enough&#39; value by the algorithm, the crawl frequency of the site may be as high as hourly or it may even be measured in minutes.</p>\r\n'),
(14, 'Deep Link', '<p style=\"text-align:justify\">Deep links are important as they are specifically targeted to deep content, and not just the home page of the website. Deep links are generally highly relevant as they point from closely relevant pages. Also, the typical link profile of a high quality website will have a variety of deep links and not just links pointing to the home page, so many webmasters attempt to mimic this phenomenon when working to acquire links for their websites.</p>\r\n'),
(15, 'Directory', '<p style=\"text-align:justify\">A catalog of websites which is generally categorized by topic. High quality directories are manually organized and have editorial experts which vet submissions based on specific criteria. There are a variety of directories including general directories which have a multitude of general categories. There are also niche directories which cater to specific industries or groups.</p>\r\n'),
(16, 'Doorway Pages', '<p style=\"text-align:justify\">A doorway page is a webpage which is designed to rank for a small number of highly targeted keywords, but has no logical place in the hierarchy of a website. Doorway pages funnel traffic to other parts of a website which usually are filled with ads or a facility to help the owner of the page make money from the traffic. Since these types of doorway pages are generally of low or no value to the user, search engines take great measures to algorithmically find and penalize such pages and sites; however, since it takes time for the search engines to catch on to such schemes, the owners of such pages continue to develop new pages/sites solely for this purpose, and run the websites/pages until the search engines penalize/ban them, and then they move on to a new website and a new set of doorway pages.</p>\r\n'),
(17, 'Duplicate Content', '<p style=\"text-align:justify\">Duplicate content is content which is duplicated across two or more pages on one or more websites. Duplicate content can include text, images, and file names.<br />\r\nDuplicate content is undesirable as it is demoted by search engine algorithms, so it is important for a website to avoid the creation of duplicate content whether by design or accident. Many websites fall prey to a duplicate content penalty by inadvertently creating duplicate content by such features as sorting through HTML links, and printer friendly pages.</p>\r\n'),
(18, ' Editorial Link', '<p style=\"text-align:justify\">Editorial links are those which are earned based on a websites merits and generally without direct solicitation. Search engines want to see these types of links, and value them highly, which in turn can result in improved search engine rankings.<br />\r\n&nbsp;</p>\r\n'),
(19, 'External Links', '<p style=\"text-align:justify\">An external link is a hyperlink from a website which points outside the domain of origin. For example, on our site we have several links pointing to SEO-related resources on Google...those are external links. External links can be a helpful signal for search engines to determine the topic of a website, assuming the links are pointing to relevant resources and are designed to help users find answers or solve a problem.</p>\r\n'),
(20, 'FFA Directories or Pages (Free for All)', '<p style=\"text-align:justify\">An FFA (Free for all) directory or page is a web property which allows anyone to add a link. These types of links are considered highly undesirable as these pages can be easily spammed and thus hold very low (if any) value when it comes to helping improve organic search engine rankings.</p>\r\n'),
(22, 'Flash', '<p style=\"text-align:justify\">Flash is a vector graphic-based software which facilitates the creation of highly interactive and rich-looking websites. Flash is owned by Adobe and is widely supported by browsers and platforms; however, currently Apple&#39;s mobile devices do not support Flash.<br />\r\nWebsites which are developed entirely in Flash have a tough time gaining high rankings in search engines as search engine algorithms have very little on which to base ranking decisions. So it is recommended that if you will be utilizing Flash to ensure that your website is not made in its entirety with Flash software, and only uses Flash elements.</p>\r\n'),
(23, 'Fresh Content', '<p style=\"text-align:justify\">Fresh content is newly developed content which has hitherto not been published anywhere on the web. Fresh content is beneficial in helping attract attention to a website, whether the attention is given by users or search engines. The re-editing of old content does not make it fresh.<br />\r\nFresh content provides a variety of advantages including, growing archive of content (which will improve ranking possibilities), can coax the search engines to crawl your website more often (to find new content), and giving people a reason to return to your website.</p>\r\n'),
(24, 'Fuzzy Search', '<p style=\"text-align:justify\">Fuzzy search is the technology which helps retrieve relevant results even if the search terms are misspelled (or fuzzy).</p>\r\n'),
(25, 'FTP', '<p style=\"text-align:justify\">FTP (or File Transfer Protocol) is a protocol for transferring data between two or more computers. FTP capabilities are built into many pieces of software such as Dreamweaver (a web development software). FTP software is also available as a standalone tools which allows for transfer of files between computers, and is mostly used by web developers to transfer files from local machines to web servers.<br />\r\n&nbsp;</p>\r\n'),
(26, 'Sitemap', '<p style=\"text-align:justify\">A sitemap is a list of pages (usually only the important ones) of a website which is accessible to search engine spiders and users. Usually it is coded in an HTML format; however, sitemaps which are submitted directory to search engines (e.g., Google Sitemaps) are coded in XML.</p>\r\n'),
(27, 'Hidden Text', '<p style=\"text-align:justify\">Using hidden text on web pages is a risky SEO technique which is basically the process of hiding optimized, and often voluminous text stuffed with keywords from regular website visitors while still accessible to search engine spiders.<br />\r\nThis approach goes against search engine guidelines and will (once discovered) get a website banned from search engines.</p>\r\n'),
(28, 'HTML', '<p style=\"text-align:justify\">HTML Stands for HyperText Markup Language. HTML is the markup language by which most website pages are created.</p>\r\n'),
(29, 'Inbound Links', '<p style=\"text-align:justify\">Inbound links are links which point from one website to another. The link terminology is subjective, since the website receiving the link would describe it as an inbound link, and the website providing the link would describe it as an outbound link.</p>\r\n'),
(30, 'Information Architecture', '<p style=\"text-align:justify\">Information Architecture (AI) is the art/craft/science of developing a user-interface, and organizational structure for websites to improve user-experience (UX).<br />\r\n&nbsp;</p>\r\n'),
(31, 'Keyword', '<p style=\"text-align:justify\">A keyword in the online marketing context is a keyword or phrase which describe a product, service, or piece of information that a user with a specific intention (i.e., buying, or learning) will use to query the index of a search engine.<br />\r\n&nbsp;</p>\r\n'),
(32, 'Keyword Density', '<p style=\"text-align:justify\">An outdated measure of the relevancy of a page for a search term based on the frequency with which the keyword or phrase appeared on a particular page. This measure of optimization and relevancy is no longer a valid technique as it can be easily manipulated.</p>\r\n'),
(33, 'Keyword Research', '<p style=\"text-align:justify\"><br />\r\nThe process of researching and discovering keyword and keyword phrases relevant to the topic at hand. The keywords are then used to develop an SEO and PPC campaign and strategy.</p>\r\n'),
(34, 'Link Building', '<p style=\"text-align:justify\"><br />\r\nThe process of acquiring inbound links for a website in order to positively impact its search engine rankings. Not every type of link is considered high quality so link building can be a laborious and time-consuming process, since the links which are worth having can only be obtained by providing high quality, useful, and/or engaging content.</p>\r\n'),
(35, 'Link Farm', '<p style=\"text-align:justify\">One or more websites which provide linking opportunities and exercise virtually no editorial control over listings within the site or collection.<br />\r\n&nbsp;</p>\r\n'),
(36, 'Link Popularity', '<p style=\"text-align:justify\">A measure of the number of inbound links that a particular page or website has.</p>\r\n'),
(37, ' Long Tail', '<p style=\"text-align:justify\">Describes a search term which is more specific but has a much smaller search volume compared to the main keywords of a category of keywords. For example, a &#39;green widget&#39; being one of the top keywords in a category would have related long tails such as &#39;custom wooden dark green widget&#39;, which has a relatively small number of searches but is much more descriptive/specific.<br />\r\nThough long tail keywords have small number of searches individually, they comprise the majority of the searches conducted in the search engines.<br />\r\n&nbsp;</p>\r\n'),
(38, 'Meta Refresh', '<p style=\"text-align:justify\">Meta Refresh is a meta tag which is used to make a browser refresh (this is not a redirect) to another URL.</p>\r\n'),
(39, 'Meta Tags', '<p>The term meta tags is generally used to refer to three of the multiple possible head tags which can be found in an HTML document: meta description, meta keywords, and title tag.</p>\r\n'),
(40, 'Meta Keywords', '<p style=\"text-align:justify\">Meta Keywords is a meta tag which can be used to provide the search engines a list of keywords relevant to a page&#39;s topic. The meta keywords tag has very (if any) impact on search results nowadays.</p>\r\n'),
(41, 'Organic Search Results', '<p>Organic search results refer to the portion of results on the search engine result pages which are unpaid. These listings are distinct from the paid ones which generally appear on the top, right, and bottom of the organic listings.<br />\r\n&nbsp;</p>\r\n'),
(42, ' PageRank', '<p style=\"text-align:justify\">PageRank is a value between 0 and 1 which is assigned to a web document by the Google algorithm, which is one of the measures used to determine the value/relevancy of a page in relation to a particular search term. PageRank is distinct from Toolbar PageRank which is a value between 0 and 10 assigned algorithmically by Google which indicates the importance of a page as determined by the Google algorithm. The Toolbar PageRank is updated a few times per year</p>\r\n'),
(43, ' Paid Inclusion', '<p style=\"text-align:justify\">Paid Inclusion is the process of obtaining listings on web properties such as business directories by paying a fee and going through an editorial review process.</p>\r\n'),
(44, 'Reciprocal Link', '<p style=\"text-align:justify\">Reciprocal Link is the practice of exchanging links in hopes of gaining better rankings in the search engine results pages. Basically, the idea is that &quot;I&#39;ll link to you if you link to me&quot;. This generally results in a low quality link profile and not much (if any) improvement in rankings, especially if the only incoming links to a site are based on a reciprocal linking scheme.<br />\r\n&nbsp;</p>\r\n'),
(45, 'Redirect', '<p style=\"text-align:justify\">A redirect is the process of redirecting a search engine spider or web browser from one location on a site to another location on the same site (or outside). There are two types of important redirect:<br />\r\n301: Moved Permanently - this is the preferred method of page redirection, especially for SEO purposes as it helps pass along any link/authority value the page has to its new location.<br />\r\n302: Moved Temporarily - this redirect reports that the page being requested from the server has been found, but has temporarily been relocated to a new URL.</p>\r\n'),
(46, 'Reputation Management', '<p style=\"text-align:justify\">Reputation Management is the exercise of ensuring that the message of your company/brand is prominent in search results when a search is conducted for your company/brand name or any other recognizable product, trademark, or copyright. Reputation management is also possible for individuals who are looking to protect their name.</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n'),
(47, 'robots.txt', '<p style=\"text-align:justify\">robots.txt is a file which is/should be placed in the root folder of a website and provides directives for the search engines as to which pages of the site should not be indexed.</p>\r\n'),
(48, 'Search Engine Optimization (SEO)', '<p style=\"text-align:justify\">Search engine optimization is the art (and science) of presenting information to the search engines in a manner which helps the search engine algorithms best understand the relevance of a website&#39;s content to search queries being conducted by search engine users.<br />\r\n&nbsp;</p>\r\n'),
(49, 'SERP', '<p style=\"text-align:justify\">Search Engine Result Page or SERP refers to the page which displays information generated based on a search query entered into the search engine.</p>\r\n'),
(50, 'Title', '<p style=\"text-align:justify\">The title or title tag of a web page is used to describe the content of a webpage. Page titles appear in the search results as links which point searchers to the resulting pages which the search engine found to be relevant to the search conducted by the searcher.</p>\r\n'),
(51, 'TrustRank', '<p style=\"text-align:justify\">TrustRank is the process of algorithmically (but through the initial help of human vetted web properties) separating good quality pages and spam by evaluating linking relationships.</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `usage_rec`
--

DROP TABLE IF EXISTS `usage_rec`;
CREATE TABLE IF NOT EXISTS `usage_rec` (
  `us_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `userid` varchar(50) NOT NULL,
  `use_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `url` varchar(1000) NOT NULL,
  `status` varchar(8) NOT NULL DEFAULT 'active',
  PRIMARY KEY (`us_id`)
) ENGINE=MyISAM AUTO_INCREMENT=106 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usage_rec`
--

INSERT INTO `usage_rec` (`us_id`, `title`, `userid`, `use_date`, `url`, `status`) VALUES
(1, 'sourcecode', '1', '2019-07-14 05:12:57', 'http://www.google.com', 'hide'),
(2, 'sourcecode', '1', '2019-07-15 06:56:01', 'http://www.google.com', 'hide'),
(3, 'sourcecode', '1', '2019-07-15 07:01:34', 'http://www.google.com', 'hide'),
(4, 'sourcecode', '1', '2019-07-16 05:58:16', 'http://www.google.com', 'hide'),
(5, 'sourcecode', '1', '2019-07-16 05:59:34', 'http://www.google.com', 'hide'),
(6, 'sourcecode', '1', '2019-07-16 06:02:40', 'http://khalsacollege.edu.in/', 'hide'),
(7, 'sourcecode', '1', '2019-07-16 06:07:47', 'http://www.google.com', 'hide'),
(8, 'sourcecode', '1', '2019-06-16 06:08:00', 'http://khalsacollege.edu.in/', 'hide'),
(9, 'sourcecode', '1', '2019-07-16 06:21:27', 'http://cacms.in/', 'hide'),
(10, 'sourcecode', '1', '2019-07-16 06:23:45', 'http://cacms.in/', 'hide'),
(11, 'sourcecode', '1', '2019-07-16 06:24:23', 'http://khalsacollege.edu.in/', 'hide'),
(12, 'sourcecode', '1', '2019-06-16 06:27:38', 'http://khalsacollege.edu.in/', 'hide'),
(13, 'sourcecode', '1', '2019-06-16 06:28:30', 'https://facebook.com/', 'hide'),
(14, 'sourcecode', '1', '2019-07-16 06:28:48', 'http://sbi.co.in/', 'hide'),
(15, 'sourcecode', '1', '2019-07-16 06:29:09', 'http://cacms.in/', 'hide'),
(16, 'sourcecode', '1', '2019-07-16 06:38:34', 'http://cacms.in/', 'hide'),
(17, 'sourcecode', '1', '2019-07-16 06:41:28', 'http://cacms.in/', 'hide'),
(18, 'sourcecode', '1', '2019-07-16 06:44:00', 'http://cacms.in/', 'hide'),
(19, 'sourcecode', '1', '2019-07-16 06:47:04', 'http://cacms.in/', 'hide'),
(20, 'sourcecode', '1', '2019-07-16 06:51:29', 'http://cacms.in/', 'hide'),
(21, 'inline_css_test', '1', '2019-07-16 06:57:22', 'http://cacms.in/', 'hide'),
(22, 'sourcecode', '1', '2019-07-16 07:10:28', 'http://cacms.in/', 'hide'),
(23, 'inline_css_test', '1', '2019-06-16 15:29:54', 'http://khalsacollege.edu.in/', 'hide'),
(24, 'inline_css_test', '1', '2019-05-16 15:33:51', 'http://khalsacollege.edu.in/', 'hide'),
(25, 'inline_css_test', '1', '2019-07-16 15:34:32', 'http://khalsacollege.edu.in/', 'hide'),
(26, 'inline_css_test', '1', '2019-07-16 15:38:02', 'http://khalsacollege.edu.in/', 'hide'),
(27, 'inline_css_test', '1', '2019-07-16 15:38:46', 'http://cacms.in/', 'hide'),
(28, 'inline_css_test', '1', '2019-07-16 15:39:23', 'http://khalsacollege.edu.in/', 'hide'),
(29, 'sourcecode', '1', '2019-07-16 15:39:58', 'http://khalsacollege.edu.in/', 'hide'),
(30, 'sourcecode', '1', '2019-07-16 15:42:09', 'http://khalsacollege.edu.in/', 'hide'),
(31, 'sourcecode', '1', '2019-07-16 15:52:35', 'http://khalsacollege.edu.in/', 'hide'),
(32, 'sourcecode', '1', '2019-07-17 05:09:53', 'http:/google.com', 'hide'),
(33, 'sourcecode', '1', '2019-07-17 05:10:22', 'http://cacms.in/', 'hide'),
(34, 'sourcecode', '1', '2019-07-17 05:12:09', 'http://cacms.in', 'hide'),
(35, 'sourcecode', '1', '2019-07-17 05:12:43', 'http://cacms.in/', 'hide'),
(36, 'sourcecode', '1', '2019-07-17 05:16:21', 'http://cacms.in/', 'hide'),
(37, 'sourcecode', '1', '2019-07-17 05:16:27', 'http://cacms.in/', 'hide'),
(38, 'sourcecode', '1', '2019-07-17 05:17:23', 'http://cacms.in/', 'hide'),
(39, 'sourcecode', '1', '2019-07-17 05:19:36', 'http://instagram.com', 'hide'),
(40, 'sourcecode', '1', '2019-07-17 05:19:52', 'http://instagram.com/', 'hide'),
(41, 'sourcecode', '1', '2019-07-17 05:20:05', 'https://instagram.com/', 'hide'),
(42, 'sourcecode', '1', '2019-07-17 05:20:27', 'http://instagram.in/', 'hide'),
(43, 'sourcecode', '1', '2019-07-17 05:23:27', 'http://www.khalsacollege.edu.in/', 'hide'),
(44, 'sourcecode', '1', '2019-07-17 05:24:29', 'http://www.khalsacollege.edu.in/', 'hide'),
(45, 'sourcecode', '1', '2019-07-17 05:47:32', 'http://cacms.in', 'hide'),
(46, 'sourcecode', '1', '2019-07-17 05:47:42', 'http://cacms.in/', 'hide'),
(47, 'sourcecode', '1', '2019-07-17 05:47:53', 'http://www.khalsacollege.edu.in/', 'hide'),
(48, 'sourcecode', '1', '2019-07-17 05:50:01', 'http://www.khalsacollege.edu.in/', 'hide'),
(49, 'sourcecode', '1', '2019-07-17 05:50:31', 'http://www.khalsacollege.edu.in/', 'hide'),
(50, 'sourcecode', '1', '2019-07-17 05:54:31', 'http://www.khalsacollege.edu.in/', 'hide'),
(51, 'sourcecode', '1', '2019-07-17 05:56:02', 'http://www.khalsacollege.edu.in/', 'hide'),
(52, 'sourcecode', '1', '2019-07-17 05:58:47', 'http://cacms.in/', 'hide'),
(53, 'sourcecode', '1', '2019-07-17 05:59:56', 'http://cacms.in/', 'hide'),
(54, 'sourcecode', '1', '2019-07-17 06:02:29', 'http://cacms.in/', 'hide'),
(55, 'sourcecode', '1', '2019-07-17 06:04:00', 'http://cacms.in/', 'hide'),
(56, 'sourcecode', '1', '2019-07-17 06:04:27', 'http://cacms.in/', 'hide'),
(57, 'sourcecode', '1', '2019-07-17 06:05:19', 'http://www.khalsacollege.edu.in/', 'hide'),
(58, 'sourcecode', '1', '2019-07-17 17:11:08', 'http://khalsacollege.edu.in/', 'hide'),
(59, 'sourcecode', '1', '2019-07-18 05:30:44', 'http://khalsacollege.edu.in/', 'hide'),
(60, 'sourcecode', '1', '2019-07-18 15:58:30', 'http://cacms.in/', 'hide'),
(61, 'sourcecode', '1', '2019-07-18 15:58:59', 'http://cacms.in/', 'hide'),
(62, 'sourcecode', '1', '2019-07-18 15:59:43', 'http://cacms.in/', 'hide'),
(63, 'inline_css_test', '1', '2019-07-18 16:03:05', 'http://cacms.in/', 'hide'),
(64, 'sourcecode', '1', '2019-07-18 16:03:28', 'http://cacms.in/', 'hide'),
(65, 'sitemap_test', '1', '2019-07-18 16:04:30', 'http://cacms.in/', 'hide'),
(66, 'sourcecode', '1', '2019-07-18 16:04:38', 'http://cacms.in/', 'hide'),
(67, 'sourcecode', '1', '2019-07-18 16:05:11', 'http://cacms.in/', 'hide'),
(68, 'sitemap_test', '1', '2019-07-19 05:52:43', 'http://cacms.in/', 'hide'),
(69, 'sitemap_test', '1', '2019-07-19 05:54:55', 'http://cacms.in/', 'hide'),
(70, 'sitemap_test', '1', '2019-07-19 05:59:09', 'http://cacms.in/', 'hide'),
(71, 'sitemap_test', '1', '2019-07-19 05:59:37', 'http://khalsacollege.edu.in/', 'hide'),
(72, 'sitemap_test', '1', '2019-07-19 05:59:46', 'http://khalsacollege.edu.in/', 'hide'),
(73, 'sitemap_test', '1', '2019-07-19 05:59:56', 'http://sbi.co.in/', 'hide'),
(74, 'sitemap_test', '1', '2019-07-19 06:00:05', 'http://cacms.in/', 'hide'),
(75, 'sitemap_test', '1', '2019-07-19 06:00:12', 'http://sbi.co.in/', 'hide'),
(76, 'sitemap_test', '1', '2019-07-19 06:47:02', 'http://cacms.in/', 'hide'),
(77, 'sourcecode', '1', '2019-07-19 12:19:22', 'http://cacms.in/', 'hide'),
(78, 'sourcecode', '1', '2019-07-19 12:19:27', 'http://cacms.in/', 'hide'),
(79, 'sourcecode', '1', '2019-07-19 12:20:00', 'http://cacms.in/', 'hide'),
(80, 'sourcecode', '1', '2019-07-19 12:27:30', 'http://cacms.in/', 'hide'),
(81, 'sourcecode', '1', '2019-07-22 07:12:06', 'http://khalsacollege.edu.in/', 'hide'),
(82, 'image', '1', '2019-07-22 07:12:38', 'http://khalsacollege.edu.in/', 'hide'),
(83, 'image', '1', '2019-07-22 07:16:46', 'http://khalsacollege.edu.in/', 'hide'),
(84, 'inline_css_test', '1', '2019-05-16 15:29:54', 'http://khalsacollege.edu.in/', 'hide'),
(85, 'inline_css_test', '1', '2019-06-16 15:29:54', 'http://khalsacollege.edu.in/', 'hide'),
(86, 'image_alt', '1', '2019-07-25 08:51:03', 'http://cacms.in/', 'active'),
(87, 'meta_tag', '1', '2019-07-25 08:52:34', 'http://cacms.in/', 'active'),
(88, 'inline_css', '1', '2019-06-16 15:29:54', 'http://khalsacollege.edu.in/', 'hide'),
(89, 'sourcecode', '1', '2019-07-25 16:40:14', 'http://cacms.in/', 'active'),
(90, 'link_extractor', '1', '2019-07-25 16:40:50', 'http://cacms.in/', 'active'),
(91, 'meta_tag', '1', '2019-07-25 16:45:44', 'http://khalsacollege.edu.in/', 'active'),
(92, 'meta_tag', '1', '2019-07-25 16:46:57', 'http://khalsacollege.edu.in/', 'active'),
(93, 'inline_css', '1', '2019-07-25 16:48:25', 'http://cacms.in/', 'active'),
(94, 'heading_test', '1', '2019-07-25 16:49:20', 'http://cacms.in/', 'active'),
(95, 'heading_test', '1', '2019-07-25 16:50:10', 'http://cacms.in/', 'active'),
(96, 'sitemap', '1', '2019-07-25 16:51:04', 'http://cacms.in/', 'active'),
(97, 'email_test', '1', '2019-07-25 16:51:28', 'http://cacms.in/', 'active'),
(98, 'email_test', '1', '2019-07-25 16:52:13', 'http://cacms.in/', 'active'),
(99, 'email_test', '1', '2019-07-25 16:52:50', 'http://khalsacollege.edu.in/', 'active'),
(100, 'image_alt', '1', '2019-07-25 16:57:09', 'http://cacms.in/', 'active'),
(101, 'image_alt', '1', '2019-07-26 05:02:35', 'http://khalsacollege.edu.in/', 'active'),
(102, 'email_test', '1', '2019-07-27 07:43:59', 'http://khalsacollege.edu.in/', 'active'),
(103, 'sitemap', '1', '2019-07-27 07:45:23', 'http://cacms.in/', 'active'),
(104, 'link_extractor', '5', '2019-07-27 08:02:53', 'http://khalsacollege.edu.in/', 'hide'),
(105, 'link_extractor', '5', '2019-07-27 08:04:14', 'http://cacms.in/', 'hide');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `image` varchar(100) DEFAULT 'image/user.png',
  `city` varchar(50) DEFAULT NULL,
  `password` varchar(50) NOT NULL,
  `regdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(8) NOT NULL DEFAULT 'active',
  `lastname` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `firstname`, `email`, `phone`, `image`, `city`, `password`, `regdate`, `status`, `lastname`) VALUES
(1, 'vikas', 'vikaskumar7321@gmail.com', '7973816623', 'image/nature.jpg', 'tarn taran', 'bebe68374a49cb41b7c9219e97250044', '2019-07-11 05:10:50', 'active', ''),
(2, NULL, 'ritika@gmail.com', NULL, 'image/user.png', NULL, 'e10adc3949ba59abbe56e057f20f883e', '2019-07-27 07:48:57', 'active', NULL),
(3, NULL, 'a@gmail.com', NULL, 'image/user.png', NULL, '827ccb0eea8a706c4c34a16891f84e7b', '2019-07-27 07:52:01', 'active', NULL),
(4, NULL, 'b@gmail.com', NULL, 'image/user.png', NULL, '827ccb0eea8a706c4c34a16891f84e7b', '2019-07-27 07:54:32', 'active', NULL),
(5, 'a', 'a1@gmail.com', '', 'image/india.jpg', '', '827ccb0eea8a706c4c34a16891f84e7b', '2019-07-27 07:55:53', 'active', '');

-- --------------------------------------------------------

--
-- Table structure for table `video`
--

DROP TABLE IF EXISTS `video`;
CREATE TABLE IF NOT EXISTS `video` (
  `videoid` int(11) NOT NULL AUTO_INCREMENT,
  `video` varchar(100) NOT NULL,
  `title` varchar(60) NOT NULL,
  `overview` varchar(8000) NOT NULL,
  `addedon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `category` varchar(60) NOT NULL,
  PRIMARY KEY (`videoid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `video`
--

INSERT INTO `video` (`videoid`, `video`, `title`, `overview`, `addedon`, `category`) VALUES
(1, 'video/5 Ways to Gain More Instagram.mp4', '5 ways to gain more instagram followers', '<p style=\"text-align:justify\">Are you looking to grow your Instagram following? Follow these 5 steps:</p>\r\n\r\n<p style=\"text-align:justify\">Summary of How to Grow Your Instagram Following Do you want to be instafamous?&nbsp; Well of course you do, who doesn&#39;t? Heck, these days, instafamous people are like celebrities!</p>\r\n\r\n<p style=\"text-align:justify\">Have people told you, make sure you comment and like and follow other people who are popular.</p>\r\n\r\n<p>&nbsp;</p>\r\n', '2019-07-14 05:40:23', 'Search Engine Optimization'),
(2, 'video/3 Unorthodox SEO Tips to Increase Organic Website Traffic (RIGHT NOW) - YouTube (360p).mp4', 'SEO Tips to increase organic traffic', '<p style=\"text-align:justify\">Boost Organic Website Traffic Tip #1:<br />\r\nThe first tip I have for you is to go and buy other properties within your space.<br />\r\nIt&#39;s expensive; you don&#39;t have to go as crazy . But it&#39;s a great way to grow your search engine rankings without spending a ton of money of SEO.&nbsp; for learn more watch full video ..</p>\r\n', '2019-07-14 06:30:53', 'Search Engine Optimization'),
(3, 'video/Advanced Step-By-Step SEO Tutorial (2019) - YouTube (360p).mp4', 'Advanced Step-By-Step SEO Tutorial', '<p style=\"text-align:justify\">If you want higher Google rankings, this SEO tutorial is for you. In my experience, success with search engine optimization comes down to getting the fundamentals right. Then moving onto advanced SEO strategies and techniques. And that&#39;s exactly how this SEO tutorial is structured. First, you&#39;ll learn how to improve your site&#39;s loading speed. As you see in the video, site speed is a misunderstood Google ranking.</p>\r\n', '2019-07-18 06:48:39', 'Search Engine Optimization'),
(4, 'video/SEO For Beginners.mp4', 'SEO for Beginners', '<p style=\"text-align:justify\">SEO For Beginners: 3 Powerful SEO Tips to Rank #1 on Google in 2019 Are you new to SEO and want to rank #1 on google this upcoming year? Here are 3 SEO strategies that will boost your rankings! Focus on content<br />\r\nGoogle has this update called Hummingbird, and with Hummingbird, websites who just have content on everything won&#39;t do as well as sites which focus on one single niche and are super thorough.</p>\r\n', '2019-07-18 06:50:41', 'Search Engine Optimization'),
(5, 'video/Advanced Step-By-Step SEO Tutorial (2019) - YouTube (360p).mp4', 'Advanced Step-By-Step SEO Tutorial', '<p style=\"text-align:justify\">If you want higher Google rankings, this SEO tutorial is for you. In my experience, success with search engine optimization comes down to getting the fundamentals right. Then moving onto advanced SEO strategies and techniques. And that&#39;s exactly how this SEO tutorial is structured. First, you&#39;ll learn how to improve your site&#39;s loading speed. As you see in the video, site speed is a misunderstood Google ranking.</p>\r\n', '2019-07-18 06:52:03', 'Search Engine Optimization'),
(6, 'video/What is SEO and how does it work.mp4', 'What is SEO ? and how does it works', '<p style=\"text-align:justify\">Hey Guys, This video will explain you SEO (Search Engine Optimization), How Search Engine works to rank websites .</p>\r\n', '2019-07-18 06:56:20', 'Search Engine Optimization');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
