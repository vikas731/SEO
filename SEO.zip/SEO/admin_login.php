<?php session_start(); ?>
 <?php include 'db.php' ?>
<html>
<head>
<title>Admin Log in</title>
  <link href='css/bootstrap.min.css' rel='stylesheet'>
   
</head>
<body>

    <div class="container">
        <div class="row  mt-5 pt-5 pb-5" style="background-color:f4f4f4;" >
           
            <div class="col-lg-2"></div>
             
            
            <div class="col-lg-8 pt-3 pb-3">
            <div class="row " style="box-shadow:2px 2px 2px #000" >
            <div class="col-lg-6 p-5" style="background-color:ffffff; ">
                 <h3>Admin Login</h3><br/>
                <form action="" method="post">
                <label>Username</label>
                 <input type="UserName" class="form-control rounded-0" name="un" style="border:none; border-bottom:1px solid black;" required>  <br/>
                    <label>Password</label><br/>
                 <input type="password" class="form-control rounded-0" name="pwd" style="border:none;border-bottom:1px solid black;"required ><br/><br/>

                    <button  type="submit" class="btn btn-primary btn-block" name="save">Login </button><br/>
                       <p class="text-center">Forgot Password?</p>
                </form>
        <?php
        if(isset($_POST['save'])){
            $pw=md5($_POST['pwd']);
            $sql="select * from admin where username='$_POST[un]' and password='$pw';";
            $result=$conn->query($sql);
            if($result->num_rows>0){
                $_SESSION['ad']='admin';
                echo "<script>window.location='admin/savepost.php';</script>";
            }
                
            else
                echo "<br/><div class='alert alert-warning'>Invalid User Name OR Password</div>";
        
            
            
        }
        ?>
                 </div>
             
            <div class="col-lg-6 " style="background-image:url('login.jpg'); background-size:cover">

                </div>
        </div>
                </div> 
    
    <div class="col-lg-2">
            
                <form >
                <button type="submit" class="btn btn-primary" style="bottom:-30px; right:40px; position:absolute;" >Back Home</button>
                </form>
            </div>
                  
</div>
   </div> 
    
</body>
</html>
