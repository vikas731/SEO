<?php include 'header.php' ?>
<?php
function alexaRank($url) 
{
 $alexaData = simplexml_load_file("http://data.alexa.com/data?cli=10&url=".$url);
 $alexa['globalRank'] =  isset($alexaData->SD->POPULARITY) ? $alexaData->SD->POPULARITY->attributes()->TEXT : 0 ;
 $alexa['CountryRank'] =  isset($alexaData->SD->COUNTRY) ? $alexaData->SD->COUNTRY->attributes() : 0 ;
 return json_decode(json_encode($alexa), TRUE);
}

if(isset($_GET['url'])) 
{
 $url = $_GET['url'];
 $alexa = alexaRank($url);
 $globalRank ="Global Alexa Rank  is : ".$alexa['globalRank'][0];
 $countryRank ="Alexa Rank In ".$alexa['CountryRank']['@attributes']['NAME']." is : ".$alexa['CountryRank']['@attributes']['RANK'];
}
?>
<div class="container-fluid">
    <div class="row"> 
            <div class='col-md-12 text-center bg-light pt-5 pb-5'> 
            <h5> Alexa Rank Checker</h5>
            <h6> <a href='index.php' style="color:#f9a32a "> Home </a><i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i> SEO Tools <i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i>Alexa Rank Checker </h6>
            
            </div>
    </div></div>
      <div class="container pt-5" style="min-height:500px">
        <div class="row">
            <div class="col-md-12">
           
                <p style="text-align:justify;">Alexa Rank Checker is the easiest and fastest way to simultaneously collect Alexa Rank, incoming Links, and the Status of multiple websites. This way you get to know where you stand and your competitors in the business.
This Alexa Rank Checker is a very helpful tool if you want to analyze your websites because once you get the results, you can already move to formulating strategies on how to improve your website and increase traffic

</p>
            </div>
        </div>
         <div class="row pt-2">
        
            <div class="col-md-6 pt-5 pb-5  bg-light"><h5 class='pb-2'>Enter your Website url</h5>
                <form action="" method="">
                    <input type="url" placeholder="Enter Website url" name="url" class="form-control" required><br/>
                    <button type="submit" class="btn btn-primary " name="submit">Submit</button>
                </form>
                <?php
if(isset($_GET['submit']))
{

echo "<p>" .$globalRank. "</p>";
echo "<p>" .$countryRank. "</p>";
 

}
?>
        </div>
          </div>
</div>
<?php include 'footer.php' ?>