﻿<?php include 'header.php' ?>
<div class="container-fluid">
    <div class="row"> 
            <div class='col-md-12 text-center bg-light pt-5 pb-5'> 
            <h5> Image Alt Test</h5>
            <h6> <a href='index.php' style="color:#f9a32a "> Home </a><i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i> Site Test <i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i>Image Alt Test </h6>
            
            </div>
    </div></div>
     <div class="container pt-5" style="min-height:500px">
        <div class="row">
            <div class="col-md-12">
           
            <h3>Image Alt Test</h3>
                <p>Check if images on your webpage are using alt attributes. If an image cannot be displayed (e.g., due to broken image source, slow internet connection, etc), the alt attribute provides alternative information. Using relevant keywords and text in the alt attribute can help both users and search engines better interpret the subject of an image.</p>
            </div>
        </div>
         <div class="row pt-2">
        
            <div class="col-md-6 pt-5 pb-5  bg-light"><h5 class='pb-2'>Enter your Website url</h5>
                <form action="" method="post">
                    <input type="url" placeholder="Enter Website url" name="url" class="form-control" required><br/>
                    <button type="submit" class="btn btn-primary " name="submit">Submit</button>
                </form>
                  
            </div>
            <div class="col-md-6 pt-4">
                <p>In order to pass this test you must add an alt attribute to every <img> tag used into your webpage.</p>

                <p>An image with an alternate text specified is inserted using the following HTML line:</p>

<p CLASS="bg-light">&lt;img src="image.png" alt="text_to_describe_your_image"&gt;</p>

<p>Remember that the point of alt text is to provide the same functional information that a visual user would see.</p>
              <!-- Button trigger modal -->
<a href='#' data-toggle="modal" data-target="#exampleModalScrollable">
  Know More About Image Alt Test
</a>

<!-- Modal -->
<div class="modal fade" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalScrollableTitle">Image Alt Test</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
<p> Search engines, users who disabled images in their browsers and other agents who are unable to see the images on your webpage can read the alt attributes assigned to the image since they cannot view it.</p>
     <h5> How You’re Images “Look” to the Search Engines</h5>

<p>Search engines send out automated programs called “spiders” that crawl your site and search for what type of content it contains. Although spiders aren’t able to “see” images, they are able to read the text which is associated with those images. With this information, and the information gathered from your content and your meta data, the search engines determine the theme of your site. There are three types of text that the search engine spiders “see” when they look at your images:
</p>
          <ul>
    <li>Image Alt tags: accessible (by means of programs which dictate text) also to web users who are vision</li>
 impaired.
   <li> Image file name: this is the actual name of your image file. For example: “ocean landscape.jpeg”</li>

    <li>Image captions: the text which is found directly beside, over, or underneath your images.</li>
</ul>

<p>Optimizing each of these types of text enhances the SEO of your site and assists you in further communicating your site’s theme to the search engines.</p>

<p>Since Google and other search engines are unable to see your images, it is important that you use the alternative text to tag the image with the information you want the search engine to know about the image you have on your site. These alt tags, or alternative text, will help the search engines locate your images and display them in the SERP’s. Google doesn’t know you have an image of a flying squirrel on your site, unless you tell it….so read on.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
    
      </div>
    </div>
  </div>     
</div></div></div>
   <div class='row'>
         
         <div class='col-md-12'>
             <table class="table">
                    <?php
//insertion
if(isset($_POST['submit'])){
if(!isset($_SESSION['uid']))
    echo "<script> window.location='sign_in.php?page=image_alt';</script>";
    else{

$sql="insert into usage_rec(title,url,userid) values('image_alt','$_POST[url]','$_SESSION[uid]');";
if($conn->query($sql)==TRUE)
{
    $url=$_POST['url'];
@$html = file_get_contents($url);
$doc = new DOMDocument();
@$doc->loadHTML($html);
$tags = $doc->getElementsByTagName('img');
if(count($tags)==0)
	echo count($tags)." Record Found  Check Your URL Again";
else {
    echo "<tr><th>Image Src</th><th>Image Alt </th><th>Image</th></tr>";
foreach ($tags as $tag) {
$src=$tag->getAttribute('src');
$alt=$tag->getAttribute('alt');
$alt=$alt==""?"N/A":$alt;
if(substr($src,0,4)=="http" or substr($src,0,5)=="//www"){
       echo "<tr>
<td>".$src ." </td><td> ".$alt." </td>
<td> <a href='$src' target='_blank'> <i class='icofont icofont-image'></i> </a> </td>
</tr>";
}
else{
    $SRC=$url.$src;
      echo "<tr>
<td>".$src ." </td><td> ".$alt." </td>
<td> <a href='$SRC' target='_blank'> <i class='icofont icofont-image'></i> </a> </td>
</tr>"; 
    
    //echo "<tr><td>".$src ." </td><td> ".$alt." </td><td>  <i class='icofont icofont-image'></i>  </td></tr>";
} }}

}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";
}}
 ?>      
             </table>
       </div>
         </div>
        </div>
<hr/>
<?php include 'footer.php' ?>