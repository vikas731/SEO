<?php include'header.php' ?>
<div class="container-fluid">
<div class="row"> 
            <div class='col-md-12 text-center bg-light pt-5 pb-5'> 
            <h5> Frequently Asked Questions </h5>
            <h6> <a href='index.php' style="color:#f9a32a "> Home </a> <i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i> FAQ </h6>
            
            </div>
</div>
</div>
    <div class="container-fluid">
<div class="row  pt-2">

 <div class="col-md-3 pt-3">
     
     <div class='p-4 text-justify' style="background:#62c4ff;  ">
         <h5>List of Best and Worst practices for designing a high traffic website</h5>
     <p>Here is a checklist of the factors that affect your rankings with Google, Bing, Yahoo! and the other search engines. The list contains positive, negative and neutral factors because all of them exist. Most of the factors in the checklist apply mainly to Google and partially to Bing, Yahoo! and all the other search engines of lesser importance.</p>
        </div>
     <div class="row">
 <div class="col-md-12 pt-4 ">
     <form action="" method="post">
              <h5> Ask your Question </h5><br/>
              <input type="email" class="form-control" name="e" placeholder="email "required> <br/>
                <textarea class="form-control" rows="6" placeholder="Type Your Questioin Here" name="q"></textarea><br/>
                <button type="submit" class="btn btn-primary" name="submit" >Submit</button>
            </form>
            <?php 
    if(isset($_POST['submit'])){

$sql="insert into questions(question,email) values('$_POST[q]','$_POST[e]');";
 if($conn->query($sql)==TRUE)
            echo "<br/><div class='alert alert-success'>Record saved </div>";
        else
            echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";
    }
     
     ?>
         </div></div></div>
    
 <div class="col-md-9 pt-3"> 
  <?php
//selection
$sql="select * from faq order by questionid desc";
$result=$conn->query($sql);

while($row=$result->fetch_assoc())
{
    
    $qid=$row['questionid'];

    ?>      
      <div class="row">

 <div class="col-md-12">
        
<div id="accordion">
  <div class="card">
    <div class="card-header" id="heading<?php echo $qid?>">
      <h5 class="mb-0">
        <button class="btn btn-link" data-toggle="collapse" data-target="#collapse<?php echo $qid?>" aria-expanded="true" aria-controls="collapse<?php echo $qid?>">
          <?php echo $row['question']; ?>
        </button>
      </h5>
    </div>
    <div id="collapse<?php echo $qid?>" class="collapse" aria-labelledby="heading<?php echo $qid?>" data-parent="#accordion">
      <div class="card-body"><?php echo $row['answer'] ?>
      </div>
    </div>
  </div>
 </div>
            </div>
    </div>
<?php } ?>
    </div></div></div>
<?php include'footer.php' ?>