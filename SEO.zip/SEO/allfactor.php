<?php include'header.php' ?>
<div class="container-fluid">
<div class="row"> 
            <div class='col-md-12 text-center bg-light pt-5 pb-5'> 
            <h5> Seo Factors </h5>
            <h6> <a href='index.php' style="color:#f9a32a "> Home </a> <i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i> Factors </h6>
            
    </div></div></div>

 <div class="row ">
     <div class="col-md-1"></div>
         <div class="col-md-10">
        
         </div>
     <div class="col-md-1"></div>
</div>

<div class="container-fluid pt-4">

<div class="row">
    <div class="col-md-3">
        <div class='p-4 text-justify' style="background:#62c4ff;  ">
         <h5>List of Best and Worst practices for designing a high traffic website</h5>
     <p>Here is a checklist of the factors that affect your rankings with Google, Bing, Yahoo! and the other search engines. The list contains positive, negative and neutral factors because all of them exist. Most of the factors in the checklist apply mainly to Google and partially to Bing, Yahoo! and all the other search engines of lesser importance.</p>
        </div>
        
    <table class="table table-hover p-4" style="background:#0f8bd6; color:#fff">
    <?php
$sql="select * from factor group by type;";
$result=$conn->query($sql);

while($row=$result->fetch_assoc())
{
     $ct=$row['type'];
    echo "<tr><td><a href='allfactor.php?type=$ct' style='color:#fff; text-decoration:none;'>".$row['type']."</td></tr></p>";
} 

     echo "<tr><td> <a href='allfactor.php' style='color:#fff'> Show All Factors </td></tr>";
?>
        </table>
       
    </div>
<div class="col-md-9">
<table class="table table-striped table-bordered table-hover">
<tr><th>Title</th><th>Description</th><th>Point</th></tr>
<?php
    if(isset($_GET['type']))
$sql="select * from factor where type='$_GET[type]' order by factorid desc";
else
 $sql="select * from factor order by factorid desc";   
    
$result=$conn->query($sql);

while($row=$result->fetch_assoc())
{
     $fid=$row['factorid'];
echo "<tr>";
echo "<td>".strip_tags($row['title'])."</td>";

    
    echo "<td>".$row['description']."</td>";
 echo "<td>".$row['point']."</td>";
echo "</tr>";
}

?>

</table>

    <?php

if(isset($_GET['dl'])){

$sql="delete from factor where factorid='$_GET[dl]';";
if($conn->query($sql)==TRUE)
{
echo "<script>window.alert('Record Deleted');
window.location='display_factor.php'</script>";
}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";

}


?>
</div>
<div class="col-md-1"></div>
</div>


</div>
<?php include'footer.php' ?>



 