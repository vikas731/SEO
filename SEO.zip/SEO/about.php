<?php include'header.php' ?>

<div class="row"> 
  <div class='col-md-12 text-center bg-light pt-5 pb-5'> 
    <h5> About us</h5>
    <h6> <a href='index.php' style="color:#f9a32a "> Home </a><i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i> About us </h6>
  </div>
</div>
<div class="container">
  <div class="row  pt-5">
    <div class='col-md-4 pt-3'>
      <img src="seo.jpg" width="100%" height="300px" style="background:transparent;">
    </div>
    <div class='col-md-8 text-justify'>
      <p> <b>SEO KIT </b>is a website that offers free online SEO tools and Information. People from all over the world can easily access all these tools and utilize for whatever purpose it may serve them best.We at SEO-KIT bring you the most reliable results so you can have the best materials that you can use for your website or content, SEO-KIT will provide you with all the things you need to make your website and content highly competitive.</p>
      <p>We at SEO-KIT bring you the most reliable results so you can have the best materials that you can use for your website or content, SEO-KIT will provide you with all the things you need to make your website and content highly competitive</p>
      <p>SEO-KIT team and staff is continually developing and extending its services and enhancing its existing webmaster and seo tools. Our goal is to provide high quality of service so that your website is highly optimized and increasingly visible. We understand that technology is outdated and newest web technology is embraced at full force at very fast pace, and we continue to grow right along with it. Your comments, feedback and suggestions are welcome to improve the quality and services at SEO-KIT.</p>
    </div>
  </div>
</div>
<?php include'footer.php' ?>