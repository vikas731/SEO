<?php session_start();
unset($_SESSION['uid']);
unset($_SESSION['em']);
echo "<script>window.location='../sign_in.php';</script>";
?>