<?php include 'header.php' ?>
<header class="page-header">
            <div class="container-fluid">
                <h2 class="no-margin-bottom"> <a href="review.php"> <i class="icofont icofont-speech-comments" style="color:#f9a32a"> </i></a> Review </h2>
            </div>
          </header>
<div class="container">
    <div class="row pt-5">
        <div class="col-md-3 "></div>
    <div class="col-md-6 ">
        <form action="" method="post">
        <label>Type your review here</label>
        <textarea rows="7" name="txt" class="form-control" required></textarea><br/>
        <button type="submit" class="btn btn-primary" name="submit" style="background:#0674a1">Send Review</button>
          <button type="reset" class="btn btn-secondary" name="reset">Clear</button>
            </form>
        <?php
        if(isset($_POST['submit'])){
$sql="insert into review (reviews,reviewby) values('$_POST[txt]','$_SESSION[uid]');";
if($conn->query($sql)==TRUE)
{
echo "<br/><div class='alert alert-success'>Record saved </div>";
}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";

}

?>
        </div>
     <div class="col-md-3 "></div>
    </div>

</div>
<?php include 'footer.php' ?>