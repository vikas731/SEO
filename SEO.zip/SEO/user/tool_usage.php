<?php include 'header.php'; ?>
<!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
                <h2 class="no-margin-bottom"><i class="icofont icofont-tools" style="color:#f9a32a;"></i> Tool Usage</h2>
            </div>
          </header>
<body>

<div class="container pt-4">

     <div class="text-right p-3"><a  href='tool_usage.php?dl=0' type="button" name="btn" class="btn btn-primary">Delete History</a></div>
    
<div class="row">
<div class="col-md-1"></div>
<div class="col-md-10">
<table class="table table-striped table-bordered table-hover">
   
<tr><th>Title</th><th>Use Date</th><th>Url</th></tr>
<?php
$sql="select * from usage_rec where status='active' and userid='$_SESSION[uid]' order by us_id desc";
$result=$conn->query($sql);

while($row=$result->fetch_assoc())
{
    echo "<tr>";
echo "<td>".$row['title']."</td>";

echo "<td>".$row['use_date']."</td>";
echo "<td>".$row['url']."</td>";

}

?>

</table>
</div>
        <?php

if(isset($_GET['dl'])){

$sql="Update usage_rec set status='hide' where userid='$_SESSION[uid]';";
if($conn->query($sql)==TRUE)
{
echo "<script>window.alert('History Deleted');
window.location='tool_usage.php'</script>";
}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";

}


?>

<div class="col-md-1"></div>

</div>
</div>
<?php include 'footer.php'; ?>