<?php include 'header.php'?>

          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom"> <i class='icofont icofont-key' style='color:#f9a32a'> </i> Change Password</h2>
            </div>
          </header>

       <div class="container">
           <div class="row pt-5">
               <div class="col-md-6">
        
           <p>Use the form below to change your password</p>
           <p>New password are required to be a minimum of 6 characters in length</p>
           
            <hr/>
                <form action="" method="post" >
            <label style="font-family:verdana;">Old Password</label><br/>
        <input type="password" name="op" class="form-control" required ><br/>
            <label style="font-family:verdana;">New Password</label><br/>
        <input type="text" name="np" class="form-control" required><br/>
            <label style="font-family:verdana;">Confirm New Password</label><br/>
        <input type="text" name="cnp" class="form-control" required><br/>
            <div class="text-right">
                <button type="submit" value="Change Password" class="btn btn-primary" name="save" style="background:#0674a1">Change Password</button>
            <button type="reset" value="Cancel"  name="rst" class="btn btn-danger">Cancel</button>
               
                </div>
        
               </form>
                   
                   <?php
    //update new password
    if(isset($_POST['save']))
    {
        $sql="select * from user where userid='$_SESSION[uid]';";
        $result=$conn->query($sql);
        $row=$result->fetch_assoc();
        
        $epw=$row['password'];
        $opw=md5($_POST['op']);
        if($epw==$opw){
            if($_POST['np']==$_POST['cnp'])
            {
          $npw=md5($_POST['np']);
                $sql="UPDATE user set password='$npw' where userid='$_SESSION[uid]';";
                if($conn->query($sql)==TRUE)
                 echo "<script>window.alert('Password Saved');</script></div>";
                else
                    echo "<br/><div class='alert alert-danger'>Error :".$conn->error."</div>";
                
            }
            else
            echo"<br/><div class='alert alert-warning'>Confirm Password not Matched</div>";
            }
        else
           echo"<br/><div class='alert alert-warning'>Old Password not Matched</div>";
        
        
        
    }
    ?>
               </div>
               <div class="col-md-6"></div>
           </div>
           </div>
    </body>
</html>
<?php include 'footer.php'?>