
<?php include 'header.php'?>

          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom"> <i class='icofont icofont-user' style='color:#f9a32a'> </i> My Profile </h2>
            </div>
          </header>

       <div class="container">
        <?php
        $sql="select * from user where userid='$_SESSION[uid]';";
        $result=$conn->query($sql);
        $row=$result->fetch_assoc();
        ?>
        <div class="row  pt-5 pb-4 mb-3">
            
<div class="col-md-4">
            <img src="<?php echo $row['image'] ?>" width=70% height="200" class="border p-2 rounded-circle">
            
            
            </div>

            <div class="col-md-6"> 
            
            <form action="" method="post" enctype="multipart/form-data">
                <label style="font-family:verdana">Select Image</label>
               <input type="file" name="img" class="form-control"> <br/>
                <p> only JPG and PNG Files are allowed * </p>
                <button type="submit" name="submit" class="btn btn-primary" style="background:#0674a1">Upload Image</button>
            
            </form>
          
                <?php //insert data into table

if(isset($_POST['submit'])){

     $dirname="image/";
    $filename=$dirname.$_FILES['img']['name'];
    $tempname=$_FILES['img']['tmp_name'];
    $filetype=pathinfo($filename,PATHINFO_EXTENSION);
   // echo $filetype;
if($filetype=='jpg' or $filetype=='png' or $filetype=='jpeg' ){
if(move_uploaded_file($tempname,$filename)==TRUE)
{
$sql="update user set image='$filename' where userid='$_SESSION[uid]';";
if($conn->query($sql)==TRUE)
{
echo "<script>window.location='profile.php';</script>";
}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";

}

else
{
echo "<br/><div class='alert alert-warning'>Error in File Uploading</div>";
}
}
    else
      echo "<br/><div class='alert alert-warning'>only jpg png and jpeg allow</div>";  

}

?>

            
           </div>
            <div class="col-md-2"></div>
        </div>
            <hr/>
        <form action="" method="post" class="form-group">
            <div class="row">
          
            <div class="col-md-6">
                  <label style="font-family:verdana">First Name</label>
                <input type="text" name="fnm" value="<?php echo $row['firstname'] ?>" class="form-control"><br/></div>
               
                <div class="col-md-6">
                     <label style="font-family:verdana">Last Name</label>
                    <input type="text" name="lnm" value="<?php echo $row['lastname'] ?>" class="form-control"><br/></div>
            
            </div>
            
            <div class="row">
            
            <div class="col-md-6">
                <label style="font-family:verdana">Email</label>
                <input type="email" name="em" value="<?php echo $row['email'] ?>" class="form-control"><br/></div>
                 
                <div class="col-md-6">
                    <label style="font-family:verdana">Phone no</label>
                    <input type="tel" name="phn" value="<?php echo $row['phone'] ?>" class="form-control"><br/></div>
            
            </div>
            
            <div class="row">
             
            <div class="col-md-6">
                <label style="font-family:verdana">City</label>
                <input type="text" name="city" value="<?php echo $row['city'] ?>" class="form-control"><br/></div>
                <div class="col-md-6"><br/><br/><button type="submit" name="save" class="btn btn-primary">Update Profile</button></div>
            
            </div>
                
        </form>
        <?php 
    if(isset($_POST['save'])){
        $sql="update user set firstname='$_POST[fnm]',lastname='$_POST[lnm]',email='$_POST[em]',phone='$_POST[phn]',
        city='$_POST[city]' where userid='$_SESSION[uid]';";
        if($conn->query($sql)==TRUE)
        {
          echo "<script>window.alert('Profile UPdated');
          window.location='profile.php';</script>";
            
        }
        else
            echo "</br><div alert alert-warning>error".$conn->error."</div>";
        
    }
                       ?>
    </div>
    
 <?php include 'footer.php' ?>



        