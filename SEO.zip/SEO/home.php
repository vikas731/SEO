<?php include "header.php" ?>
<style>
    h5 {
    font-size: 20px;
    font-family: 'Bariol-Bold', sans-serif;
    white-space: nowrap;
    overflow: hidden;
        text-overflow: ellipsis;}
    .hv:hover i{
       font-size:7em;
       transition: all 300ms ease;
       
    }
    .hv:hover p{display:none;}
    .hv:hover{ background: #ecf0f1;}
    </style>

<body>
    
   <!-- slider-->
    <div class="bd-example">
  <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
      <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="seo_images/search-engine-optimisation-gibraltar-blog.jpg" class="d-block w-100" alt="..." height="550px">
        <div class="carousel-caption d-none d-md-block">
          <h5>First slide label</h5>
          <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="seo_images/search-engine-411105_1280.jpg" class="d-block w-100" alt="..." height="550px">
        <div class="carousel-caption d-none d-md-block">
          <h5>Second slide label</h5>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="seo_images/seo-search-engin.jpg" class="d-block w-100" alt="..." height="550px">
        <div class="carousel-caption d-none d-md-block">
          <h5>Third slide label</h5>
          <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
        </div>
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>
    <div class="container pt-4 pb-3" style="text-align:justify;">
        <div class="row ">
        <div class="col-md-5">
            <h5>What We Do?</h5>
            <p class='text-center'> <B>SEO KIT </B> is a website that offers free online SEO tools and Information. People from all over the world can easily access all these tools and utilize for whatever purpose it may serve them best.We at SEO-KIT bring you the most reliable results so you can have the best materials that you can use for your website or content, SEO-KIT will provide you with all the things you need to make your website and content highly competitive.
                <B> Our goal </B>is to provide high quality of service so that your website is highly optimized and increasingly visible. We understand that technology is outdated and newest web technology is embraced at full force at very fast pace, and we continue to grow right along with it.</p>
            </div>
             <div class="col-md-7">
                 <img src="seo_images/SEO-1.png" width="100%" height="350px" >
            </div>
    </div>
    </div>
        <div class="container-fluid  pt-3">
        <hr/>
        <h5 style="text-align:center;">SEO Tools </h5>
        <hr/>
        </div>
   
    <div class="container">
    <div class="row">
        <div class="col-md-4 text-center pt-5 pb-4 border hv " >
        <a href='htmlsv.php' style="color:#222; text-decoration:none">
            <i class="icofont icofont-file-alt icofont-4x" style="color:#E67E22; "  ></i> 
            <h5 class='pt-3 pb-3' style="color:#0674a1 "><b>Source Code Viewer </b></h5> 
            <p >The Source Code Viewer Tool makes it easy to fetch and view... </p><!--source code of any URL.--> </a>
        </div>
         <div class="col-md-4 text-center pt-5 pb-4 border hv">
        <a href='image_alt_test.php' style="color:#222; text-decoration:none">
            <i class="icofont icofont-image icofont-4x" style="color:#E67E22;"></i>
             <h5 class='pt-3 pb-3' style="color:#0674a1 " ><b>Image Alt Test</b></h5>
            <p>Check if images on your webpage are using alt attributes.If an image...</p> <!--  scannot be displayed (e.g., due to broken image  -->
            </a>
        </div>
         <div class="col-md-4 text-center pt-5 pb-4 border hv">
       <a href='inline_css_test.php' style="color:#222; text-decoration:none">
            <i class="icofont icofont-file-code icofont-4x" style="color:#E67E22; "></i>
             <h5 class='pt-3 pb-3' style="color:#0674a1 "><b>Inline CSS Test</b></h5>
           <p>Check your webpage HTML tags for inline CSS properties. Inline CSS...  </p> <!-- property are added by using the style attribute within specific HTML tags. Inline CSS-->
           </a>
        </div>
        </div>
        <div class="row">
         <div class="col-md-4 text-center pt-5 pb-4 border hv">
        <a href='Link_Extractor.php' style="color:#222; text-decoration:none">
            <i class="icofont icofont-link icofont-4x" style="color:#E67E22; "></i>
             <h5 class='pt-3 pb-3' style="color:#0674a1 "><b>Link Extractor</b></h5>
             <p>Link Extractor is SEO tool let you get a list of the links of a web... </p><!-- page.The link text and the link line in your page html code are showed. Its important to have -->
             </a>
        </div>
    
         <div class="col-md-4 text-center pt-5 pb-4 border hv">
        <a href='meta_tag_extractor.php' style="color:#222; text-decoration:none">
            <i class="icofont icofont-tags icofont-4x" style="color:#E67E22; "></i>
             <h5 class='pt-3 pb-3' style="color:#0674a1 "><b>Meta Tag Extractor</b></h5>
             <p>This Meta Tags Analyzer tool checks meta tags of your website and...</p><!-- provide the report. Simply enter your website URL and the SEO Analyzer Tool will extract-->
             </a>
        </div>
        <div class="col-md-4 text-center pt-5 pb-4 border hv">
        <a href='heading_test.php' style="color:#222; text-decoration:none">
            <i class="icofont icofont-code icofont-4x" style="color:#E67E22; "></i>
            <h5 class='pt-3 pb-3' style="color:#0674a1 "><b>Heading Test</b></h5>
            <p>Check if your webpage is using any H1 and H2 HTML header tags...</p><!-- Header tags are not visible to users, but help clarify and support the overall theme -->
            </a>
        </div>
        </div>
        <div class="row">
         <div class="col-md-4 text-center pt-5 pb-4 border hv">
        <a href='Alexa_rank_checker.php' style="color:#222; text-decoration:none">
            <i class="icofont icofont-listing-number icofont-4x" style="color:#E67E22; "></i>
             <h5 class='pt-3 pb-3' style="color:#0674a1 "><b>Alexa Rank Checker</b></h5>
             <p>Alexa Rank Checker is the easiest and fastest way to simultaneously... </p><!--  collect Alexa Rank, incoming Links, and the Status of multiple websites. -->
             </a>
        </div>
         <div class="col-md-4 text-center pt-5 pb-4 border hv">
        <a href='sitemap_test.php' style="color:#222; text-decoration:none">
            <i class="icofont icofont-site-map icofont-4x" style="color:#E67E22; "></i>
             <h5 class='pt-3 pb-3' style="color:#0674a1 "><b>Sitemap Test</b></h5>
             <p>Check if the website has a sitemap. A sitemap is important as it lists...  </p><!--  all the web pages of the site and let search engine crawlers to crawl the website-->
             </a>
        </div>
             <div class="col-md-4 text-center pt-5 pb-4 border hv">
        <a href='email_test.php' style="color:#222; text-decoration:none">
            <i class="icofont icofont-email icofont-4x" style="color:#E67E22; "></i>
             <h5 class='pt-3 pb-3' style="color:#0674a1 "><b>Email Test</b></h5>
             <p>Check if the website has a sitemap. A sitemap is important as it lists...  </p><!--  all the web pages of the site and let search engine crawlers to crawl the website-->
             </a>
        </div>
        </div>
        
    </div>
   
    
    
        <div class="container-fluid  pt-3">
        <hr/>
        <h5 style="text-align:center;"> Latest Seo  Articles / Blog    </h5>
        <hr/>
        </div>
    <div class="container  pt-3">
        <div class="row  pt-3">
  <?php
//selection
$sql="select * from blogpost order by postid desc limit 3";
$result=$conn->query($sql);

while($row=$result->fetch_assoc())
{
    
    $pid=$row['postid'];
    ?>
            <div class="col-md-4">
            
                
                <div class="card">
  <img src="admin/<?php echo $row['image']; ?>" width="95%" height="250" class="card-img-top" alt="...">
  <div class="card-body">
    <div style="min-height:200px">
      <h5 class="card-title"><?php echo $row['title']; ?></h5>
    <p class="card-text text-justify"><?php echo substr(strip_tags($row['content']),0,220); ?>...</p>
     </div> 
   <?php   echo "<a href='blogpost.php?id=$pid' class='btn btn-outline-dark'>Read More</a>" ?>
  </div>
</div>
                
                
                
             </div>
<?php } ?>
    </div>
</div>
<div class="container-fluid  pt-3">
        <hr/>
        <h5 style="text-align:center;"> Latest News     </h5>
        <hr/>
        </div>
    <div class="container">
    <div class="row">
        <div class="col-md-12">
            <?php
//selection
$sql="select * from news order by newsid desc limit 2";
$result=$conn->query($sql);

while($row=$result->fetch_assoc())
{
    
    $nid=$row['newsid'];
    ?>
        <div class="row  pt-3 border pb-3 mt-3 ">
            <div class="col-md-4">
            
            <img src="admin/<?php echo $row['image']; ?>" width="95%" height="230"> </div>
<div class="col-md-8">
 <h5 class='pt-2'> <?php echo $row['title']; ?></h5>
<p class='text-justify'><?php echo substr(strip_tags($row['content']),0,450); ?></p>
<div class='text-right'>            
<?php   echo "<a href='news.php?id=$nid' class='btn btn-outline-dark'>Read More</a>" ?>
            </div> </div>
    </div>
<?php } ?>
        
        </div>
        <div class="col-md-3"></div>
        
        </div>
    </div>
    
<?php include "footer.php" ?>