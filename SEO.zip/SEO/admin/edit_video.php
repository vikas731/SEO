
<?php include 'header.php'; ?>
<script src="../editor/ckeditor.js"></script>
 <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Video</h2>
            </div>
          </header>
<?php
    //selection
$sql="select * from video where videoid='$_GET[vid]'";
$result=$conn->query($sql);
$row=$result->fetch_assoc();
?>

<div class="container pt-4">

<div class='row pt-3'>
<div class='col-6'><h5> +NEW Video </h5></div>
<div class='col-6 text-right'><h5><a href="display_video.php"> View Videos</a></h5></div>
</div><hr/>
<form action="" method='post' enctype="multipart/form-data" >
<div class='row'>

<div class='col-md-9'>
<input type='text' placeholder='video Title' name='t' value="<?php echo $row['title'] ?>" required class="form-control"><br/>
<textarea rows='7' placeholder="Overview" class="form-control" name='o' required ><?php echo $row['overview'] ?></textarea><br/>
</div>
<div class='col-md-3'>
<select class="form-control" name='sc'>
<option ><?php echo $row['category'] ?></option>
    
<?php
//select data from table for options
$sql="select * from category order by category";
$result1=$conn->query($sql);

while($row1=$result1->fetch_assoc())
{
echo "<option>".$row1['category']."</option>";   
}
    ?>
</select><br/>
    <video src="<?php echo $row['video'] ?>" width="200" height="120" controls></video>
    
    <br/><br/>
<label>Select Video</label>
<input type="file" class="form-control" accept='mp4' name='vid'>
<p class='text-right'> * only Mp4 files are allowed</p><br/>
<button type="submit" class="btn btn-primary" name='save' style="background:#0674a1;">Submit</button>
<button type="reset" class="btn btn-danger" name='reset'>Reset</button>
</div>
</div>
</form>
<?php

if(isset($_POST['save'])){
    
        echo "jggg";
    if(!is_uploaded_file($_FILES['vid']['tmp_name']))
        $filename=$row['video'];
    else{
        echo "jjj";
    $dirname="video/";
    $filename=$dirname.$_FILES['vid']['name'];
    $tempname=$_FILES['vid']['tmp_name'];
    $filetype=strtolower(pathinfo($filename,PATHINFO_EXTENSION));
    //echo $filetype;
if($filetype=='mp4' or $filetype=='avi')
{
    if(move_uploaded_file($tempname,$filename)==TRUE)
    {
        $uploadok=1;
    }
            else{
                $filename=$row['video'];
                echo "<script>window.alert('Error in File Uploading')</script>";
            }
   
}
else{
    $filename=$row['video'];
    echo "<script>window.alert('only mp4 or avi allow')</script>";
    } }
        //updation
        $v=$_GET['vid'];
    $sql="update video set title='$_POST[t]',video='$filename',overview='$_POST[o]',category='$_POST[sc]' where videoid='$_GET[vid]';";
        
        if($conn->query($sql)==TRUE)
           echo "<script>window.location='edit_video.php?vid=$v';</script>";
        else
            echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";
    
    

  
}

?>

</div>
<script>CKEDITOR.replace('o');</script>

<?php include 'footer.php'; ?>