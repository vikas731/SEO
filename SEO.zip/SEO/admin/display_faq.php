<?php include 'header.php'; ?>

<div class="container pt-4">

<div class="row">
<div class="col-md-1"></div>
<div class="col-md-10">
<table class="table table-striped table-bordered table-hover">
<tr><th>Question </th><th>Answer</th><th>Edit</th><th>Delete</th></tr>
<?php
$sql="select * from faq order by questionid desc";
$result=$conn->query($sql);

while($row=$result->fetch_assoc())
{
     $qid=$row['questionid'];
echo "<tr>";
echo "<td>".$row['question']."</td>";
echo "<td>".$row['answer']."</td>";
     echo "<td><a href='edit_faq.php?qid=$qid'><i class='icofont icofont-edit'></i></a></td>";
     echo "<td><a href='display_faq.php?dl=$qid'><i class='icofont icofont-delete'></i></a></td>";
echo "</tr>";
}

?>

</table>

    <?php

if(isset($_GET['dl'])){

$sql="delete from faq where questionid='$_GET[dl]';";
if($conn->query($sql)==TRUE)
{
echo "<script>window.alert('Record Deleted');
window.location='display_faq.php'</script>";
}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";

}


?>
</div>
<div class="col-md-1"></div>
</div>


</div>
<?php include 'footer.php'; ?>