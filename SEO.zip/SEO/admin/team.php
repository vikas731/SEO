
<?php include 'header.php'; ?>
<script src="../editor/ckeditor.js"></script>
 <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Team</h2>
            </div>
          </header>
<div class="container pt-4">


<form action="" method="post">


<div class='row mb-4'>
<div class='col-md-6'> <label>First name:</label><input type='text' placeholder='First name' name='fn' required class="form-control" pattern[a-z A-Z]{30} > </div>

<div class='col-md-6'> <label>Last name:</label><input type='text' placeholder='Last name' name='ln' class="form-control" pattern[a-z A-Z]{30}> </div>
</div>

<div class='row mb-4'>
<div class='col-md-6'> <label>Email:</label><input type='email' placeholder='Email' name='em' required class="form-control"> </div>

<div class='col-md-6'> <label>Phone No:</label><input type='tel' placeholder='Phone no' name='phn' required class="form-control"  pattern[0-9]{16}> </div>
</div>

<div class="row">

<div class='col-md-6'>
<label>Select image:</label><br/>
<input type='file' placeholder='Select image' name='img' class="form-control" required  accept='.jpg,.png,.jpeg'>
<p class='text-right'> * only jpg or png files are allowed</p></div>

<div class='col-md-6'>
<label>Work Type:</label>
<select class="form-control" name="wt">
<option >work type</option>
</select><br/>
</div>
</div>

<div class='row'>
<label>About:</label>
<div class='col-md-12'>
<textarea rows='7' placeholder="Type Here" class="form-control" name="c" required ></textarea><br/></div>
</div>




<div class='row'>
<div class='col-md-12'>
<button type="submit" class="btn btn-primary" name="save" style="background:#0674a1;">Submit</button>
<button type="reset" class="btn btn-danger">Reset</button>
</div>
    </div>

</form>
<?php

if(isset($_POST['save'])){

$sql="insert into team(first_name,last_name,about,image,emailid,phoneno,worktype) values('$_POST[fn]','$_POST[ln]','$_POST[c]','$_POST[img]','$_POST[em]','$_POST[phn]','$_POST[wt]');";
if($conn->query($sql)==TRUE)
{
echo "<br/><div class='alert alert-success'>Record saved </div>";
}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";

}


?>
</div>
<script>CKEDITOR.replace('a');</script>

<?php include 'footer.php'; ?>