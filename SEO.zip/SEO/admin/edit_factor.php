
<?php include 'header.php'; ?>
<script src="../editor/ckeditor.js"></script>
 <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Factors</h2>
            </div>
          </header>
<?php
    //selection
$sql="select * from factor where factorid='$_GET[fid]'";
$result=$conn->query($sql);
$row=$result->fetch_assoc();
?>
<div class="container pt-4">
    <form action="" method="post">
            <div class='row'>
                    <div class='col-md-12'>
                        <input type='text' placeholder='Title' value="<?php echo $row['title'] ?>" name='t' required class="form-control"><br/>
                    </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <select  name="sc" class="form-control">
                    <option><?php echo $row['type'] ?></option>
                         <option>Keywords</option>
                        <option>Links</option>
                        <option>Metatags</option>
                        <option>Content</option>
                        <option>Visual Extras and SEO</option>
                        <option>Domains, URLs, Web Mastery</option>
                        
            
                    </select>
                </div>
                <div class="col-md-6">
                    <input type='text' placeholder='Point' value="<?php echo $row['point'] ?>" name='p' required class="form-control"><br/>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <textarea rows='7' placeholder="Description" name="d" class="form-control" required ><?php echo $row['description'] ?></textarea><br/>
                    <button type="submit" name="save" class="btn btn-primary mr-2" style="background:#0674a1;">Submit</button>
                    <button type="reset" class="btn btn-danger">Reset</button>
    
                </div>
            </div>
    </form>
<?php
//insertion
if(isset($_POST['save'])){

$f=$_GET['fid'];

$title=addslashes($_POST['t']);        $desc=addslashes($_POST['d']);
    $sql="update factor set title='$title',type='$_POST[sc]',point='$_POST[p]',description='$desc' where factorid='$_GET[fid]';";
if($conn->query($sql)==TRUE)
{
echo "<script>window.location='edit_factor.php?fid=$f';</script>";
}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";

}
?>
</div>


<script>CKEDITOR.replace('d');</script>
<?php include 'footer.php'; ?>