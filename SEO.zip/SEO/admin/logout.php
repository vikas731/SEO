<?php session_start();
unset($_SESSION['ad']);
echo "<script>window.location='../admin_login.php';</script>";
?>