<?php include 'header.php'; ?>
<!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Web Enquires</h2>
            </div>
          </header>
<body>

<div class="container pt-4">

<div class="row">
<div class="col-md-1"></div>
<div class="col-md-10">
<table class="table table-striped table-bordered table-hover">
<tr><th>Name</th><th>Email</th><th>Phone no</th><th>Url</th><th>Message</th><th>Message date</th></tr>
<?php
$sql="select * from contact_msg order by enquiry desc";
$result=$conn->query($sql);

while($row=$result->fetch_assoc())
{
    echo "<tr>";
echo "<td>".$row['name']."</td>";
echo "<td>".$row['email']."</td>";
echo "<td>".$row['phoneno']."</td>";
echo "<td>".$row['url']."</td>";
echo "<td>".$row['message']."</td>";
echo "<td>".$row['msgdate']."</td>";
    echo "</tr>";
}

?>

</table>
</div>
    
<div class="col-md-1"></div>

</div>
</div>
<?php include 'footer.php'; ?>