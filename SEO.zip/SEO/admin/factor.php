
<?php include 'header.php'; ?>
<script src="../editor/ckeditor.js"></script>
 <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Factors</h2>
            </div>
          </header>
<div class="container pt-4">
    <div class='row pt-3'>
        <div class='col-6'><h5> <a href="factor.php"> +NEW FACTOR </a></h5></div>
        <div class='col-6 text-right'><h5><a href="display_factor.php"> VIEW FACTOR</a></h5></div>
    </div><hr/>
    <form action="" method="post">
            <div class='row'>
                    <div class='col-md-12'>
                        <input type='text' placeholder='Title' name='t' required class="form-control"><br/>
                    </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <select  name="sc" class="form-control" required>
                    <option>Select type</option>
                         <option>Keywords</option>
                        <option>Links</option>
                        <option>Metatags</option>
                        <option>Content</option>
                        <option>Visual Extras and SEO</option>
                        <option>Domains, URLs, Web Mastery</option>
               
                    </select>
                </div>
                <div class="col-md-6">
                    <input type='text' placeholder='Point' name='p' required class="form-control"><br/>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <textarea rows='7' placeholder="Description" name="d" class="form-control" required ></textarea><br/>
                    <button type="submit" name="save" class="btn btn-primary mr-2" style="background:#0674a1;">Submit</button>
                    <button type="reset" class="btn btn-danger">Reset</button>
    
                </div>
            </div>
    </form>
<?php
//insertion
    if(isset($_POST['save'])){

        $title=addslashes($_POST['t']);        $desc=addslashes($_POST['d']);
        $sql="insert into factor(title,type,point,description) values('$title','$_POST[sc]','$_POST[p]','$desc');";
    if($conn->query($sql)==TRUE)
        {
            echo "<br/><div class='alert alert-success'>Record saved </div>";
        }
    else
        echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";

                            }   
?>
</div>


<script>CKEDITOR.replace('d');</script>
<?php include 'footer.php'; ?>