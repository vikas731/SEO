
<?php include 'header.php'; ?>
<script src="../editor/ckeditor.js"></script>
 <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Terms & Description</h2>
            </div>
          </header>
<div class="container pt-4">

<div class='row pt-3'>
    <div class='col-6'><h5><a href="term.php"> +NEW TERM </a></h5></div>
<div class='col-6 text-right'><h5><a href="display_term.php"> VIEW TERMS</a></h5></div>
</div><hr/>
<form action="" method="post" >
<div class='row'>

<div class='col-md-12'>
<input type='text' placeholder='Term' name='t' required class="form-control"><br/>
<textarea rows='7' placeholder="Description" name='d' class="form-control" required ></textarea><br/>
<button type="submit" name='save'class="btn btn-primary mr-3" style="background:#0674a1;">Submit</button>
<button type="reset" name='reset' class="btn btn-danger">Reset</button>
</div>

</div>

</form>
<?php

if(isset($_POST['save'])){

$sql="insert into term(term,description) values('$_POST[t]','$_POST[d]');";
if($conn->query($sql)==TRUE)
{
echo "<br/><div class='alert alert-success'>Record saved </div>";
}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";

}
?>
</div>
<script>CKEDITOR.replace('d');</script>

<?php include 'footer.php'; ?>