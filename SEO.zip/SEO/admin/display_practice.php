<?php include'../db2.php' ?>
<div class="container pt-4">
<link rel="stylesheet" href="../css/bootstrap.min.css">
 <link rel="stylesheet" href="../css/icofont.css">
<div class="row">
<div class="col-md-1"></div>
<div class="col-md-10">
<table class="table table-striped table-bordered table-hover">
<tr><th>First name</th><th>Last name</th><th>Class</th><th>Phone no</th><th>Image</th><th>Content</th><th>Del</th></tr>
<?php
  $sql="select * from form;";
$result=$con->query($sql);
while($row=$result->fetch_assoc()){
    $fid=$row['formid'];
    echo "<tr>";	
    echo "<td>".$row['first_name']."</td>";
    echo "<td>".$row['last_name']."</td>";
    echo "<td>".$row['class']."</td>";
    echo "<td>".$row['phoneno']."</td>";
    echo "<td>".$row['image']."</td>";
    echo "<td>".$row['content']."</td>";
    echo "<td><a href='display_practice.php?d=$fid'><i class='icofont icofont-delete'></i></a></td>";
    echo "</tr>";
}
?>
    </table>
<?php
if(isset($_POST['d'])){
$sql="delete from form where formid='$_POST[d]'";
if($con->query($sql)==TRUE)
{
echo "<script>window.alert('Record Deleted');
window.location='display_practice.php'</script>";
}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";
}

?>
    </div>
    <div class="col-md-1"></div>
    </div>
</div>
