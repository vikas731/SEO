<?php include 'header.php'; ?>
 <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Category</h2>
            </div>
          </header>
<body>

<div class="container pt-4">


<div class='row pt-3'>
<div class='col-5'><h4>Add Category</h4><br/>

<form action="" method="post">
<p>Type Category Name</p>
<input type="text" placeholder="Type here" name="cat" maxlength="60" class="form-control" required><br/>
<button type="submit" name="save" class="btn btn-primary btn-block" style="background:#0674a1;">Save Category</button>
</form>
<?php

if(isset($_POST['save'])){

$sql="insert into category(category) values('$_POST[cat]');";
if($conn->query($sql)==TRUE)
{
echo "<br/><div class='alert alert-success'>Record saved </div>";
}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";

}


?>
</div>

<div class='col-md-1 '></div>

<div class='col-md-6 '>
    <h4>Category List</h4>
    <table class="table table-striped table-bordered table-hover">
        <tr><th>Category name </th><th>Delete</th></tr>
<?php
//select data from table
$sql="select * from category order by category";
$result=$conn->query($sql);

while($row=$result->fetch_assoc())
{
$c=$row['category'];
echo "<tr>";
echo "<td>".$row['category']."</td>";
echo "<td><a href='category.php?dl=$c'><i class='icofont icofont-delete'></i></a></td>";
echo "</tr>";
}
?>

</table>
<?php
//delete row from table
if(isset($_GET['dl'])){

$sql="delete from category where category='$_GET[dl]';";
if($conn->query($sql)==TRUE)
{
echo "<script>window.alert('recordDeleted');
window.location='category.php'</script>";
}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";

}


?>
</div><br/>

</div><hr/>

</div>

<?php include 'footer.php'; ?>
