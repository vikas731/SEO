<?php include 'header.php'; ?>

<script src="../editor/ckeditor.js"></script>
 <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Blogpost</h2>
            </div>
          </header>
<div class="container pt-4">
<div class='row pt-3'>
    <div class='col-6'><h5> <a href="savepost.php">+NEW BLOGPOST </a></h5></div>
<div class='col-6 text-right'><h5><a href="display_blogpost.php"> VIEW POSTS</a></h5></div>
</div><hr/>
<form action="" method='post' enctype="multipart/form-data" >
<div class='row'>

<div class='col-md-9'>
<input type='text' placeholder='Post Title' name='t' required class="form-control"><br/>
<textarea rows='7' placeholder="Type Here" class="form-control" name='c' required ></textarea><br/>
</div>
<div class='col-md-3'>
<select class="form-control" name='sc' required>
<option value="" >Select Category</option>
<?php
//select data from table
$sql="select * from category order by category";
$result=$conn->query($sql);

while($row=$result->fetch_assoc())
{
echo "<option>".$row['category']."</option>";   
}
    ?>
    
</select><br/>
<label>Select image</label>
<input type="file" class="form-control" accept='.jpg,.png,.jpeg' name='img'>
<p class='text-right'> * only jpg or png files are allowed</p><br/>
<button type="submit" class="btn btn-primary" name='submit' style="background:#0674a1;">Submit</button>
<button type="reset" class="btn btn-danger" name='reset'>Reset</button>
</div>
</div>
</form>
<?php //insert data into table

if(isset($_POST['submit'])){

     $dirname="image/";
    $filename=$dirname.$_FILES['img']['name'];
    $tempname=$_FILES['img']['tmp_name'];
    $filetype=pathinfo($filename,PATHINFO_EXTENSION);
    //echo $filetype;
if($filetype=='jpg' or $filetype=='png' or $filetype=='jpeg' )
{
    if(move_uploaded_file($tempname,$filename)==TRUE)
    {
        $sql="insert into blogpost(title,image,content,category) values('$_POST[t]','$filename','$_POST[c]','$_POST[sc]');";
        if($conn->query($sql)==TRUE)
        {
            echo "<br/><div class='alert alert-success'>Record saved </div>";
        }
        else
            echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";
    }
        else
            echo "<br/><div class='alert alert-warning'>Error in File Uploading</div>";
}
else
    echo "<br/><div class='alert alert-warning'>only jpg png and jpeg allow</div>";  
}

?>

</div>


<script>CKEDITOR.replace('c');</script><!--add editor in textarea-->
<?php include 'footer.php'; ?>