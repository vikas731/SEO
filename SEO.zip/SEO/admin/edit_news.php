
<?php include 'header.php'; ?>
<script src="../editor/ckeditor.js"></script>
 <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">News</h2>
            </div>
          </header>
<?php
    //selection
$sql="select * from news where newsid='$_GET[nid]'";
$result=$conn->query($sql);
$row=$result->fetch_assoc();
?>
<div class="container pt-4">
    <div class='row pt-3'>
        <div class='col-6'><h5> <a href="news.php"> +NEW NEWS </a></h5></div>
        <div class='col-6 text-right'><h5><a href="display_news.php"> View News</a></h5></div>
    </div><hr/>
<form action="" method="post" enctype="multipart/form-data">
    <div class='row'>
        <div class='col-md-9'>
        <input type='text' placeholder='News Title' value="<?php echo $row['title'] ?>" name='t' required class="form-control"><br/>
        <input type='text' placeholder='Sub Title' value="<?php echo $row['subtitle'] ?>" name='st' required class="form-control"><br/>
        <textarea rows='7' placeholder="Type Here" class="form-control" name='c' required ><?php echo $row['content'] ?></textarea><br/>
        </div>
        <div class='col-md-3'>
            
            <img src="<?php echo $row['image'] ?>" width="200" height="120">
    
    <br/><br/>
            <label>Select image</label>
            <input type="file" class="form-control" accept='.jpg,.png,.jpeg' name="img">
            <p class='text-right'> * only jpg or png files are allowed</p><br/>
            <button type="submit" name="save" class="btn btn-primary" style="background:#0674a1;">Submit</button>
            <button type="reset" class="btn btn-danger">Reset</button>
        </div>
    </div>
</form>
    <?php //updation

if(isset($_POST['save'])){
//update file
    if(!is_uploaded_file($_FILES['img']['tmp_name']))
        $filename=$row['image'];
    else{
     $dirname="image/";
    $filename=$dirname.$_FILES['img']['name'];
    $tempname=$_FILES['img']['tmp_name'];
    $filetype=pathinfo($filename,PATHINFO_EXTENSION);
    echo $filetype;
        if($filetype=='jpg' or $filetype=='png' or $filetype=='jpeg' )
        {
            if(move_uploaded_file($tempname,$filename)==TRUE)
            $uploadok=1;
            else{
                $filename=$row['image'];
                echo "<script>window.alert('Error in File Uploading')</script>";
            }
            }
        else{
            $filename=$row['image'];
            echo "<script>window.alert('only jpg png and jpeg allow')</script>"; 
    }
    }
    //updation
       $p=$_GET['nid'];
        $sql="update news set title='$_POST[t]',subtitle='$_POST[st]',image='$filename',content='$_POST[c]' where newsid='$_GET[nid]';";
        if($conn->query($sql)==TRUE)
        {
            echo "<script>window.location='edit_news.php?nid=$p';</script>";
            
        }
        else
            echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";
    }
       


?>
</div>
<script>CKEDITOR.replace('c');</script>

<?php include 'footer.php'; ?>