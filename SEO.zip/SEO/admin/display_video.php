<?php include 'header.php'; ?>

<div class="container pt-4">

<div class="row">
<div class="col-md-1"></div>
<div class="col-md-10">
<table class="table table-striped table-bordered table-hover">
<tr><th>Title</th><th>Content</th><th>Video</th><th>Category</th><th>Added on</th><th>Edit</th><th>Del</th></tr>
<?php
$sql="select * from video order by videoid desc";
$result=$conn->query($sql);

while($row=$result->fetch_assoc())
{
    $vid=$row['videoid'];
echo "<tr>";
echo "<td>".$row['title']."</td>";
echo "<td>".$row['overview']."</td>";
echo "<td><video src='.$row[video].' width='70' height='70' controls></video></td>";
echo "<td>".$row['category']."</td>";
echo "<td>".$row['addedon']."</td>";
     echo "<td><a href='edit_video.php?vid=$vid'><i class='icofont icofont-edit'></i></a></td>";
    echo "<td><a href='display_video.php?dl=$vid'><i class='icofont icofont-delete'></i></a></td>";
echo "</tr>";
}

?>

</table>

    <?php

if(isset($_GET['dl'])){

$sql="delete from video where videoid='$_GET[dl]';";
if($conn->query($sql)==TRUE)
{
echo "<script>window.alert('Record Deleted');
window.location='display_video.php'</script>";
}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";

}


?>
</div>
<div class="col-md-1"></div>
</div>


</div>
<?php include 'footer.php'; ?>