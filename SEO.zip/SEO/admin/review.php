<?php include 'header.php'; ?>
<!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Reviews</h2>
            </div>
          </header>
<body>

<div class="container pt-4">

<div class="row">
<div class="col-md-1"></div>
<div class="col-md-10">
<table class="table table-striped table-bordered table-hover">
<tr><th>Reviews</th><th>Review by</th><th>Review date</th></tr>
<?php
$sql="select * from review,user where user.userid=review.reviewby order by reviewid desc";
$result=$conn->query($sql);

while($row=$result->fetch_assoc())
{
    
echo "<tr>";
echo "<td>".$row['reviews']."</td>";
    
echo "<td>".$row['email']."</td>";

echo "<td>".$row['reviewdate']."</td>";

}

?>

</table>


</div>
<div class="col-md-1"></div>
</div>
</div>
<?php include 'footer.php'; ?>