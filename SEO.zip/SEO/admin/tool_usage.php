<?php include 'header.php'; ?>
<?php $d=date('Y-m');   ?>
<!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Tool Usage</h2>
            </div>
          </header>
<body>
<form action="" method="post">
    <div class="row pt-3">
    <div class="col-md-1"></div>
    <div class="col-md-2 pt-3 text-right"><h3>Select Tool Name</h3></div>
    <div class="col-md-3">
        <select name="t" class="form-control" required>
            <option value=''> Select Title</option>
            <option>sourcecode</option>
            <option>image_alt</option>
            <option>inline_css</option>
            <option>email_test</option>
            <option>heading_test</option>
            <option>meta_tag</option>
            <option>sitemap</option>
            
        </select>
    </div>
    
    <div class="col-md-3"><input type="month" class="form-control" name="m" min="2019-06" max="<?php echo $d;?>"></div>
    <div class="col-md-2"><button type="submit" class="btn btn-primary" name="btn">Submit</button></div>
    <div class="col-md-1"></div>
   </div>
     </form>
<div class="container pt-4">

<div class="row">
<div class="col-md-1"></div>
<div class="col-md-10">
<table class="table table-striped table-bordered table-hover">
<tr><th>Title</th><th>Userid</th><th>Use Date</th><th>Url</th></tr>
<?php
    if(isset($_POST['btn'])){
        $mt=substr($_POST['m'],5,2);

$sql="select * from usage_rec,user where usage_rec.title='$_POST[t]' and month(usage_rec.use_date)='$mt'   and user.userid=usage_rec.userid order by us_id desc";
$result=$conn->query($sql);

while($row=$result->fetch_assoc())
{
    echo "<tr>";
echo "<td>".$row['title']."</td>";
echo "<td>".$row['email']."</td>";
echo "<td>".$row['use_date']."</td>";
echo "<td>".$row['url']."</td>";

}
    }
?>

</table>
</div>
    
<div class="col-md-1"></div>

</div>
</div>
<?php include 'footer.php'; ?>