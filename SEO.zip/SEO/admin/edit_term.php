
<?php include 'header.php'; ?>
<script src="../editor/ckeditor.js"></script>
 <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Terms & Description</h2>
            </div>
          </header>
<?php
    //selection
$sql="select * from term where termid='$_GET[tid]';";
$result=$conn->query($sql);
$row=$result->fetch_assoc();
?>
<div class="container pt-4">

<div class='row pt-3'>
<div class='col-6'><h5> +NEW TERM </h5></div>
<div class='col-6 text-right'><h5><a href="display_term.php"> VIEW TERMS</a></h5></div>
</div><hr/>
<form action="" method="post" >
<div class='row'>

<div class='col-md-12'>
<input type='text' placeholder='Term' name='t' value="<?php echo $row['term'] ?>" required class="form-control"><br/>
<textarea rows='7' placeholder="Description" name='d' class="form-control" required ><?php echo $row['description'] ?></textarea><br/>
<button type="submit" name='save'class="btn btn-primary mr-3" style="background:#0674a1;">Submit</button>
<button type="reset" name='reset' class="btn btn-danger">Reset</button>
</div>

</div>

</form>
<?php

if(isset($_POST['save'])){
  $t=$_GET['tid'];

 $sql="update term set term='$_POST[t]',description='$_POST[d]' where termid='$_GET[tid]';";  
if($conn->query($sql)==TRUE)
{
   echo "<script>window.alert('Record Updated') ;</script>";
 echo "<script>window.location='edit_term.php?tid=$t';</script>";
}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";

}
?>
</div>
<script>CKEDITOR.replace('d');</script>

<?php include 'footer.php'; ?>