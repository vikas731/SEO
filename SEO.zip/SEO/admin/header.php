<!DOCTYPE html>
<html>
  <head>
      
      <?php /*check whether admin login or not (if session value is not set then admin is not login and jump(pass) to the login page. when admin login with correct username and password then the session variable is to be set and admin can access all the pages. if session variable is to be unset then he cannot acces  all the pages of admin panel then he have to login again to set the session value)*/
      session_start();
      if(!isset($_SESSION['ad'])){
          echo "<script>window.location='../admin_login.php';</script>";
      }
      ?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Project ADMIN - PANEL </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   
    <!-- CSS files -->
    <link rel="stylesheet" href="../css/bootstrap.min.css"> 
    <link rel="stylesheet" href="../css/icofont.css">
    <link rel="stylesheet" href="../css/sidebar/style.default.css">
    <link rel="shortcut icon" href="../favicon.png">
  
  </head>
     <!-- Make connection with database(seo_db) -->
    <?php include '../db.php'; ?>
  <body>
    <div class="page">
      <!-- Main Navbar-->
      <header class="header" >
        <nav class="navbar" >
          
          <div class="container-fluid " >
            <div class="navbar-holder d-flex align-items-center justify-content-between">
              <!-- Navbar Header-->
              <div class="navbar-header" >
                <!-- Navbar Brand --><a href="#" class="navbar-brand d-none d-sm-inline-block">
                  <div class="brand-text d-none d-lg-inline-block"><span>SEO </span><strong>Dashboard</strong></div>
                  <div class="brand-text d-none d-sm-inline-block d-lg-none"><strong>BD</strong></div></a>
                <!-- Toggle Button--><a id="toggle-btn" href="#" class="menu-btn active"><span></span><span></span><span></span></a>
              </div>
              <!-- Navbar Menu -->
              <ul class="nav-menu list-unstyled d-flex flex-md-row align-items-md-center">
                <!-- Languages dropdown    
                <li class="nav-item dropdown"><a id="languages" rel="nofollow" data-target="#" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link language dropdown-toggle"><span class="d-none d-sm-inline-block">English</span></a>
                  <ul aria-labelledby="languages" class="dropdown-menu">
                    <li><a rel="nofollow" href="#" class="dropdown-item"> Option 1 </a></li>
                    <li><a rel="nofollow" href="#" class="dropdown-item"> Option 2  </a></li>
                  </ul>
                </li>-->
                <!-- Logout    -->
                  <li class="nav-item"><a href="logout.php" class="nav-link logout"> <span class="d-none d-sm-inline"> Logout</span><i class="icofont icofont-logout "></i></a></li>
              </ul>
            </div>
          </div>
        </nav>
      </header>
      <div class="page-content d-flex align-items-stretch " > 
        <!-- Side Navbar -->
        <nav class="side-navbar">
          <!-- Sidebar Header-->
          <div class="sidebar-header d-flex align-items-center">
            <div class="avatar"><img src="seo.jpg" alt="..." class="img-fluid rounded-circle"></div>
            <div class="title">
              <h1 class="h4">Admin Panel </h1>
              <p>Welcome</p>
            </div>
          </div>
          <!-- Sidebar Navidation Menus--><span class="heading">Main</span>
          <ul class="list-unstyled">
            <li class="active"><a href="index.html"> <i class="icofont icofont-dashboard text-dark" style="font-size:30px;color:#2196F3"></i>Dashboard</a></li>
           
            <li><a href="#exampledropdownDropdown" aria-expanded="false" data-toggle="collapse"> <i class="icofont icofont-contacts" style="font-size:30px;"></i>Seo Guide </a>
              <ul id="exampledropdownDropdown" class="collapse list-unstyled ">
               
                <li><a href="factor.php"><i class="icofont icofont-dashboard text-dark"></i>Imp Factors</a></li>
                  <li><a href="term.php"><i class="icofont icofont-dashboard text-dark"></i>Seo Terms</a></li>
              </ul>
            </li>
              
            
            <li><a href="#exampledropdownDropdown1" aria-expanded="false" data-toggle="collapse"><i class="icofont icofont-page" style="font-size:30px;"></i>Seo Content </a>
              <ul id="exampledropdownDropdown1" class="collapse list-unstyled ">
                <li><a href="category.php"><i class="icofont icofont-dashboard text-dark"></i>Category</a></li>
                <li><a href="savepost.php"><i class="icofont icofont-dashboard text-dark"></i>Articles</a></li>
                
                <li><a href="news.php"><i class="icofont icofont-news text-dark"></i>News</a></li>
              </ul>
            </li>
           
            <li> <a href="reg_user.php"> <i class="icofont icofont-users " style="font-size:30px;"></i>Reg Users</a></li>
            <li> <a href="tool_usage.php"> <i class="icofont icofont-tools" style="font-size:30px;"></i>Tool Usage </a></li>
          </ul><span class="heading">Message </span>
          <ul class="list-unstyled">
            <li> <a href="web_enquires.php"> <i class="icofont icofont-ui-message"></i>Web Enquires </a></li>
            <li> <a href="review.php"> <i class="icofont icofont-edit"></i>Reviews </a></li>
              <li> <a href="logout.php"> <i class="icofont icofont-logout "></i>Log out</a></li>
          </ul>
        </nav>
        <div class="content-inner">
         
         
   