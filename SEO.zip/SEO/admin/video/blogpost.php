<script src="../editor/ckeditor.js"></script>

<html>
<head>
<title>web page</title>
<link href="../css/bootstrap.min.css" rel="stylesheet">
<?php include '../db.php'; ?>


</head>
<body>

<div class="container pt-4">

<div class='row pt-3'>
<div class='col-6'><h5> +NEW BLOGPOST </h5></div>
<div class='col-6 text-right'><h5><a href="#"> View Posts</a></h5></div>
</div><hr/>
<form action="" method='post' >
<div class='row'>

<div class='col-md-9'>
<input type='text' placeholder='Post Title' name='t' required class="form-control"><br/>
<textarea rows='7' placeholder="Type Here" class="form-control" name='c' required ></textarea><br/>
</div>
<div class='col-md-3'>
<select class="form-control" name='sc'>
<option >Select Category</option>
</select><br/>
<label>Select image</label>
<input type="file" class="form-control" accept='.jpg,.png,.jpeg' name='img'>
<p class='text-right'> * only jpg or png files are allowed</p><br/>
<button type="submit" class="btn btn-primary" name='submit'>Submit</button>
<button type="reset" class="btn btn-danger" name='reset'>Reset</button>
</div>
</div>
</form>
<?php

if(isset($_POST['submit'])){

$sql="insert into blogpost(title,image,content,category) values('$_POST[t]','$_POST[img]','$_POST[c]','$_POST[sc]');";
if($conn->query($sql)==TRUE)
{
echo "<br/><div class='alert alert-success'>Record saved </div>";
}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";

}


?>

</div>

</body>
</html>
<script>CKEDITOR.replace('c');</script>