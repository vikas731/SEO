<?php include 'header.php'; ?>

<div class="container pt-4">

<div class="row">
<div class="col-md-1"></div>
<div class="col-md-10">
<table class="table table-striped table-bordered table-hover">
<tr><th>First_Name</th><th>Last_Name</th><th>About</th><th>Image</th><th>Email_Id</th><th>Phone_No</th><th>Work_Type</th><th>Del</th></tr>
<?php
$sql="select * from team order by memberid desc";
$result=$conn->query($sql);

while($row=$result->fetch_assoc())
{
     $mid=$row['memberid'];
echo "<tr>";
echo "<td>".$row['first_name']."</td>";
echo "<td>".$row['last_name']."</td>";
    echo "<td>".$row['about']."</td>";
    echo "<td>".$row['image']."</td>";
     echo "<td>".$row['emailid']."</td>";
     echo "<td>".$row['phoneno']."</td>";
     echo "<td>".$row['worktype']."</td>";
     echo "<td><a href='display_team.php?dl=$mid'><i class='icofont icofont-delete'></i></a></td>";
echo "</tr>";
}

?>

</table>

    <?php

if(isset($_GET['dl'])){

$sql="delete from team where memberid='$_GET[dl]';";
if($conn->query($sql)==TRUE)
{
echo "<script>window.alert('Record Deleted');
window.location='display_team.php'</script>";
}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";

}


?>
</div>
<div class="col-md-1"></div>
</div>


</div>
<?php include 'footer.php'; ?>