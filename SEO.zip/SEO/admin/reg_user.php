<?php include 'header.php'; ?>
<body>

<div class="container pt-4">

<div class="row">
<div class="col-md-1"></div>
<div class="col-md-10">
<table class="table table-striped table-bordered table-hover">
<tr><th>First name</th><th>Last name</th><th>Image</th><th>Phone</th><th>Email</th><th>City</th></tr>
<?php
$sql="select * from user order by userid desc";
$result=$conn->query($sql);

while($row=$result->fetch_assoc())
{
    
echo "<tr>";
echo "<td>".$row['firstname']."</td>";
echo "<td>".$row['lastname']."</td>";
echo "<td><img src='../user/".$row['image']."' width='70px' height='70px'></td>";
echo "<td>".$row['phone']."</td>";
echo "<td>".$row['email']."</td>";
    echo "<td>".$row['city']."</td>";
    
}

?>

</table>

 


</div>
<div class="col-md-1"></div>
</div>
</div>
<?php include 'footer.php'; ?>