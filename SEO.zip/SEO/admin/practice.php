<?php include '../db2.php'; ?>
<link href='../css/bootstrap.min.css' rel='stylesheet'>
<div class="container">

<form action='' method='post' >
<div class="row pt-4">
    
    <div class="col-md-6">
        <input type="text" placeholder="First name" name="fn" class="form-control"><br/>
        <input type="text" placeholder="Class" name="cl" class="form-control"><br/>
        <input type="file" name="img" class="form-control"><br/>
 

    </div>
    <div class="col-md-6">
        <input type="text" placeholder="Last name" name="ln" class="form-control"><br/>
        <input type="tel" placeholder="Phone number" name="phn" class="form-control"><br/>
        
      </div>  
    </div>
    <div class='row'>
    <div class='col-md-12'>
        <textarea placeholder='Type here' rows='7'  name='c' class='form-control' required ></textarea><br/>
    <button type="submit" name='save' class="btn btn-primary" style="background:#0674a1;">Submit</button><br/>
        </div>
    </div>

    </form>
    <?php
    if(isset($_POST['save']))
    {
    $sql="insert into form(first_name,last_name,class,phoneno,image,content)
    values('$_POST[fn]','$_POST[ln]','$_POST[cl]','$_POST[phn]','$_POST[img]','$_POST[c]');";   
    
    if($con->query($sql)==TRUE)
    {
        echo "<br/><div class='alert alert-success'>Record saved </div>";
    }
    else
  echo "<br/><div class='alert alert-warning'>Error".$con->error."</div>";
    }
    ?>
</div>