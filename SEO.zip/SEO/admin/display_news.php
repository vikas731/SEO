<?php include 'header.php'; ?>

<div class="container pt-4">

<div class="row">
<div class="col-md-1"></div>
<div class="col-md-10">
<table class="table table-striped table-bordered table-hover">
<tr><th>Title </th><th>Sub Title</th><th>Content</th><th>Image</th><th>Edit</th><th>Del</th></tr>
<?php
$sql="select * from news order by newsid desc";
$result=$conn->query($sql);

while($row=$result->fetch_assoc())
{
     $nid=$row['newsid'];
echo "<tr>";
echo "<td>".$row['title']."</td>";
echo "<td>".$row['subtitle']."</td>";
  echo "<td>".substr(strip_tags($row['content']),0,150)."</td>";
    echo "<td><img src='".$row['image']."' width='70px' height='70px'></td>";
      echo "<td><a href='edit_news.php?nid=$nid'><i class='icofont icofont-edit'></i></a></td>";
     echo "<td><a href='display_news.php?dl=$nid'><i class='icofont icofont-delete'></i></a></td>";
echo "</tr>";
}

?>

</table>

    <?php

if(isset($_GET['dl'])){

$sql="delete from news where newsid='$_GET[dl]';";
if($conn->query($sql)==TRUE)
{
echo "<script>window.alert('Record Deleted');
window.location='display_news.php'</script>";
}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";

}


?>
</div>
<div class="col-md-1"></div>
</div>


</div>
<?php include 'footer.php'; ?>