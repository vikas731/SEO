<?php session_start(); ?>
 <?php include 'db.php' ?>
<html>
<head>
    <title>Sign in
    </title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet" href="css/icofont.css">
    </head>
<body>
    <div class="container">
        <div class="row  mt-5 pt-5 pb-5" style="background-color:f4f4f4;" >    
            <div class="col-lg-2"></div>
            <div class="col-lg-8 pt-3 pb-3">
            <div class="row " style="box-shadow:2px 2px 2px #000" >
            <div class="col-lg-6 p-5" style="background-color:ffffff; ">
                 <h3>SEO</h3><br/>
                <form action="" method="post">
                <label>Username or Email</label>
                 <input type="email" class="form-control rounded-0" name="em" style="border:none; border-bottom:1px solid black;" required>  <br/>
                    <label>Password</label><br/>
                 <input type="password" class="form-control rounded-0" name="pwd" style="border:none;border-bottom:1px solid black;"required ><br/><br/>
                    <button  type="submit" class="btn btn-primary btn-block" name="save">Sign in</button><br/>
                       <p class="text-center">New User?<a href="sign_up.php" style="text-decoration:none;"> Sign Up</a></p>
                </form>              
                 <?php
        if(isset($_POST['save'])){
            $pw=md5($_POST['pwd']);
            $sql="select * from user where email='$_POST[em]' and password='$pw';";
            $result=$conn->query($sql);
            if($result->num_rows>0){
                $row=$result->fetch_assoc();   
                $_SESSION['uid']=$row['userid'];
                $_SESSION['em']=$row['email'];
                if(isset($_GET['page'])){     
                    if($_GET['page']=='sourcecode')
                    echo "<script>window.location='htmlsv.php';</script>";
                    else if($_GET['page']=='image_alt')
                    echo "<script>window.location='image_alt_test.php';</script>";
                    else if($_GET['page']=='inline_css')
                    echo "<script>window.location='inline_css_test.php';</script>";
                    else if($_GET['page']=='email_test')
                    echo "<script>window.location='email_test.php';</script>";
                    else if($_GET['page']=='heading_test')
                    echo "<script>window.location='heading_test.php';</script>";
                    else if($_GET['page']=='meta_tag')
                    echo "<script>window.location='meta_tag_extractor.php';</script>";
                    else if($_GET['page']=='sitemap')
                    echo "<script>window.location='sitemap_test.php';</script>";
                     else if($_GET['page']=='link_extractor')
                    echo "<script>window.location='Link_Extractor.php';</script>";
                    
                }
                else
                echo "<script>window.location='user/profile.php';</script>";
            }
                
            else
                echo "<br/><div class='alert alert-warning'>Invalid Email or Password</div>";
        }      
            ?>    
                </div>    
            <div class="col-lg-6 " style="background-image:url('login.jpg'); background-size:cover">
                </div>
        </div>
                </div>    
            <div class="col-lg-2">  
                <form >
                <a href="index.php" class="btn btn-primary" style="bottom:-30px; right:40px; position:absolute;" >Back Home</a>
                </form>
            </div>
        </div>
    </div>
    </body>
</html>