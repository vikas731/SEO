<?php include'header.php' ?>
<div class="container-fluid">
 <div class="row"> 
            <div class='col-md-12 text-center bg-light pt-5 pb-5'> 
            <h5> Latest Articles / Blog </h5>
            <h6> <a href='index.php' style="color:#f9a32a "> Home </a> <i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i>  Blog </h6>
            
            </div>
</div>
</div>
 
    
    <div class="container">
        <div class="row  pt-5">
  <?php
//selection
$sql="select * from blogpost where postid='$_GET[id]'";
$result=$conn->query($sql);

$row=$result->fetch_assoc();
    
    $pid=$row['postid'];
    ?>
            <div class="col-md-9 pt-3">
            <h3 class='pb-2'> <?php echo $row['title']; ?></h3>
                
             <p>
             <i class="icofont icofont-calendar"></i> <?php echo $row['addedon']; ?>&nbsp;
               <i class="icofont icofont-tag"></i> <?php echo $row['category']; ?>
            </p>

            <img src="admin/<?php echo $row['image']; ?>" width="70%" height="350">
                <p><?php echo $row['content']; ?></p>
           
    </div>
</div>
<?php include'footer.php' ?>