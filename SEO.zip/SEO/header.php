<?php session_start(); ?>
<!DOCTYPE html>
<html>
  <head>
    <!-- CSS files -->
    <link rel="stylesheet" href="css/bootstrap.min.css"> 
    <link rel="stylesheet" href="css/icofont.css">  
  </head>
     <!-- Make connection with database(seo_db) -->
    <?php include 'db.php'; ?>
      <style>
          .footer{bottom:0px; position:absolute;} 
    </style>
  <body>
      <div class="container-fluid ">
      <div class="row pt-3 pb-2">
          <div class="col-md-6">
               <h2 style="font-weight:bold;"><a href="index.php" style="text-decoration:none;">SE<i class="icofont icofont-search " style="color:#f9a32a"></i> <span style="color:#0674a1; font-weight:bold;">KIT</span> </a></h2>
          </div>
          <?php if(!isset($_SESSION['uid'])){ ?>
          <div class="col-md-6 pt-2">
         <h5 class="text-right" ><a href="sign_up.php" style="text-decoration:none;"><i class="icofont icofont-user " style="color:#f9a32a"></i>Register</a> &nbsp;
             <a href="sign_in.php" style="text-decoration:none;"><i class="icofont icofont-login " style="color:#f9a32a"></i>Login</a>&nbsp;</h5>  
          </div>
            <?php } else { ?>
          <div class="col-md-6 pt-2">
              <?php
            $sql="select * from user where userid='$_SESSION[uid]';";
            $result=$conn->query($sql);
            $row=$result->fetch_assoc();
              ?>
         <h5 class="text-right"><a href="user/profile.php" style="text-decoration:none;"><i class="icofont icofont-user " style="color:#f9a32a"></i>
             <?php if($row['firstname']=="")
               echo  "User".$_SESSION['uid'];
                 else
               echo ucfirst($row['firstname']);
                ?></a> &nbsp;
             <a href="user/logout.php" style="text-decoration:none;"><i class="icofont icofont-login " style="color:#f9a32a"></i>Logout</a>&nbsp;</h5>
          </div>
          <?php }  ?>
          </div></div>
    <nav class="navbar navbar-expand-lg navbar-dark " style="background:#0674a1">
  
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav ml-auto mr-auto ">
       <li class="nav-item active">
        <a class="nav-link" href="about.php">About us</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="allterm.php?lt=A">Glossary</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="allfactor.php">Factor</a>
      </li>
    <li class="nav-item dropdown active">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          SEO Tools
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          
          
              <a class="dropdown-item" href="image_alt_test.php">Image Alt Test</a>
             <a class="dropdown-item" href="heading_test.php">Heading Test</a>
             <a class="dropdown-item" href="inline_css_test.php">Inline Css Test</a>
             <a class="dropdown-item" href="meta_tag_extractor.php">Meta Tag Extractor</a>
              <a class="dropdown-item" href="Link_Extractor.php">Link Extractor</a>
        </div>
      </li>
    
    
      <li class="nav-item active">
        <a class="nav-link" href="allblog.php">Blog</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="allnews.php">News</a>
      </li>
   
      <li class="nav-item active " >
         <a class="nav-link" href="contact_us.php"><i class="icofont icofont-phone " style="color:#f9a32a"></i>Contact us</a>
        </li>
    </ul>    
  </div>
      </nav>
   