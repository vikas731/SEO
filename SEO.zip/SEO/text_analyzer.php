<?php include 'header.php' ?>
<div class="container-fluid">
    <div class="row"> 
            <div class='col-md-12 text-center bg-light pt-5 pb-5'> 
            <h5> Text Analyzer  </h5>
                <h6> <a href='index.php' style="color:#f9a32a "> Home </a> <i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i> Other Tools <i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i> Text Analyzer </h6>
            
            </div>
    </div></div>
    <div class="container pt-5" style="min-height:500px">
        <div class="row">
            <div class="col-md-12">
          
               
                <p class="text-justify">This text analysis tool provides information on the readability and complexity of the text, as well as statistics on word frequency and character count. This can be useful when preparing text that needs to been a certain number of words or character. It can also help you to determine information about the readability of text such as average word length. You can use this online word counter to not just count word, character, space.<br/>Enter or paste your text to analyze in a box blew then click on Analyze</p>
                
            </div>
        </div>
        <div class="row pt-2">
        
            <div class="col-md-12 pt-4 pb-4 bg-light"><h5 class='pb-2'>Type Your Text Here (max length 3000 char) </h5>
                <form action="" method="post">
                   <textarea rows="7" class="form-control" name="text" maxlength="3000" required></textarea><br/>
                    <button type="submit" class="btn btn-primary " name="a">Analyze</button>
                    
                    
                    <button type="reset" class="btn btn-primary " name="r">Reset</button>
                    
                </form>
 
<?php

if(isset($_POST['a'])){
$txt=$_POST['text'];
$len=strlen($txt);
$wrd=str_word_count($txt);
$sp=substr_count($txt,' ');
    

 ?>
        </div>
            </div>
    
            <br/>

      <div class="row">
        <div class="col-md-9">
            <table class="table table-hover">
                    <?php
                echo "<tr><th>Total Length : </th>";
    echo "<td>".$len."</td></tr>";
     echo "<tr><th>Total Word : </th>";
     echo "<td>".$wrd."</td></tr>";
     echo "<tr><th>Spaces : </th>";
     echo "<td>".$sp."</td></tr>";
                ?>
            
            </table>
           
          </div>
         
          <div class="col-md-3"></div>
            </div>  
             <?php } ?>
    </div>
<?php include 'footer.php' ?>
           <!-- <div class="col-md-6 pt-4">
                <h5>What is URL Encoding?</h5>
                <p>URL Encoding also known as Percent-encoding, convert characters into a format that can be transmitted over the internet. URL Encoding is basically used within the main Uniform Resource Identifier (URI) which include both Uniform Resource Locator (URL) and Uniform Resource Name (URN). In URL Encoding, all non-alphanumeric character except - _ . are replaced with a percent (%) sign followed by two hex digits and spaces encoded as plus (+) sign.</p>
                
    
                 Button trigger modal 
<a href='#' data-toggle="modal" data-target="#exampleModalScrollable">
  Know More About Encode Decode URL 
</a>

<!-Modal ->
<div class="modal fade" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalScrollableTitle">HTML Source Viewer</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          
             <h5>Why and when would you use URL Encoding?</h5>
                <p>When the URL contain a character from the Reserved Character, then the character must be encoded. It is necessary and you should always encode any special characters found in URL.</p>
          
          
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          
      </div>
    </div>
  </div>
</div>-->
            
        
      
