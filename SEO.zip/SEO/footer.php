
<div class="container-fluid pt-5 pb-5 mt-4 "  style="background-image:url('footerbg.jpg')" ><!--style="background-color:lightgrey;"-->
    <div class="container">
    <div class="row">
      
       
        <div class="col-md-3" >
        <h3> SEO KIT </h3><br/>
            <p> We at SEO-KIT bring you the most reliable results so you can have the best materials that you can use for your website or content, SEO-KIT will provide you with all the things you need to make your website and content highly competitive</p>
            
            <a href="about.php" name="save" class="btn" style='background:#0674a1; color:#fff'>Read More</a>
        </div>
          <div class="col-md-2" >
        <h5>Site Pages </h5><br/>
      <ul type='circle' style="color:#f9a32a">         
          
  <li> <a href='allterm.php?lt=A' style="color:#222; text-decoration:none"> Glossary </a></li>

  <li> <a href='allfactor.php' style="color:#222; text-decoration:none"> Factor </a></li>



  <li> <a href='allblog.php' style="color:#222; text-decoration:none"> Blog</a></li>

  <li> <a href='allnews.php' style="color:#222; text-decoration:none"> News </a></li>

  

    </ul>          
        
        </div>
        <div class="col-md-3" >
        <h5>SEO Tools </h5><br/>
      <ul type='circle' style="color:#f9a32a">         
          <li> <a href='image_alt_test.php' style="color:#222; text-decoration:none"> Image Alt Test </a></li>
   <li> <a href='heading_test.php' style="color:#222; text-decoration:none"> Heading Test</a></li>
  <li> <a href='inline_css_test.php' style="color:#222; text-decoration:none"> Inline Css Test  </a></li>
   
  <li> <a href='meta_tag_extractor.php' style="color:#222; text-decoration:none"> Meta Tag  </a></li>
          
  <li> <a href='Link_Extractor.php' style="color:#222; text-decoration:none"> Link Extractor  </a></li>

  

    </ul>          
        
        </div>
        
        
        
        
        
        
          <div class="col-md-2" >
<h5><strong> Location</strong></h5><br/>
<p><i class="icofont icofont-pin" style="font-size:25px;color:#f9a32a;" ></i>265 Yorkland Blvd., Suite 400
Toronto, ON M2J 1S5</p>
<h2>Call Center</h2>
<p><i class="icofont icofont-phone" style="font-size:25px;color:#f9a32a;"></i>+1 4196452135</p>

</div>
      
        </div>
    </div>
     <script src="js/jquery-3.3.1.min.js"></script>
<script src='js/popper.min.js'></script>
<script src='js/bootstrap.min.js'></script>
    

</body> 


</html>