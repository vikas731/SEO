<?php include 'header.php' ?>
<div class="container-fluid">
     <div class="row"> 
            <div class='col-md-12 text-center bg-light pt-5 pb-5'> 
            <h5> Plaintext Emails Test</h5>
            <h6> <a href='index.php' style="color:#f9a32a "> Home </a><i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i> Site Test <i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i>Emails Test </h6>
            
            </div>
    </div></div>
    <div class="container pt-5" style="min-height:500px">
        <div class="row">
            <div class="col-md-12">
           
                <p>Check your webpage for plaintext email addresses. Any e-mail address posted in public is likely to be automatically collected by computer software used by bulk emailers (a process known as e-mail address harvesting). A spam harvester can read through the pages in your site and extract plaintext email addresses which are then added to bulk marketing databases (resulting in more inbox spam). There are several methods for email obfuscation.</p>
            </div>
        </div>
        <div class="row pt-2">
        
            <div class="col-md-6 pt-5 pb-5  bg-light"><h5 class='pb-2'>Enter your Website url</h5>
                <form action="" method="post">
                    <input type="url" placeholder="Enter Website url" name="url" class="form-control" required><br/>
                    <button type="submit" class="btn btn-primary " name="submit">Submit</button>
                </form>
          
            </div>
            <div class="col-md-6 pt-4">
               
                <h5>How do I fix it?</h5>
                <p>In order to pass this test you must make your email addresses invisible to email spiders. Note that the best option is to replace your entire contact mechanism with a contact form and using the POST method while submitting the form.</p>
                <p>Other solutions are listed below:</p>
                <ul>

       <li> replace the at (@) and dot (.) characters</li>
    <li>replace text with images</li>
    <li>use email obfuscators</li>
    <li>hide email addresses using JavaScript or CSS trick</li>
    </ul>
   
            </div>
        </div>
        <div class="row">
        <div class="col-md-12">
            
                                         <?php
//insertion
if(isset($_POST['submit'])){
if(!isset($_SESSION['uid']))
    echo "<script> window.location='sign_in.php?page=email_test';</script>";
    else{

$sql="insert into usage_rec(title,url,userid) values('email_test','$_POST[url]','$_SESSION[uid]');";
if($conn->query($sql)==TRUE)
{
    $url=$_POST['url'];
@$text=file_get_contents($url);
$res = preg_match_all("/[a-z0-9]+[_a-z0-9.-]*[a-z0-9]+@[a-z0-9-]+(.[a-z0-9-]+)*(.[a-z]{2,4})/i",$text,$matches);
if ($res) {
foreach(array_unique($matches[0]) as $email) {
echo $email . "<br />";
} }
else {
echo "No emails found.";
} 

}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";
}}
 ?>      
            </div>
        </div>
        </div>

<?php include 'footer.php' ?>