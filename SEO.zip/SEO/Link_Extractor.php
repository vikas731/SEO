<?php include 'header.php' ?>
<div class="container-fluid">
     <div class="row"> 
            <div class='col-md-12 text-center bg-light pt-5 pb-5'> 
            <h5> Link Extractor</h5>
            <h6> <a href='index.php' style="color:#f9a32a "> Home </a> <i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i> SEO Tools <i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i>Link Extractor </h6>
            
            </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
            
                <p>Link Extractor is SEO tool let you get a list of the links of a web page.The link text and the link line in your page html code are showed. Its important to have knowledge about all link on your webpage. Extract all internal/external links from any webpage.
</p>
<p>Like other SEO tools here it completely scrape content from user inputed url/webpage. All the anchor text & linked webpage from the inputed webpage get into a order one by one. It shows all link on a webpage. It will help in a way like you can see structure of webpages which may be a wrong way for SEO purpose.</p>
            </div>
        </div>
</div>
         <div class="container pt-5" style="min-height:400px">
        <div class="row">
            <div class="col-md-12">
                <form action="" method="post">
                    <input type="url" placeholder="Enter Website url" name="url" class="form-control" required><br/>
                    <button type="submit" class="btn btn-primary " name="submit">Submit</button>
                </form>

           
            </div></div><br/>
        <div class="row">
             <div class="col-md-12">
                 <table class="table">
                                          <?php
//insertion
if(isset($_POST['submit'])){
if(!isset($_SESSION['uid']))
    echo "<script> window.location='sign_in.php?page=link_extractor';</script>";
    else{
$sql="insert into usage_rec(title,url,userid) values('link_extractor','$_POST[url]','$_SESSION[uid]');";
if($conn->query($sql)==TRUE)
{
$url=$_POST['url'];
@$html = file_get_contents($url);
$doc = new DOMDocument();
@$doc->loadHTML($html);
$tags = $doc->getElementsByTagName('a');
if(count($tags)==0)
echo count($tags)." Record Found  Check Your URL Again";
else {
foreach ($tags as $tag) {
$l=$tag->getAttribute('href');
if(substr($l,0,4)=="http")
 echo "<tr><td> <a href='".$l."' target='_blank'>".$l."</a></td> </tr>";
else
echo "<tr><td>".$l."</td> </tr>";
}  

}}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";
}}
 ?>       
                     </table>
            </div>
             </div>
        </div>
</div>
<?php include 'footer.php' ?>