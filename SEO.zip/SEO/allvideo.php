<?php include'header.php' ?>
<div class="container-fluid">
        <div class="row"> 
            <div class='col-md-12 text-center bg-light pt-5 pb-5'> 
            <h5> Videos </h5>
            <h6> <a href='index.php' style="color:#f9a32a "> Home </a> <i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i>  Videos </h6>
            
            </div>
</div>
</div>
    
    <div class="container">
        <div class="row  pt-5">
  <?php
//selection
$sql="select * from video order by videoid desc";
$result=$conn->query($sql);

while($row=$result->fetch_assoc())
{
    
    $vid=$row['videoid'];
    ?>
          <div class="col-md-4 pb-4">
            
            <div class="card">
              <video src="admin/<?php echo $row['video']; ?>" width="95%" height="250" class="card-img-top" alt="..." ></video>
                <div class="card-body">
           <div style="min-height:300px">
                <h5 class="card-title"> <?php echo $row['title']; ?></h5>
                <p class="card-text text-justify"><?php echo substr(strip_tags($row['overview']),0,350); ?></p>
                    </div>
            <?php   echo "<a href='video.php?id=$vid' class='btn btn-outline-dark'>Read More</a>" ?>
            </div>
            </div>
            </div>
<?php } ?>
    </div>
</div>
<?php include'footer.php' ?>