<?php include'header.php' ?>
<body>
 
    
    <div class="container">
        <div class="row  pt-5">
  <?php
//selection
$sql="select * from video where videoid='$_GET[id]';";
$result=$conn->query($sql);

$row=$result->fetch_assoc();
    
    $vid=$row['videoid'];
    ?>
            <div class="col-md-9 pt-3">
            <h3 class='pb-2'> <?php echo $row['title']; ?></h3>
                
             <p>
             <i class="icofont icofont-calendar"></i> <?php echo $row['addedon']; ?>&nbsp;
               <i class="icofont icofont-tag"></i> <?php echo $row['category']; ?>
            </p>

                <video src="admin/<?php echo $row['video']; ?>" width="70%" height="350" controls></video>
                <p><?php echo $row['overview']; ?></p>
           
    </div>
</div>
<?php include'footer.php' ?>