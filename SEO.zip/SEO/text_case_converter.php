<?php include 'header.php' ?>
<script>
function myFunction() { 
var copyText= document.getElementById("txt"); 
copyText.select(); 
document.execCommand("copy"); 
alert("Copied the text")     //" + copyText.value
}

</script>
<div class="container-fluid">
    <div class="row"> 
        <div class='col-md-12 text-center bg-light pt-5 pb-5'> 
            <h5> Text Case Converter  </h5>
                <h6> <a href='index.php' style="color:#f9a32a "> Home </a> <i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i> Other tools <i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i> Text Case Converter </h6>
            
            </div>
    </div></div>
    <div class="container pt-5" style="min-height:500px">
        <div class="row">
            <div class="col-md-12">
          
                <p>Accidentally left the caps lock on and typed something, but can't be bothered to start again and retype it all?.
                    Simply enter your text and choose the case you want to convert in to.<a href='#' data-toggle="modal" data-target="#exampleModalScrollable" style="text-decoration:none;">
 Read more 
</a></p>
   

                                <!-- Button trigger modal -->

                <!-- Modal -->
<div class="modal fade" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalScrollableTitle">Text Case Converter</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

      
          <p>Case Converter is a simple free online tool that converts any text to either lower case, upper case, title case. Text Case Converter is a handy web application that allows you to change text case of any text easily to upper case, lower case or title case. Simply paste the text you want to convert into the text area below, click on one of the buttons and let the tool to do the work for you..</p>
          
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
    
      </div>
    </div>
  </div>
</div>
               
                
            </div>
        </div>
        <div class="row pt-0">
        
            <div class="col-md-12 pt-4 pb-4 bg-light"><h5 class='pb-2'>Type Your Text Here (Max Limit 3000 Char)</h5>
                <form action="" method="post">
                   <textarea rows="7" class="form-control" name="text" required maxlength="3000"></textarea><br/>
                    <button type="submit" class="btn btn-primary " name="u">Upper</button>
                    
                    <button type="submit" class="btn btn-primary" name="l">Lower</button>
                      <button type="submit" class="btn btn-primary " name="c">Capitalize</button>
                    <button type="reset" class="btn btn-secondary" name="r">Reset</button>
                    
                </form>
                <br/>
                <h5 class='pb-2'>Converted Text</h5>
                                   <a type="button" onclick="myFunction()" class="btn btn-primary">Copy</a>

                    <textarea id="txt" rows="7" class="form-control" readonly >
			<?php
                       if(isset($_POST['u']))
                         echo strtoupper($_POST['text']);
                       if(isset($_POST['l']))
                         echo strtolower($_POST['text']);
                       if(isset($_POST['c']))
                         echo ucwords($_POST['text']);
                        ?>
                    </textarea><br/>
                   

                






            </div>
           <!-- <div class="col-md-6 pt-4">
                <h5>What is URL Encoding?</h5>
                <p>URL Encoding also known as Percent-encoding, convert characters into a format that can be transmitted over the internet. URL Encoding is basically used within the main Uniform Resource Identifier (URI) which include both Uniform Resource Locator (URL) and Uniform Resource Name (URN). In URL Encoding, all non-alphanumeric character except - _ . are replaced with a percent (%) sign followed by two hex digits and spaces encoded as plus (+) sign.</p>
                
    
                 Button trigger modal 
<a href='#' data-toggle="modal" data-target="#exampleModalScrollable">
  Know More About Encode Decode URL 
</a>

<!-Modal ->
<div class="modal fade" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalScrollableTitle">HTML Source Viewer</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          
             <h5>Why and when would you use URL Encoding?</h5>
                <p>When the URL contain a character from the Reserved Character, then the character must be encoded. It is necessary and you should always encode any special characters found in URL.</p>
          
          
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          
      </div>
    </div>
  </div>
</div>-->
            </div>
        </div>
        
    

<?php include 'footer.php' ?>