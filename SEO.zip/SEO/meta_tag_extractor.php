<?php include 'header.php' ?>
<div class="container-fluid">
    <div class="row"> 
            <div class='col-md-12 text-center bg-light pt-5 pb-5'> 
            <h5>Meta Tag Extractor</h5>
            <h6> <a href='index.php' style="color:#f9a32a "> Home </a><i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i> SEO Tools<i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i> Meta Tag Extractor</h6>
            
            </div>
    </div></div>
    <div class="container pt-5" style="min-height:500px">
        <div class="row">
            <div class="col-md-12">
                <p>This Meta Tags Analyzer tool checks meta tags of your website and provide the report. Simply enter your website URL and the SEO Analyzer Tool will extract SEO meta tags from the given URL. This tool will generate a search engine heath report based on the meta title, meta keyword, and discription.</p>

<p>Also, the preview of your website in search Engine would appeare under the SEO heah report. The SEO meta tags analysis report is applicable for all search engine, like Google, yahoo.bing,etc.
</p>
     </div>
        </div>
        <div class="row pt-2">
        
            <div class="col-md-6 pt-5 pb-5 bg-light"><h5 class='pb-2'>Enter your Website url</h5>
                <form action="" method="post">
                    <input type="url" placeholder="Enter Website url" name="url" class="form-control" required><br/>

 <button type="submit" class="btn btn-primary "  name="submit">Submit</button>


                </form>
            
       </div>
            <div class="col-md-6 pt-4">
                <p>This simple tool shows how tools are. There are many time you want to view the HTML of the website to find out more about page. HTML source viewer is simple yet powerful utility for viewing the actual html source code for a given web page.</p>
    
                <!-- Button trigger modal -->
<a href='#' data-toggle="modal" data-target="#exampleModalScrollable">
  Know More About Meta Tag Extractor
</a>

<!-- Modal -->
<div class="modal fade" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalScrollableTitle">HTML Source Viewer</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

      <h5>What are Meta Tags?</h5> 
          <p>Meta tags are snippest of text thet describe the web page content. Meta tags don't display in the web page, it is used by the search engines. The Meta Tags help search engine(yahoo,bing,google etc) to understand about web pages.</p>
          <h5>About Get Source Code of Webpage</h5>
          <p>Underneath a professionally designed website, lies your page source code. It is the code that your browser transforms into a rich experience for users. Search engines like Google, "read" this code to figure out where your site pages should show up in their indexes for a given search query.</p>
          <h5>How Meta Tags help SEO?</h5>
          <p>For SEO main 3 meta tags are used title,keyword, and discription. When the user searches a term in Google Search. Google finds the website with the relevant content and list the relavent sites in the search result. The Meta Tags help Google to Know about the web page content and list the relavent website based on search.

</p>
        <p> Major used Meta Tags for SEO are discribed below.</p>
 <p><strong>Title Tag :</strong> The &lt; title &gt;tag tell s the user and search engines about the topic of a web page. It appear at the top of the browser and search listing. Use a brief and descriptive title for better search engine visibility. Google basically display first 50-60 characters of a title tag. so, keep title length under 60 character.</p>


 <p><strong>Description Meta Tag :</strong> The description meta tag gives Google and other search engines a brief description about a web page.it appear in the searc listing under the title. Google basically display first 150-160 characters of a description tag. so, keep description length under 160 character.</p>


 <p><strong>Keyword Meta Tags :</strong> The keyword meta teg tells the topic of the website to search engines. Keyword are a group of separated by a comma(,) and work behind the secne. Keep Keywords length under 10 words for a better result.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
    
      </div>
    </div>
  </div>
</div>
            </div>
        </div>
        <div class="row">
        <div class="col-md-12">
            <table class="table">
                            <?php
//insertion
if(isset($_POST['submit'])){
if(!isset($_SESSION['uid']))
    echo "<script> window.location='sign_in.php?page=meta_tag';</script>";
    else{
$sql="insert into usage_rec(title,url,userid) values('meta_tag','$_POST[url]','$_SESSION[uid]');";
if($conn->query($sql)==TRUE)
{
    
function getmeta($l){
$tags = get_meta_tags($l);
if(isset($tags['keywords']))
echo "<br/><b>keyword : </b>".$tags['keywords'];  
else
echo "<br/><b>keyword :</b>  ---- ";  
if(isset($tags['description']))
echo "<br/><b>Description : </b>".$tags['description'];  
else
echo "<br/><b>Description : </b> ---- ";  

}

$url=$_POST['url'];
$html = file_get_contents($url);
$doc = new DOMDocument();
@$doc->loadHTML($html);
$tags = $doc->getElementsByTagName('a');
foreach ($tags as $tag) {
$l=$tag->getAttribute('href');

if(substr($url,0,12)==substr($l,0,12)){
echo "$url".$l;
 getmeta($l);
}

}}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";
}}
 ?>               
    </table>  
            
            </div>
        </div>
        </div>
<?php include 'footer.php' ?>          