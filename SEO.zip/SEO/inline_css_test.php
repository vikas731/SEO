<?php include 'header.php' ?>
<div class="container-fluid">
    <div class="row"> 
            <div class='col-md-12 text-center bg-light pt-5 pb-5'> 
            <h5>Inline CSS Test </h5>
                <h6> <a href='index.php' style="color:#f9a32a "> Home </a> <i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i> Site Test <i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i> Inline CSS Test </h6>
            
            </div>
    </div></div>
    <div class="container pt-5" style="min-height:500px">
        <div class="row">
            <div class="col-md-12">
                <p>Check your webpage HTML tags for inline CSS properties. Inline CSS property are added by using the style attribute within specific HTML tags. Inline CSS properties unnecessarily increase page size, and can be moved to an external CSS stylesheet. Removing inline CSS properties can improve page loading time and make site maintenance easier.</p>
            </div>
        </div>
        <div class="row pt-2">
        
            <div class="col-md-6 pt-5 pb-5  bg-light"><h5 class='pb-2'>Enter your Website url</h5>
                <form action="" method="post">
                    <input type="url" placeholder="Enter Website url" name="url" class="form-control" required><br/>
                    <button type="submit" class="btn btn-primary " name="submit">Submit</button>
                </form>
 
            </div>
            <div class="col-md-6 pt-4">
                <p>It is a good practice to move all the inline CSS rules into an external file in order to make your page "lighter" in weight and decrease the code to text ratio.</p>
                <ul>

    <li>check the HTML code of your page and identify all style attributes</li>
    <li>for each style attribute found you must properly move all declarations in the external CSS file and remove the style attribute</li>
    </ul>
                   <!-- Button trigger modal -->
<a href='#' data-toggle="modal" data-target="#exampleModalScrollable">
  Click here for example 
</a>

<!-- Modal -->
<div class="modal fade" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalScrollableTitle">Img Alt Tag</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
<h5>For example:</h5>

&lt;!--this HTML code with inline CSS rule:--&gt;
<p>&lt;p style="color:red; font-size: 12px"&gt;some text here&lt;/p&gt;</p>

&lt;!--would became:--&gt;<br/>
&lt;p&gt;some text here&lt;/p&gt;<br/><br/>
&lt;!--and the rule added into your CSS file:--&gt;<br/>
<p>p{color:red; font-size: 12px}</p>

      
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
    
      </div>
    </div>
  </div>

    </div></div>
            
        </div><br/>
        <div class="row">
        <div class="col-md-12">
            <table class="table">
                
                                         <?php
//insertion
if(isset($_POST['submit'])){
if(!isset($_SESSION['uid']))
    echo "<script> window.location='sign_in.php?page=inline_css';</script>";
    else{
$sql="insert into usage_rec(title,url,userid) values('inline_css','$_POST[url]','$_SESSION[uid]');";
if($conn->query($sql)==TRUE)
{
   $url=$_POST['url'];
@$html = file_get_contents($url);
@$doc = new DOMDocument();
@$doc->loadHTML($html);
$els = $doc->getElementsByTagName('*');
echo "<tr><th>Line No.</th><th>Tag Name</th><th>Inline CSS</th></tr>";
for($i = 0; $i < $els->length; $i++){
if($els->item($i)->hasAttribute('style')){
echo "<tr>"; 
echo  " <td>".$els->item($i)->getLineNo()."</td>";
echo " <td> ".$els->item($i)->tagName."</th>";
echo "<td>".$els->item($i)->getAttribute('style')."</td>";
echo "</tr>"; 
 } }

}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";
}}
 ?>    
      </table>
            </div>
        </div>
        </div>
 
<?php include 'footer.php' ?>