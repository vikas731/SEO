<?php include'header.php' ?>
<body>
 
<div class="container pt-4">

<div class="row">
<div class="col-md-1"></div>
<div class="col-md-10">
<table class="table table-striped table-bordered table-hover">
<tr><th>Term</th><th>Description</th><th>Edit</th><th>Delete</th></tr>
<?php
$sql="select * from term order by termid desc";
$result=$conn->query($sql);

while($row=$result->fetch_assoc())
{
     $tid=$row['termid'];
echo "<tr>";
echo "<td>".$row['term']."</td>";
echo "<td>".$row['description']."</td>";
     echo "<td><a href='edit_term.php?tid=$tid'><i class='icofont icofont-edit'></i></a></td>";
     echo "<td><a href='display_term.php?dl=$tid'><i class='icofont icofont-delete'></i></a></td>";
echo "</tr>";
}

?>

</table>

    <?php

if(isset($_GET['dl'])){

$sql="delete from term where termid='$_GET[dl]';";
if($conn->query($sql)==TRUE)
{
echo "<script>window.alert('Record Deleted');
window.location='display_term.php'</script>";
}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";

}


?>
</div>
<div class="col-md-1"></div>
</div>


</div>
<?php include'footer.php' ?>



 