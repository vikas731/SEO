<?php session_start(); ?>
 <?php include 'db.php' ?>
<html>
<head>
    <title>Sign up
    </title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/icofont.css">
     
    </head>
    <?php use PHPMailer\PHPMailer\PHPMailer;use PHPMailer\PHPMailer\Exception;?>
<body>
    <div class="container">
        <div class="row  mt-5 pt-5 pb-5" style="background-color:f4f4f4;">
            <div class="col-lg-2"></div>
            <div class="col-lg-8 pt-3 pb-3">
            <div class="row" style="box-shadow:2px 2px 2px #000" >
            <div class="col-lg-6 p-5" style="background-color:ffffff;">
                 <h3>SEO</h3><br/>
                <form action="" method="post">
                <label> Email</label>
                 <input type="email" class="form-control rounded-0" name="em" style="border:none; border-bottom:1px solid black;" required ><br/>
                    <label>Password</label>
                 <input type="password" class="form-control rounded-0" name="pwd" style="border:none;border-bottom:1px solid black;"required ><br/>
                      <label>Rewrite Password</label>
                 <input type="password" class="form-control rounded-0" name="rpwd" style="border:none;border-bottom:1px solid black;" required ><br/><br/>

                    <button  type="submit" class="btn btn-primary btn-block" name="save" style="background:#0674a1;">Sign up</button>
                    
                    <p style="text-align:center;">Already User<a href="sign_in.php">Sign in</a></p>
                </form>
                </div>
            <div class="col-lg-6 " style="background-image:url('login.jpg'); background-size:cover">

                </div>
        </div>
                </div> 
            
            <div class="col-lg-2">
                <a href="index.php"><button type="submit" class="btn btn-primary" style="bottom:-30px; right:40px; position:absolute;" >Back Home</button> </a>        
            </div>
                       <?php
        if(isset($_POST['save'])){
            if($_POST['pwd']==$_POST['rpwd'])
           {
                $sql="select * from user where email='$_POST[em]'";
                $result=$conn->query($sql);
                if($result->num_rows>0)
                   echo "<br><div class='alert alert-warning'>Account Already Exist...</div>";
               else
                   {
                   $pw=md5($_POST['pwd']);
               $sql="insert into user(email,password) values('$_POST[em]','$pw')";
               if($conn->query($sql)==TRUE)
               {                 
// require 'PHPMailer-master/src/Exception.php';
//require 'PHPMailer-master/src/PHPMailer.php';
//require 'PHPMailer-master/src/SMTP.php';         
//$mail = new PHPMailer(true);
//$email='ak99887972@gmail.com';
//$password='Ajay@30470';
//$to_id=$_POST['em'];
//$subject='Welcome to SEO Services';
//
//$message='<h4> Hello User </h4><br/> <p> Thanks for Join Our SEO Services </p> <br/> <h5> Regards : Seo Team </h5>';
//try {
//    $mail->isSMTP();   
//    $mail->SMTPDebug = 0;
//    $mail->Host = 'smtp.gmail.com';
//    $mail->SMTPAuth   = true;                                   
//    $mail->Username   = $email;                   
//    $mail->Password   = $password;                     
//    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;  
//    $mail->Port       = 587;                                   
//    $mail->setFrom($email,'SEO');
//    $mail->addAddress($to_id);
//    $mail->addReplyTo($email,'Information');
//    $mail->isHTML(true); 
//    $mail->Subject = $subject;
//    $mail->Body    = $message;   
//    $mail->send();
//    echo 'Message has been sent';
//} catch (Exception $e) {
//    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
//}
////$mail=new PHPMailer;
////$mail->SMTPOptions=array('ssl' =>array('verify_peer'=>false,'verify_peer_name'=>false,'allow_self_signed'=>true));
////$mail->isSMTP();
////$mail->Host='smtp.gmail.com';
////$mail->Port=587;
////$mail->SMTPSecure='SSL';
////$mail->SMTPAuth=true;
////$mail->Username=$email;
////$mail->Password=$password;
////$mail->addAddress($to_id);
////$mail->Subject=$subject;
////$mail->msgHTML($message);
//if(!$mail->send())
//{
//$error="Mailer Error:".$mail->ErrorInfo;
//echo '<p id="para">'.$error.'</p>';
//}
//else
//{
//echo "<script>window.location='sign_in.php';</script>";
//}   
}
else
{
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";
 }
}}
else
{
echo "<br><div class='alert alert-warning'>Retry password Not Match</div>";
 }
}           
?>
        </div>    
    </div>
    </body>
</html>