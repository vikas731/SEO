<?php include'header.php' ?>
<body>
 
    
    <div class="container">
        <div class="row  pt-5">
  <?php
//selection
$sql="select * from faq where questionid='$_GET[id]'";
$result=$conn->query($sql);

$row=$result->fetch_assoc();
    
    $qid=$row['questionid'];
    ?>
           
            <div class="col-md-9 pt-3">
            <h3 class='pb-2'> <?php echo $row['question']; ?></h3>
                  <h5 class='pb-2'> <?php echo $row['answer']; ?></h5>
        
            
           
    </div>
</div>
<?php include'footer.php' ?>