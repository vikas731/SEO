<?php include'header.php' ?>
<div class="container-fluid">
<div class="row"> 
            <div class='col-md-12 text-center bg-light pt-5 pb-5'> 
            <h5> Seo Glossary </h5>
            <h6> <a href='index.php' style="color:#f9a32a "> Home </a> <i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i>Glossary </h6>
            
    </div></div></div>
 
    
    <div class="container pt-4">
        <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-10">
        <nav aria-label="Page navigation example">
  
            <ul class="pagination" style="text-align:center;">

    <li class="page-item"><a class="page-link" href="allterm.php?lt=A">A</a></li>
    <li class="page-item"><a class="page-link" href="allterm.php?lt=B">B</a></li>
    <li class="page-item"><a class="page-link" href="allterm.php?lt=C">C</a></li>  
    <li class="page-item"><a class="page-link" href="allterm.php?lt=D">D</a></li> 
    <li class="page-item"><a class="page-link" href="allterm.php?lt=E">E</a></li>
    <li class="page-item"><a class="page-link" href="allterm.php?lt=F">F</a></li>
    <li class="page-item"><a class="page-link" href="allterm.php?lt=G">G</a></li>  
    <li class="page-item"><a class="page-link" href="allterm.php?lt=H">H</a></li>
    <li class="page-item"><a class="page-link" href="allterm.php?lt=I">I</a></li>
    <li class="page-item"><a class="page-link" href="allterm.php?lt=J">J</a></li>
    <li class="page-item"><a class="page-link" href="allterm.php?lt=K">K</a></li>
    <li class="page-item"><a class="page-link" href="allterm.php?lt=L">L</a></li>  
    <li class="page-item"><a class="page-link" href="allterm.php?lt=M">M</a></li> 
    <li class="page-item"><a class="page-link" href="allterm.php?lt=N">N</a></li>
    <li class="page-item"><a class="page-link" href="allterm.php?lt=O">O</a></li>
    <li class="page-item"><a class="page-link" href="allterm.php?lt=P">P</a></li>  
    <li class="page-item"><a class="page-link" href="allterm.php?lt=Q">Q</a></li>
    <li class="page-item"><a class="page-link" href="allterm.php?lt=R">R</a></li>
    <li class="page-item"><a class="page-link" href="allterm.php?lt=S">S</a></li>
    <li class="page-item"><a class="page-link" href="allterm.php?lt=T">T</a></li>  
    <li class="page-item"><a class="page-link" href="allterm.php?lt=U">U</a></li> 
    <li class="page-item"><a class="page-link" href="allterm.php?lt=V">V</a></li>
    <li class="page-item"><a class="page-link" href="allterm.php?lt=W">W</a></li>
    <li class="page-item"><a class="page-link" href="allterm.php?lt=X">X</a></li>  
    <li class="page-item"><a class="page-link" href="allterm.php?lt=Y">Y</a></li>
    <li   class="page-item"><a class="page-link" href="allterm.php?lt=Z">Z</a></li>
                
      
  </ul>
          
</nav>
        </div>           <div class="col-md-1"></div>
  </div>
  <?php
//selection
    $i=0;
    $lt=$_GET['lt'];
$sql="select * from term where term LIKE '$lt%' order by term ASC";
$result=$conn->query($sql);

while($row=$result->fetch_assoc())
{
    $i++;
    $clr=$i%2!=0?"#fff":"#f5f5f5";
    
    $nid=$row['termid'];
    ?>
        <div class="row  pt-2" style='background:<?php echo $clr; ?>'>
            <div class="col-md-2 pt-5 pb-2">
            <h5 class='pt-2'> <?php echo $row['term']; ?></h5>
            </div>   
<div class="col-md-10">
 
<p class='text-justify'><?php echo $row['description']; ?></p>
                        </div>
    </div>
<?php } ?>
</div>
<?php include'footer.php' ?>