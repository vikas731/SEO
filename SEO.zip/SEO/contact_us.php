<?php include 'header.php' ?>
<div class="container-fluid">
  <div class="row"> 
    <div class='col-md-12 text-center bg-light pt-5 pb-5'> 
      <h5> Contact us </h5>
      <h6> <a href='index.php' style="color:#f9a32a "> Home </a> <i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i> Contact us  </h6>
    </div>
  </div>
</div>
<div class="container">
  <div class="row  pt-5">
    <div class="col-md-1"></div>
    <div class="col-md-3">           
      <div class="row">
        <div class="col-md-12">
          <p class="p-2"><i class="icofont icofont-phone"></i>+91 9786743638</p>
          <p class="p-2"><i class="icofont icofont-facebook"></i>facebook</p>
          <p class="p-2"><i class="icofont icofont-email"></i>projectphp@gmail.com</p>
          <p class="p-2"><i class="icofont icofont-location-pin"></i>Khalsa College,Amritsar</p>
        </div>
      </div>
    </div>            
    <div class="col-7">
      <h4>Start a Conversation</h4> <br/>          
      <form action="" method="post" > 
       <div class="row">
         <div class="col-md-6">
           <label>Name *</label>                                     
           <input type="text"  class="form-control rounded-0" required name="nm" style="border:none; border-bottom:1px solid black;"><br/>
         </div>
         <div class="col-md-6">
           <label>Email *</label>                     
           <input type="email" class="form-control rounded-0" style="border:none; border-bottom:1px solid black;" required name="em"><br/>
         </div>
       </div>
       <div class='row'>
         <div class="col-md-6">
          <label>Website Url</label>
           <input type="url"  class="form-control rounded-0" name="url" style="border:none; border-bottom:1px solid black;">
           <p class="pt-2"><small >(optional)</small></p>
         </div>              
         <div class="col-md-6">
           <label>Phone</label>
           <input type="tel" class="form-control rounded-0" name="phn" style="border:none; border-bottom:1px solid black;">
           <p class="pt-2"><small>(optional)</small></p>
         </div> 
       </div>
       <div class='row'>
         <div class="col-md-12">
           <label>Message *</label>
           <textarea rows="6" class="form-control" required name="msg"></textarea><br/>
           <button  class="btn btn-primary" type="submit" name="save" style="background:#0674a1;">Send Message</button>
         </div>
       </div>
      </form>
     </div>
<div class="col-md-1"></div>
  </div>
</div>
    
<?php
//insertion
if(isset($_POST['save'])){
$sql="insert into contact_msg(name,email,phoneno,url,message) values('$_POST[nm]','$_POST[em]','$_POST[phn]','$_POST[url]','$_POST[msg]');";
if($conn->query($sql)==TRUE)
{
require 'PHPMailer-master/PHPMailerAutoload.php';
$email='gagandeep.a24@gmail.com';
$password='project@php';
$to_id=$_POST['em'];
$subject='Thanks for being awesome!';

$message='<h4> Hi '.$_POST['nm'].'</h4><br/> <p> Thanks for your Message, We try to respond to your message  within 1 business day  </p> <br/> <h5> Regards : Seo Team </h5>';

$mail=new PHPMailer;
    $mail->SMTPOptions=array('ssl' =>array('verify_peer'=>false,'verify_peer_name'=>false,'allow_self_signed'=>true));
$mail->isSMTP();
$mail->Host='smtp.gmail.com';
$mail->Port=587;
$mail->SMTPSecure='tls';
$mail->SMTPAuth=true;
$mail->Username=$email;
$mail->Password=$password;
$mail->addAddress($to_id);
$mail->Subject=$subject;
$mail->msgHTML($message);
if(!$mail->send())
{
$error="Mailer Error:".$mail->ErrorInfo;
echo '<p id="para">'.$error.'</p>';
}
else
{
echo "<br><div class='alert alert-success' style='padding:1px;'><br/>Mail has been Sent</div>";
}
}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";

}
?>

<?php include 'footer.php' ?>