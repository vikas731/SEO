<?php include 'header.php' ?>
<div class="container-fluid">
    <div class="row"> 
            <div class='col-md-12 text-center bg-light pt-5 pb-5'> 
            <h5>Encode Decode URL  </h5>
                <h6> <a href='index.php' style="color:#f9a32a "> Home </a> <i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i> SEO Tools <i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i> Encode Decode URL </h6>
            
            </div>
    </div></div>
    <div class="container pt-5" style="min-height:500px">
        <div class="row">
            <div class="col-md-12">
          
                <p>This tool helps to encode or decode the string. Basically, it is used for URL Encoding where characters outside the ASCII set is converted into a valid ASCII format. This URL Encoding process does two things at the time of encoding.</p>
            </div>
        </div>
        <div class="row pt-2">
        
            <div class="col-md-6 pt-5 bg-light"><h5 class='pb-2'>Enter your Website url</h5>
                <form action="" method="post">
                    <input type="name" placeholder="Enter Website url" name="url" maxlength="400" class="form-control" required><br/>
                    <button type="submit" class="btn btn-primary " name="encode">Encode</button>
                    
                    <button type="submit" class="btn btn-secondary " name="decode">Decode</button>

                </form>

<?php
if(isset($_POST['encode'])){
$res=urlencode($_POST['url']);

echo "<p> <b> Entered Url : </b>".$_POST['url']."</p>";

echo "<p> <b> Encoded Url : </b>".$res."</p>";
}
else if(isset($_POST['decode'])){
$res=urldecode($_POST['url']);

echo "<p> <b> Entered Url : </b>".$_POST['url']."</p>";
echo "<p> <b> Decoded Url : </b>".$res."</p>";
}

?>




            </div>
            <div class="col-md-6 pt-4">
                <h5>What is URL Encoding?</h5>
                <p>URL Encoding also known as Percent-encoding, convert characters into a format that can be transmitted over the internet. URL Encoding is basically used within the main Uniform Resource Identifier (URI) which include both Uniform Resource Locator (URL) and Uniform Resource Name (URN). In URL Encoding, all non-alphanumeric character except - _ . are replaced with a percent (%) sign followed by two hex digits and spaces encoded as plus (+) sign.</p>
                
    
                <!-- Button trigger modal -->
<a href='#' data-toggle="modal" data-target="#exampleModalScrollable">
  Know More About Encode Decode URL 
</a>

<!-- Modal -->
<div class="modal fade" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalScrollableTitle">HTML Source Viewer</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          
             <h5>Why and when would you use URL Encoding?</h5>
                <p>When the URL contain a character from the Reserved Character, then the character must be encoded. It is necessary and you should always encode any special characters found in URL.</p>
          
          
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          
      </div>
    </div>
  </div>
</div>
            </div>
        </div>
        </div>
    

<?php include 'footer.php' ?>