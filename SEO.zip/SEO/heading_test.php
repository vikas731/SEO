<?php include 'header.php' ?>
<div class="container-fluid">
    <div class="row"> 
            <div class='col-md-12 text-center bg-light pt-5 pb-5'> 
            <h5>Heading Tags Test</h5>
                <h6> <a href='index.php' style="color:#f9a32a "> Home </a> <i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i> Site Test <i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i>Heading Test </h6>
            
        </div></div></div>
    <div class="container pt-5" style="min-height:500px">
        <div class="row">
            <div class="col-md-12">
           
            
                <p>Check if your webpage is using any H1 and H2 HTML header tags. Header tags are not visible to users, but help clarify and support the overall theme or purpose of your page to search engines. The H1 tag represents the most important heading, e.g., the title of the page or blog post. The H2 tag represents the second most important headings on the webpages, e.g., the subheadings.</p>
            </div>
        </div>
       <div class="row pt-2">
        
            <div class="col-md-6 pt-5 pb-5  bg-light"><h5 class='pb-2'>Enter your Website url</h5>
                <form action="" method="post">
                    <input type="url" placeholder="Enter Website url" name="url" class="form-control" required><br/>
                    <button type="submit" class="btn btn-primary " name="submit">Submit</button>
                </form>

            </div>
            <div class="col-md-6 pt-4">
                <p>In order to pass this test you must indentify the most important topics from your page and insert those topics between &lt;h1&gt;...&lt;/h1 tags.</p>
     
            </div>
        </div>
        <div class="row">
        <div class="col-md-12">
                             
            <?php
//insertion
if(isset($_POST['submit'])){
if(!isset($_SESSION['uid']))
    echo "<script> window.location='sign_in.php?page=heading_test';</script>";
    else{

$sql="insert into usage_rec(title,url,userid) values('heading_test','$_POST[url]','$_SESSION[uid]');";
if($conn->query($sql)==TRUE)
{
    Function  get_all_headings( $content)  {    
preg_match_all( '/\<(h[1-6])\>(.*)<\/h[1-6]>/i', $content, $matches );
    $r = array();
    if( !empty( $matches[1] ) && !empty( $matches[2] ) ) {
        $tags = $matches[1];
        $titles = $matches[2];
        foreach ($tags as $i => $tag) {
            $r[] = array( 'tag' => $tag, 'title' => $titles[ $i ] );
        }
   }
    return $r; }
 $url=$_POST['url'];
$text=@file_get_contents($url);
$r=get_all_headings($text);
echo "<table class='table'>";
 echo "<tr><th>Tag</th><th>Content</th></tr>";
for($x=0;$x<count($r);$x++)
echo "<tr><td>".$r[$x]['tag']."</td><td>".strip_tags($r[$x]['title'])."</td></tr>";
echo "</table>";

}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";
}}
 ?>  
               
            </div>
        </div>
        </div>
    
<?php include 'footer.php' ?>