<?php

$servername="localhost";
$username="root";
$password="";
$dbname="seo_db";

//create connection
$conn=new mysqli($servername,$username,$password,$dbname);
//check connection
if(!$conn)
{
 die("connection failed : ".mysqli_connection_error());
}
?>