<?php include 'header.php' ?>
<div class="container-fluid">
   <div class="row"> 
            <div class='col-md-12 text-center bg-light pt-5 pb-5'> 
            <h5>Sitemap Test </h5>
                <h6> <a href='index.php' style="color:#f9a32a "> Home </a> <i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i> Site Test <i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i> Sitemap Test </h6>
            
            </div>
    </div></div>
     <div class="container pt-5" style="min-height:500px">
        <div class="row">
            <div class="col-md-12">
           
            <h3>Sitemap Test</h3>
                <p>Check if the website has a sitemap. A sitemap is important as it lists all the web pages of the site and let search engine crawlers to crawl the website more intelligently. A sitemap also provides valuable metadata for each webpage.</p>
            </div>
        </div>
         <div class="row pt-2">
        
            <div class="col-md-6 pt-5 pb-5  bg-light"><h5 class='pb-2'>Enter your Website url</h5>
                <form action="" method="post">
                    <input type="url" placeholder="Enter Website url" name="url" class="form-control" required><br/>
                    <button type="submit" class="btn btn-primary " name="submit">Submit</button>
                </form>            </div>
            <div class="col-md-6 pt-4">
                 <p>In order to pass this test you must create a sitemap.xml file for your website. Some of the best practices are listed below:</p>
                <ul>

                    <li>It is strongly recommended that you place your sitemap at the root directory of your website: http://yourwebsite.com/sitemap.</li></ul>
                    
                                   <!-- Button trigger modal -->
<a href='#' data-toggle="modal" data-target="#exampleModalScrollable">
  Know More About Sitemap Test 
</a>

<!-- Modal -->
<div class="modal fade" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalScrollableTitle">Sitemap Test</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <p>In order to pass this test you must create a sitemap.xml file for your website. Some of the best practices are listed below:</p>
                <ul>

        <li>It is strongly recommended that you place your sitemap at the root directory of your website: http://yourwebsite.com/sitemap.xml But in some situations, you may want to produce different sitemaps for different paths on your site (e.g., security permission issues)</li>
       <li>Sitemaps should be no larger than 10MB (10,485,760 bytes) and can contain a maximum of 50,000 URLs. This means that if your site contains more than 50,000 URLs or your sitemap is bigger than 10MB, you must create multiple sitemap files and use a Sitemap index file</li>
    <li>All URLs listed in the sitemap must reside on the same host as the sitemap. For instance, if the sitemap is located at http://www.yourwebsite.com/sitemap.xml, it can't include URLs from http://subdomain.yourwebsite.com</li>
    <li>Once you have created your sitemap, let search engines know about it by submitting directly to them, pinging them, or adding the sitemap location to your robots.txt file</li>
    <li>Sitemaps can be compressed using gzip, reducing bandwidth consumption</li>
          </ul>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
    
      </div>
    </div>
  </div>

    
                </div>
            </div>
        
             <br/>
             <table class="table table-bordered table-hover table-sm"> 
<tr><th>URL </th>
<th>LastChange (GMT) </th>
<th>	Change Frequency </th>
<th>Priority </th>
</tr>


                              <?php
//insertion
if(isset($_POST['submit'])){
if(!isset($_SESSION['uid']))
    echo "<script> window.location='sign_in.php?page=sitemap';</script>";
    else{
$sql="insert into usage_rec(title,url,userid) values('sitemap','$_POST[url]','$_SESSION[uid]');";
if($conn->query($sql)==TRUE)
{
   echo '<h5> Result </h5>';
	$URL=$_POST['url']."/sitemap.xml";
@$url=file_get_contents($URL);
if($url!=''){
@$xml=new SimpleXMLElement($url);
//print_R($xml);


if(!$xml)
echo "Invalid Url"; 
else{

foreach($xml->url as $val)
 {
@$x=(100*(string)$val->priority);
  echo "<td>".$val->loc.'</td> 
  <td>'. $val->lastmod.'</td>
  <td> '. $val->changefreq.'</td>
  <td> '.$x.' %</td>
  </tr>';
 }
 }

 

 }

}
else
echo "<br/><div class='alert alert-warning'>Error".$conn->error."</div>";
}}
 ?> 
                    </table>

        </div>
        </div>

<?php include 'footer.php' ?>