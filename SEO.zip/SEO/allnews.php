<?php include'header.php' ?>
<div class="container-fluid">
<div class="row"> 
            <div class='col-md-12 text-center bg-light pt-5 pb-5'> 
            <h5> News </h5>
            <h6> <a href='index.php' style="color:#f9a32a "> Home </a> <i class=" icofont icofont-hand-drawn-alt-right" style="font-size:20px;"></i> News </h6>
            
            </div>
</div>
</div>  
    <div class="container">

  <?php
//selection
$sql="select * from news order by newsid desc";
$result=$conn->query($sql);

while($row=$result->fetch_assoc())
{
    
    $nid=$row['newsid'];
    ?>
        <div class="row  pt-3 border pb-3 mt-3 ">
            <div class="col-md-4">
            
            <img src="admin/<?php echo $row['image']; ?>" width="95%" height="230"> </div>
<div class="col-md-8">
 <h5 class='pt-2'> <?php echo $row['title']; ?></h5>
<p class='text-justify'><?php echo substr(strip_tags($row['content']),0,450); ?></p>
<div class='text-right'>            
<?php   echo "<a href='news.php?id=$nid' class='btn btn-outline-dark'>Read More</a>" ?>
            </div> </div>
    </div>
<?php } ?>
</div>
<?php include'footer.php' ?>