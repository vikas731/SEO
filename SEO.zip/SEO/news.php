<?php include'header.php' ?>
<div class="container-fluid">
<div class="row"> 
            <div class='col-md-12 text-center bg-light pt-5 pb-5'> 
            <h5> News </h5>
            <h6> <a href='index.php' style="color:#f9a32a "> Home </a> > News </h6>
            
            </div>
</div>
</div>
    
    <div class="container">
        <div class="row  pt-5">
  <?php
//selection
$sql="select * from news where newsid='$_GET[id]'";
$result=$conn->query($sql);

$row=$result->fetch_assoc();
    
    $nid=$row['newsid'];
    ?>
            <div class="col-md-9 pt-3">
            <h3 class='pb-2'> <?php echo $row['title']; ?></h3>
                  <h5 class='pb-2'> <?php echo $row['subtitle']; ?></h5>
            </p>
             <p>
             <i class="icofont icofont-calendar"></i> <?php echo $row['addedon']; ?><br/>
              

            <img src="admin/<?php echo $row['image']; ?>" width="90%" height="450">
                <p><?php echo $row['content']; ?></p>
           
    </div>
</div>
<?php include'footer.php' ?>